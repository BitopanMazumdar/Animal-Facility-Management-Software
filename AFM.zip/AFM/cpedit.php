<?php include "include/sesionlauth.php"; ?>

<?php 
//users(FName,LName,EmailID,Contact,UserType)
$cpId=filter_var($_POST['cpId'], FILTER_SANITIZE_STRING);

if($cpId!=""){
include"DBconnect.php";
	////contactperson(cpId, clientID, cpName, cpDesignation, mobile1, mobile2, phone1, phone2, email1, email2, adderss)
	$result = mysqli_query($db,"SELECT DISTINCT cpId, clientID, cpName, cpDesignation, mobile1, mobile2, phone1, phone2, email1, email2, adderss FROM contactperson WHERE cpId='$cpId'");
	if($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
	?>
	
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  <link rel="stylesheet" href="css/custom.css">
  
</head>
<body style="background-color:#F8F9FA">
<nav >
 <div class="container-fluid">
	<?php 
	include"include/headerboot.php"; 
	?>
  </div>
  <div class="container-fluid">
	<?php 
	include"include/MenuAi.php"; 
	?>		
  </div>
  <div class="container-fluid">
	<?php 
	include"include/moniRegMenu.php"; 
	?>		
  </div>
 
</nav>
 

<script language="javascript" type="text/javascript" >
	function valid()
	{
		frm = document.clientform;
		var patt = /[%*+;<=>^]/;
		
		if(frm.caddress.value !=""){
			if(patt.test(frm.caddress.value)){
				alert("invalid contact person address ! special characters: %*+;<=>^ are not allowed");
				frm.caddress.focus();
				return false;
			}
		}
		
		r=confirm("confirm submission!");
		if(r==true){
		  return true;
		}else{
		  frm.name.focus;
		  return false;
		}
		   
	}
</script>		

<div>&nbsp;</div>

<div class="container">
  
  <form class="form-horizontal" name="clientform" action="cpEdit_process.php" method="POST" onsubmit="return valid();">

<div class="row mt-4 border-top">
		<div class="col-lg-12">
			<div class="row mb-3 mt-3">
				<div class="col-lg-12 p-add-head">
					<h3 class="text-primary">Edit Contact Person Details</h3>
				</div>
			</div>
			<div class="row mb-2 mt-2">
				<div class="col-lg-6">
					<label for="cname">Name<span style="color: red">*</span></label>
					<input style="text-transform: capitalize;" pattern="[A-Za-z0-9\s.-]*" title="Special characters: . - are allowed only" required type="text" class="form-control" id="cname" placeholder="Contact Name" name="cname" value="<?php echo htmlspecialchars($pass['cpName']); ?>" />
					<input type="text" readonly="true" class="form-control sr-only" id="cpold" name="cpold" value="<?php echo $cpId; ?>" />
					</div>
				<div class="col-lg-6">
					<label for="cdesignation">Designation</label>
					<input style="text-transform: capitalize;" pattern="[A-Za-z0-9\s.-]*" title="Special characters: . - are allowed only" type="text" class="form-control" id="cdesignation" placeholder="Enter Email" name="cdesignation" value="<?php echo htmlspecialchars($pass['cpDesignation']); ?>" />
				</div>
			</div> 
			
			<div class="row mb-2 mt-2">
				<div class="col-lg-6">
					<label for="cemail1">Email</label>
					<input type="text" class="form-control" id="cemail1" placeholder="Enter Email" name="cemail1" value="<?php echo htmlspecialchars($pass['email1']); ?>" />
				</div>
				<div class="col-lg-6">
					<label for="cemail2">Alternate Email</label>
					<input type="text" class="form-control" id="cemail2" placeholder="Alternate Email" name="cemail2" value="<?php echo htmlspecialchars($pass['email2']); ?>" />
				</div>
			</div>

			<div class="row mb-2 mt-2">
				<div class="col-lg-6">
					<label for="cmobile1">Mobile No.</label>
					<input pattern="[0-9\+\s-]{9,}" title="digits + - allowed only minimum length:9 " type="text" class="form-control" id="cmobile1" placeholder="Enter Mobile No." name="cmobile1" value="<?php echo htmlspecialchars($pass['mobile1']); ?>" />
				</div>
				<div class="col-lg-6">
					<label for="cmobile2">Alternate Mobile No.</label>
					<input pattern="[0-9\+\s-]{9,}" title="digits + - allowed only minimum length:9 " type="text" class="form-control" id="cmobile2" placeholder="Alternate Mobile No." name="cmobile2" value="<?php echo htmlspecialchars($pass['mobile2']); ?>" />
				</div>
			</div>
			<div class="row mb-2 mt-2">
				<div class="col-lg-6">
					<label for="cphone1">Phone No.</label>
					<input pattern="[0-9\/\+\s-]{9,}" type="tel" title="digit + - and / allowed only" type="text" class="form-control" id="cphone1" placeholder="Enter Phone No." name="cphone1" value="<?php echo htmlspecialchars($pass['phone1']); ?>" />
				</div>
				<div class="col-lg-6">
					<label for="cphone2">Alternate Phone No.</label>
					<input pattern="[0-9\/\+\s-]{9,}" type="tel" title="digit + - and / allowed only" type="text" class="form-control" id="cphone2" placeholder="Alternate Phone No." name="cphone2" value="<?php echo htmlspecialchars($pass['phone2']); ?>" />
				</div>
			</div>
			<div class="row mb-2 mt-2"> 
				
				<div class="col-lg-8">
					<label for="caddress">Address</label>
					<textarea style="text-transform: capitalize;" class="form-control col-lg-6" id="caddress" placeholder="Enter Address" name="caddress"><?php echo htmlspecialchars($pass['adderss']); ?></textarea>
				</div>
				
			</div>
		</div>
	</div>
	<div class="form-group">
		<div>&nbsp;</div>
      <div class="col-sm-offset-4 col-sm-8">
        <button type="submit" class="btn btn-primary">
		<i class="fa fa-btn fa-edit"></i> Edit 
		</button>
		<button type="reset" class="btn btn-primary"><i class="fa fa-btn fa-refresh"></i> Reset</button> 
		<button type="button" class="btn btn-primary" onclick="window.history.back()"><i class="fa fa-btn fa-arrow-circle-left"></i> Back</button>
      </div>
    </div>
	</form>
</div>
<div>&nbsp;</div><div>&nbsp;</div>
<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
</div>
</body>
</html>	
<?php 
	}
}else{
	$_SESSION['message']="Invalid data !";
	echo '<META HTTP-EQUIV="Refresh" Content="0; URL=viewClient.php">';
}
?>