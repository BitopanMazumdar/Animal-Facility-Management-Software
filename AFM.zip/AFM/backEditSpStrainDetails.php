<div class="panel-heading">
                        Current Manager
                    </div>

                    <div class="panel-body  table-responsive" >
                        <table class="table table-striped table-hover">
                            <thead>
                                <th>Manager</th>
								<th>Zone</th>
                                <th>&nbsp;</th>
                            </thead>
                            <tbody>