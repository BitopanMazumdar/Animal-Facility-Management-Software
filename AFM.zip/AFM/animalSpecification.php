<div class="table-responsive col-sm-10 col-sm-offset-2 " >
<table class="table table-bordered" align="center">

							  <thead style="background-color: #b5e7a0;">
								<th>Species </th>
								<th>Strain </th>
								<th>Gender</th>
								<th >No of Animals </th>
								<th>Weight / Age </th>
								<th>Year</th>
								<th>&nbsp;</th>
							  </thead>
								<tbody>
									  <tr  id="row1">
							  <input type="hidden" id="row_no"  class="form-control" name="row_no" value="1" />
								<td align="center">
									<select class="form-control" name="species1" id="species1" onchange="getStrain(this.value,1)" required>
										<option value="">Select</option>											
									</select>
								</td>
								<td align="left" ><label>
								  <select required class="form-control" name="strain1" id="strain1" >
									<option value="">Select</option>

									 </select>
								</label></td>
								<td align="center" ><label>
										   <select required  class="form-control" name="sex1" id="sex1">
										   <option value="Any" selected="selected">Any</option>
									<option value="Male">Male</option>
									<option value="Female">Female</option>
								  </select>
								</label></td>
								<td align="center" ><label>
								  <input required class="form-control" name="no_of_an1"  type="number"  min="1" id="no_of_an1"  />
								</label></td>
							   <!-- <td align="center" ><input class="form-control" name="iso1" readonly="true" type="text"  id="iso1" /></td> -->
								<td align="center" ><input pattern="[0-9A-Za-z ]*" title="Special characters are not allowed" class="form-control" name="age1" type="text" id="age1" /></td>
								<td align="center" ><label>
								  <input  class="form-control" name="issueyear1"  type="number"  min="1" id="issueyear1"  />
								</label></td>
								<td width="6%" >&nbsp;</td>
							  </tr>
							  <tr  id="row2" style=" display:none;">
								<td align="center">
									<select class="form-control" name="species2" id="species2" onchange="getStrain(this.value,2)" >
										<option value="">Select</option>											
									</select>
								</td>
								<td align="left" ><label>
								  <select class="form-control" name="strain2" id="strain2"   " >
									<option value="">Select</option>
									
									</select>
								</label></td>
								<td align="center" ><label>
								  <select  class="form-control" name="sex2" id="sex2">
								  <option value="Any" selected="selected">Any</option>
									<option value="Male">Male</option>
									<option value="Female">Female</option>
								  </select>
								</label></td>
								<td align="center" ><label>
								  <input class="form-control" name="no_of_an2"  type="number"  min="1" id="no_of_an2"  />
								</label></td>
								<!--<td align="center" ><input class="form-control" name="iso2" readonly="true" type="text"  id="iso2" /></td> -->

								<td align="center" ><input pattern="[0-9A-Za-z ]*" title="Special characters are not allowed" class="form-control" name="age2" type="text" id="age2" /></td>
								<td align="center" ><label>
								  <input class="form-control" name="issueyear2"  type="number"  min="1" id="issueyear2"  />
								</label></td>
								<td width="6%" ><img src="images/close.jpg" alt="close" width="20" height="20" id="close2" style="cursor:pointer; display:none;" onclick="Close(2)" /></td>
							  </tr>
							  <tr  id="row3" style=" display:none;">
								<td align="center">
									<select class="form-control" name="species3" id="species3" onchange="getStrain(this.value,3)" >
										<option value="">Select</option>											
									</select>
								</td>
								<td align="left" ><label>
								  <select class="form-control" name="strain3" id="strain3" >
									<option value="">Select</option>
									
									</select>
								</label></td>
								<td align="center" ><label>
								  <select  class="form-control" name="sex3" id="sex3">
								  <option value="Any" selected="selected">Any</option>
									<option value="Male">Male</option>
									<option value="Female">Female</option>
								  </select>
								</label></td>
								<td align="center" ><label>
								  <input class="form-control" name="no_of_an3"  type="number"  min="1" id="no_of_an3"  />
								</label></td>
								<!-- <td align="center" ><input class="form-control" name="iso3" readonly="true" type="text" id="iso3" /></td> -->
								<td align="center" ><input pattern="[0-9A-Za-z ]*" title="Special characters are not allowed" class="form-control" name="age3" type="text" id="age3" /></td>
								<td align="center" ><label>
								  <input class="form-control" name="issueyear3"  type="number"  min="1" id="issueyear3"  />
								</label></td>
								
								<td width="6%" ><img src="images/close.jpg" alt="close" width="20" height="20" id="close3" style="cursor:pointer; display:none;" onclick="Close(3)" /></td>
							  </tr>
							  <tr  id="row4" style=" display:none;">
							  <td align="center">
									<select class="form-control" name="species4" id="species4" onchange="getStrain(this.value,4)" >
										<option value="">Select</option>											
									</select>
								</td>
								<td align="left" ><label>
								  <select class="form-control" name="strain4" id="strain4" >
									<option value="">Select</option>
									
									 </select>
								</label></td>
								<td align="center" ><label>
								  <select  class="form-control" name="sex4" id="sex4">
								  <option value="Any" selected="selected">Any</option>
									<option value="Male">Male</option>
									<option value="Female">Female</option>
								  </select>
								</label></td>
								<td align="center" ><label>
								  <input class="form-control" name="no_of_an4"  type="number"  min="1" id="no_of_an4"  />
								</label></td>
							  <!--  <td align="center" ><input class="form-control" name="iso4" readonly="true" type="text" id="iso4" /></td> -->
								<td align="center" ><input pattern="[0-9A-Za-z ]*" title="Special characters are not allowed" class="form-control" name="age4" type="text" id="age4" /></td>
								<td align="center" ><label>
								  <input  class="form-control" name="issueyear4"  type="number"  min="1" id="issueyear4"  />
								</label></td>
								<td width="6%" ><img src="images/close.jpg" alt="close" width="20" height="20" id="close4" style="cursor:pointer; display:none;" onclick="Close(4)" /></td>
							  </tr>
							  <tr  id="row5" style=" display:none;">
								<td align="center">
									<select class="form-control" name="species5" id="species5" onchange="getStrain(this.value,5)" >
										<option value="">Select</option>											
									</select>
								</td>
								<td align="left" ><label>
								  <select class="form-control" name="strain5" id="strain5" >
									<option value="">Select</option>
									
									 </select>
								</label></td>
								<td align="center" ><label>
								  <select  class="form-control" name="sex5" id="sex5">
								 <option value="Any" selected="selected">Any</option>
									<option value="Male">Male</option>
									<option value="Female">Female</option>
								  </select>
								</label></td>
								<td align="center" ><label>
								  <input class="form-control" name="no_of_an5"  type="number"  min="1" id="no_of_an5"  />
								</label></td>
							   <!-- <td align="center" ><input class="form-control" name="iso5" readonly="true" type="text" id="iso5" /></td> -->
								<td align="center" ><input pattern="[0-9A-Za-z ]*" title="Special characters are not allowed" class="form-control" name="age5" type="text" id="age5" /></td>
								<td align="center" ><label>
								  <input  class="form-control" name="issueyear5"  type="number"  min="1" id="issueyear5"  />
								</label></td>
								<td width="6%" ><img src="images/close.jpg" alt="close" width="20" height="20" id="close5" style="cursor:pointer; display:none;" onclick="Close(5)" /></td>
							  </tr>
							  <tr  id="row6" style=" display:none;">
							  <td align="center">
									<select class="form-control" name="species6" id="species6" onchange="getStrain(this.value,6)" >
										<option value="">Select</option>											
									</select>
								</td>
								<td align="left" ><label>
								  <select class="form-control" name="strain6" id="strain6" >
									<option value="">Select</option>
									
									 </select>
								</label></td>
								<td align="center" ><label>
								  <select  class="form-control" name="sex6" id="sex6">
								 <option value="Any" selected="selected">Any</option>
									<option value="Male">Male</option>
									<option value="Female">Female</option>
								  </select>
								</label></td>
								<td align="center" ><label>
								  <input class="form-control" name="no_of_an6"  type="number"  min="1" id="no_of_an6"  />
								</label></td>
							   <!-- <td align="center" ><input class="form-control" name="iso6" readonly="true" type="text" id="iso6"  /></td> -->
								<td align="center" ><input pattern="[0-9A-Za-z ]*" title="Special characters are not allowed" class="form-control" name="age6" type="text" id="age6" /></td>
								<td align="center" ><label>
								  <input  class="form-control" name="issueyear6"  type="number"  min="1" id="issueyear6"  />
								</label></td>
								<td width="6%" ><img src="images/close.jpg" alt="close" width="20" height="20" id="close6" style="cursor:pointer; display:none;" onclick="Close(6)" /></td>
							  </tr>
							  <tr  id="row7" style=" display:none;">
								<td align="center">
									<select class="form-control" name="species7" id="species7" onchange="getStrain(this.value,7)" >
										<option value="">Select</option>											
									</select>
								</td>
								<td align="left" ><label>
								  <select class="form-control" name="strain7" id="strain7" >
									<option value="">Select</option>
									
									  </select>
								</label></td>
								<td align="center" ><label>
								  <select  class="form-control" name="sex7" id="sex7">
								  <option value="Any" selected="selected">Any</option>
									<option value="Male">Male</option>
									<option value="Female">Female</option>
								  </select>
								</label></td>
								<td align="center" ><label>
								  <input class="form-control" name="no_of_an7"  type="number"  min="1" id="no_of_an7"   />
								</label></td>
							 <!--   <td align="center" ><input class="form-control" name="iso7" readonly="true" type="text" id="iso7"  /></td> -->
								<td align="center" ><input pattern="[0-9A-Za-z ]*" title="Special characters are not allowed" class="form-control" name="age7" type="text" id="age7"/></td>
								<td align="center" ><label>
								  <input  class="form-control" name="issueyear7"  type="number"  min="1" id="issueyear7"  />
								</label></td>
								<td width="6%" ><img src="images/close.jpg" alt="close" width="20" height="20" id="close7" style="cursor:pointer; display:none;" onclick="Close(7)" /></td>
							  </tr>
							  
							  <tr  id="row8" style=" display:none;">
								<td align="center">
									<select class="form-control" name="species8" id="species8" onchange="getStrain(this.value,8)" >
										<option value="">Select</option>											
									</select>
								</td>
								<td align="left" ><label>
								  <select class="form-control" name="strain8" id="strain8" >
								  <option value="">Select</option>
								  
									 </select>
								</label></td>
								<td align="center" ><label>
								  <select  class="form-control" name="sex8" id="sex8">
								  <option value="Any" selected="selected">Any</option>
									<option value="Male">Male</option>
									<option value="Female">Female</option>
								  </select>
								</label></td>
								<td align="center" ><label>
								  <input class="form-control" name="no_of_an8"  type="number"  min="1" id="no_of_an8"   />
								</label></td>
								<!--<td align="center" ><input class="form-control" name="iso8" readonly="true" type="text" id="iso8"  /></td> -->
								<td align="center" ><input pattern="[0-9A-Za-z ]*" title="Special characters are not allowed" class="form-control" name="age8" type="text" id="age8"/></td>
								<td align="center" ><label>
								  <input  class="form-control" name="issueyear8"  type="number"  min="1" id="issueyear8"  />
								</label></td>
								<td width="6%" ><img src="images/close.jpg" alt="close" width="20" height="20" id="close8" style="cursor:pointer; display:none;" onclick="Close(8)" /></td>
							  </tr>
							  
							  <tr  id="row9" style=" display:none;">
							  <td align="center">
									<select class="form-control" name="species9" id="species9" onchange="getStrain(this.value,9)" >
										<option value="">Select</option>											
									</select>
								</td>
								<td align="left" ><label>
								  <select class="form-control" name="strain9" id="strain9" >
								  <option value="">Select</option>
								  
									</select>
								</label></td>
								<td align="center" ><label>
								  <select  class="form-control" name="sex9" id="sex9">
								  <option value="Any" selected="selected">Any</option>
									<option value="Male">Male</option>
									<option value="Female">Female</option>
								  </select>
								</label></td>
								<td align="center" ><label>
								  <input class="form-control" name="no_of_an9"  type="number"  min="1" id="no_of_an9"   />
								</label></td>
								<!--<td align="center" ><input class="form-control" name="iso9" type="text" readonly="true" id="iso9"  /></td> -->
								<td align="center" ><input pattern="[0-9A-Za-z ]*" title="Special characters are not allowed" class="form-control" name="age9" type="text" id="age9"/></td>
								<td align="center" ><label>
								  <input  class="form-control" name="issueyear9"  type="number"  min="1" id="issueyear9"  />
								</label></td>
								<td width="6%" ><img src="images/close.jpg" alt="close" width="20" height="20" id="close9" style="cursor:pointer; display:none;" onclick="Close(9)" /></td>
							  </tr>
							  
							  <tr  id="row10" style=" display:none;">
							  <td align="center">
									<select class="form-control" name="species10" id="species10" onchange="getStrain(this.value,10)" >
										<option value="">Select</option>											
									</select>
								</td>
								<td align="left" ><label>
								  <select class="form-control" name="strain10" id="strain10" >
									<option value="">Select</option>
									
									</select>
								</label></td>
								<td align="center" ><label>
								  <select  class="form-control" name="sex10" id="sex10">
								  <option value="Any" selected="selected">Any</option>
									<option value="Male">Male</option>
									<option value="Female">Female</option>
								  </select>
								</label></td>
								<td align="center" ><label>
								  <input class="form-control" name="no_of_an10"  type="number"  min="1" id="no_of_an10"   />
								</label></td>
								<!--<td align="center" ><input class="form-control" name="iso10" readonly="true" type="text" id="iso10"  /></td> -->
								<td align="center" ><input pattern="[0-9A-Za-z ]*" title="Special characters are not allowed" class="form-control" name="age10" type="text" id="age10"/></td>
								<td align="center" ><label>
								  <input  class="form-control" name="issueyear10"  type="number"  min="1" id="issueyear10"  />
								</label></td>
								<td width="6%" ><img src="images/close.jpg" alt="close" width="20" height="20" id="close10" style="cursor:pointer; display:none;" onclick="Close(10)" /></td>
							  </tr>
							  <tr><td colspan="7">
							  <div id="addRow" class="addrow">ADD</div>
							  </tr></td>
		</tbody>
	</table>
</div>