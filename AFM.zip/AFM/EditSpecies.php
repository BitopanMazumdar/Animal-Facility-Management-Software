<?php include "include/sesionlauth.php"; ?>
 <?php 
	$oldsp=filter_var($_GET['oldsp'], FILTER_SANITIZE_STRING);
	$newsp=filter_var($_GET['newsp'], FILTER_SANITIZE_STRING);
	$newsp=trim($newsp);
	if($newsp != ""){
		include "Dbconnect.php";
		$sqlck="SELECT Species FROM animals WHERE Species= '$newsp'";
		$resultck = mysqli_query($db, $sqlck);
		if(!$resultck){
			 $_SESSION['message']="Fail to add  ! contact admin";
			echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=HouseAnimals.php\">";
			die('Error: ' . mysqli_error($db));
		}else{
			if($passck = mysqli_fetch_array($resultck,MYSQLI_ASSOC)){
				
				//$_SESSION['message']="Not edited, Species:  $newsp already exist ! ";
				echo "Not edited, Species:  $newsp already exist ! ";
			}else{
				
				mysqli_query($db,"UPDATE animals SET Species='$newsp' WHERE Species='$oldsp'" );
				$result = mysqli_affected_rows($db);
				if($result >=0){
					//$_SESSION['message']="Species: ".$oldsp." is Successfully edited to: ".$newsp;
					//echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=HouseAnimals.php\">";
					mysqli_query($db,"UPDATE census SET Species='$newsp' WHERE Species='$oldsp'" );
					$resultCen = mysqli_affected_rows($db);
					if($resultCen >=0){
						$_SESSION['message']="Species: ".$oldsp." is Successfully edited to: ".$newsp;
						//echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=HouseAnimals.php\">";
						
					}else{
						$_SESSION['message']="Fail to edit ! contact admin  !";
						//echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=HouseAnimals.php\">";
					}
					
				}else{
					$_SESSION['message']="Fail to edit  ! contact admin  !";
					//echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=HouseAnimals.php\">";
				}
				
			}
		}
		
		
		//mysqli_free_result($result);
		mysqli_close($db);
	}else{
		$_SESSION['message']="Invalid input data";
		//echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=HouseAnimals.php\">";
	}
		
	?>