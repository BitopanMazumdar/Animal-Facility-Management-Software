<?php include "include/sesionlauth.php"; ?>
<?php 
	include "DBconnect.php";
	//client(name, clientID, cType, status, mobile1, mobile2, phone1, phone2, email1, email2, region, cState, city, adderss, pin, cRegNum, cRdate)	
	$result = mysqli_query($db,"SELECT DISTINCT cType FROM client");
	
	$str = "<option value=\"\">Select</option>";
	while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
		
		$str = $str ."<option value=\"".$pass['cType']."\">".$pass['cType']."</option>";
				
	}
	
	echo $str;
	mysqli_free_result($result);
	mysqli_close($db);
		
	?>