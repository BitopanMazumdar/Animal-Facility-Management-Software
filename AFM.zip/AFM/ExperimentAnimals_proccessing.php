<?php include "include/sesionlauth.php"; ?>

<?php 

	$species=filter_var($_POST['species'], FILTER_SANITIZE_STRING);
	$strain=filter_var($_POST['strain'], FILTER_SANITIZE_STRING);
	$stock=filter_var($_POST['stock'], FILTER_SANITIZE_STRING);
	$qm=filter_var($_POST['qm'], FILTER_SANITIZE_STRING);
	$qf=filter_var($_POST['qf'], FILTER_SANITIZE_STRING);
	$edate=filter_var($_POST['edate'], FILTER_SANITIZE_STRING);

if($species!="" && $edate!=""){

	include "DBconnect.php" ;

	$sql="INSERT INTO `experimentanimal`(`Species`,`strain`,`MALE`,`Female`,`ExpeirmentDate`) values ('$species', '$strain', '$qm', '$qf', '$edate')";

	$Result = mysqli_query($db, $sql);
	if(!$Result)
	  {
		$_SESSION['message']="Error ! Contact admin  !";
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=ExperimentAnimals.php">';
		die('Error: ' . mysqli_error($db));
	  }
	else
	{
		$_SESSION['message']="Successfully added data !";
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=ExperimentAnimals.php">';
	}
	mysqli_close($db);
}else{
	$_SESSION['message']="Invalid input data !";
	echo '<META HTTP-EQUIV="Refresh" Content="0; URL=ExperimentAnimals.php">';
}

?>
