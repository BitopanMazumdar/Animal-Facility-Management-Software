<?php include "include/sesionlauth.php"; ?>
 <?php 
	$stock = filter_var($_GET['sd'], FILTER_SANITIZE_STRING);
	$str="<div class=\"panel-heading\">
				<h4><button type=\"button\" class=\"btn btn-danger\" onclick=\"javascript:printDiv()\" ><i class=\"fa fa-btn fa-print\"></i> Print</button>
				<span class=\"text-primary\" >&nbsp;&nbsp;&nbsp;&nbsp;	Current Animal House Status</span></h4>
			</div>

			<div class=\"panel-body  table-responsive\" id=\"printdiv\">
				<table class=\"table table-bordered table-hover\">
				<thead>
					<th width=\"24%\" align=\"left\" ><strong>Species</strong></th>
					<th width=\"25%\" align=\"left\" ><strong>Strain</strong></th>
					<th width=\"21%\" align=\"center\" ><strong>Stock Type </strong></th>
					<th width=\"15%\" align=\"center\" ><strong>Male/Female </strong></th>
					<th width=\"15%\" align=\"center\" ><strong>Total Animals  </strong></th>
					
				</thead>
				<tbody>";
	if($stock!=""){
		include "DBconnect.php";
	
			//census(CensusID, Species, strain, StockType, Male, Female)
			
			$query= "SELECT Species, strain, StockType, Male, Female FROM census WHERE StockType='$stock' ";
			
			$result = mysqli_query($db,$query);
			$i=1; 
			if($result){
				while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
					$str=$str. "<tr bgcolor=\"#FFFFFF\">";							
					$str=$str. "<td >".$pass['Species']. "</td>";
					$str=$str. "<td >".$pass['strain']. "</td>";
					$str=$str. "<td >" .$pass['StockType']. "</td>";
					$str=$str. "<td >".$pass['Male']." + " .$pass['Female']."</td>";
					$total= $pass['Male'] + $pass['Female'];
					$str=$str. "<td >".$total. "</td>";
					$str=$str."</tr>";
					$i=$i+1;
				}
				if ($i== 1){
					$str=$str. "<tr><td colspan=\"5\" class=\"table-text text-danger\"><div>*No Records found</div></td></tr>";
				}	
				
				mysqli_free_result($result);
			}else{
				$str=$str. "<tr><td colspan=\"5\" class=\"table-text text-danger\"><div>*Error, Contact Admin.</div></td></tr>";
			}
			mysqli_close($db);
		}else{
			$str=$str. "<tr><td colspan=\"5\" class=\"table-text text-danger\"><div>*Error, Contact Admin.</div></td></tr>";
		}	
				
		$str=$str."</tbody>
			</table>
		</div>
	</div>";
	echo $str;
	?>