<div class="table-responsive">
	<table class="table anspecification" width="70%" border="0" align="center" cellpadding="5" cellspacing="1">
		<input type="hidden" id="row_no"  class="form-control" name="row_no" value="1" />
		  <tr  id="row1">
			<th width="15%"  align="center" > Species </th>
			<th width="15%"  align="center" >Strain</th>
			<th width="15%" align="center" >Stock Type </th>
			<th width="15%" align="center" >Male</th>
			<th width="15%" align="center" >Female</th>
			<th width="8%" >&nbsp;</th>
		  </tr>
		  
		  <tr  id="row1">
			<td align="center"><select class="form-control" name="species1" id="species1" onchange="getStrain(this.value,1)" required>
			  <option value="">Select</option>
							
						  </select>
						  </td>
			<td align="center" id="selstrain1"><select class="form-control" name="strain1" id="strain1">
			  <option value="">Select</option>
			</select></td>
			
			<td width="12%" align="center">
			  <select required class="form-control" name="stock1" id="stock1" >
				<option value="">Select</option>
						 <option value="Breeding Pair">Breeding Pair</option>
				<option value="Issue Stock">Issue Stock</option>
					  </select>            </td>
			 <td align="center"><input class="form-control" name="qm1" type="number"  min="0" class="male" id="qm1"  onchange="malenumber(this.value,1);" /></td>
			<td align="center"><input class="form-control" name="qf1" type="number"  min="0" class="male" id="qf1"  onchange="femalenumber(this.value,1);" /></td>
			<td width="6%">&nbsp;</td>
		  </tr>
		  <tr  id="row2" style=" display:none;">
			<td align="center"><select class="form-control" name="species2" id="species2" onchange="getStrain(this.value,2)">
			  <option value="">Select</option>
							
						  </select></td>
			<td align="center" id="selstrain2"><select class="form-control" name="strain2" id="strain2"  >
			  <option value="">Select</option>
			</select></td>
			
			<td width="12%" align="center">
			  <select class="form-control" name="stock2" id="stock2" onchange="CheckDuplicate(2);" >
				<option value="">Select</option>
								<option value="Breeding Pair">Breeding Pair</option>
								<option value="Issue Stock">Issue Stock</option>
							  </select>            </td>
			<td align="center"><input class="form-control" name="qm2" type="number"  min="0" class="male" id="qm2"  onchange="malenumber(this.value,2);" /></td>
			<td align="center"><input class="form-control" name="qf2" type="number"  min="0" class="male" id="qf2" onchange="femalenumber(this.value,2);" /></td>
			<td width="6%"><img id="close2" style="cursor:pointer; display:none;" onclick="Close(2)" src="images/close.jpg" width="20" height="20" /></td>
		  </tr>
		  <tr  id="row3" style=" display:none;">
			<td align="center"><select class="form-control" name="species3" id="species3" onchange="getStrain(this.value,3)">
			  <option value="">Select</option>
							
						  </select></td>
			<td align="center" id="selstrain3"><select class="form-control" name="strain3" id="strain3" >
			  <option value="">Select</option>
			</select></td>
			
			<td width="12%" align="center">
			  <select class="form-control" name="stock3" id="stock3" onchange="CheckDuplicate(3);" >
				<option value="">Select</option>
								<option value="Breeding Pair">Breeding Pair</option>
								<option value="Issue Stock">Issue Stock</option>
							  </select>            </td>
			<td align="center"><input class="form-control" name="qm3" type="number"  min="0" class="male" id="qm3"  onchange="malenumber(this.value,3);" /></td>
			<td align="center"><input class="form-control" name="qf3" type="number"  min="0" class="male" id="qf3"  onchange="femalenumber(this.value,3);" /></td>
			<td width="6%"><img id="close3" style="cursor:pointer; display:none;" onclick="Close(3)" src="images/close.jpg" width="20" height="20" /></td>
		  </tr>
		  <tr  id="row4" style=" display:none;">
			<td align="center"><select class="form-control" name="species4" id="species4" onchange="getStrain(this.value,4)">
			  <option value="">Select</option>
						   
						  </select></td>
			<td align="center" id="selstrain4"><select class="form-control" name="strain4" id="strain4" >
			  <option value="">Select</option>
			</select></td>
			
			<td width="12%" align="center">
			  <select class="form-control" name="stock4" id="stock4" onchange="CheckDuplicate(4);" >
				<option value="">Select</option>
								<option value="Breeding Pair">Breeding Pair</option>
								<option value="Issue Stock">Issue Stock</option>
							  </select>            </td>
			<td align="center"><input class="form-control" name="qm4" type="number"  min="0" class="male" id="qm4" onchange="malenumber(this.value,4);"  /></td>
			<td align="center"><input class="form-control" name="qf4" type="number"  min="0" class="male" id="qf4" onchange="femalenumber(this.value,4);" /></td>
			<td width="6%"><img id="close4" style="cursor:pointer; display:none;" onclick="Close(4)" src="images/close.jpg" width="20" height="20" /></td>
		  </tr>
		  <tr  id="row5" style=" display:none;">
			<td align="center"><select class="form-control" name="species5" id="species5" onchange="getStrain(this.value,5)">
			  <option value="">Select</option>
			  
						  </select></td>
			<td align="center" id="selstrain5"><select class="form-control" name="strain5" id="strain5"  >
			  <option value="">Select</option>
			</select></td>
		   
			<td width="12%" align="center">
			  <select class="form-control" name="stock5" id="stock5" onchange="CheckDuplicate(5);">
				<option value="">Select</option>
								<option value="Breeding Pair">Breeding Pair</option>
								<option value="Issue Stock">Issue Stock</option>
							  </select></td>
			 <td align="center"><input class="form-control" name="qm5" type="number"  min="0" class="male" id="qm5" onchange="malenumber(this.value,5);"  /></td>
			<td align="center"><input class="form-control" name="qf5" type="number"  min="0" class="male" id="qf5" onchange="femalenumber(this.value,5);" /></td>				  
			<td width="6%"><img id="close5" style="cursor:pointer; display:none;" onclick="Close(5)" src="images/close.jpg" width="20" height="20" /></td>
		  </tr>
			<tr  id="row6" style=" display:none;">
			<td align="center"><select class="form-control" name="species6" id="species6" onchange="getStrain(this.value,6)">
			  <option value="">Select</option>
						   
						  </select></td>
			<td align="center" id="selstrain6"><select class="form-control" name="strain6" id="strain6"  >
			  <option value="">Select</option>
			</select></td>
			
			<td width="12%" align="center">
			  <select class="form-control" name="stock6" id="stock6" onchange="CheckDuplicate(6);">
				<option value="">Select</option>
								<option value="Breeding Pair">Breeding Pair</option>
								<option value="Issue Stock">Issue Stock</option>
							  </select></td>
			<td align="center"><input class="form-control" name="qm6" type="number"  min="0" class="male" id="qm6" onchange="malenumber(this.value,6);"  /></td>
			<td align="center"><input class="form-control" name="qf6" type="number"  min="0" class="male" id="qf6" onchange="femalenumber(this.value,6);" /></td>						
			<td width="6%"><img id="close6" style="cursor:pointer; display:none;" onclick="Close(6)" src="images/close.jpg" width="20" height="20" /></td>
		  </tr>
		  <tr  id="row7" style=" display:none;">
			<td align="center"><select class="form-control" name="species7" id="species7" onchange="getStrain(this.value,7)">
			  <option value="">Select</option>
							
						  </select></td>
			<td align="center" id="selstrain7"><select class="form-control" name="strain7" id="strain7" >
			  <option value="">Select</option>
			</select></td>
			
			<td width="12%" align="center">
			  <select class="form-control" name="stock7" id="stock7" onchange="CheckDuplicate(7);">
				<option value="">Select</option>
								<option value="Breeding Pair">Breeding Pair</option>
								<option value="Issue Stock">Issue Stock</option>
							  </select>           </td>
			<td align="center"><input class="form-control" name="qm7" type="number"  min="0" class="male" id="qm7" onchange="malenumber(this.value,7);"  /></td>
			<td align="center"><input class="form-control" name="qf7" type="number"  min="0" class="male" id="qf7" onchange="femalenumber(this.value,7);" /></td>
			<td width="6%"><img id="close7" style="cursor:pointer; display:none;" onclick="Close(7)" src="images/close.jpg" width="20" height="20" /></td>
		  </tr>
		  <tr>
			<td colspan="6">
				<div id="addRow" class="addrow">ADD
				</div>
			</td>
		 </tr>
	</table>
</div>					