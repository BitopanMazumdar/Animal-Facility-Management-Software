<?php include "include/sesionlauth.php"; ?>

<?php 
$type=filter_var($_POST['type'], FILTER_SANITIZE_STRING);
$ftenure=filter_var($_POST['ftenure'], FILTER_SANITIZE_STRING);
$ttenure=filter_var($_POST['ttenure'], FILTER_SANITIZE_STRING);
	$name=filter_var($_POST['name'], FILTER_SANITIZE_STRING);
	$e=filter_var($_POST['email'], FILTER_SANITIZE_STRING);
	$phone=filter_var($_POST['phone'], FILTER_SANITIZE_STRING);
	$mobile=filter_var($_POST['mb'], FILTER_SANITIZE_STRING);
	$add=filter_var($_POST['add'], FILTER_SANITIZE_STRING); 
	$pin=filter_var($_POST['pin'], FILTER_SANITIZE_STRING);
if($e!=""){
	include "DBconnect.php";
	 
	//INSERT INTO cpcseanominee(Ctype, CName, Ftenure, Ttenure, CEmail, CPhone, CMobile, CAddress, Cpin) VALUES 
	$sql= "INSERT IGNORE  INTO cpcseanominee(Ctype, CName, Ftenure, Ttenure, CEmail, CPhone, CMobile, CAddress, Cpin) VALUES  ('$type','$name','$ftenure','$ttenure','$e','$phone','$mobile','$add','$pin')";

	$result = mysqli_query($db,$sql);


		if(!$result){
			
			$_SESSION['message']="Database error, contact admin  !";
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=CNominee.php">';
			die('Error: ' . mysqli_error($db));
		}else{
				$_SESSION['message']="successful saved  !";
				
				echo '<META HTTP-EQUIV="Refresh" Content="0; URL=CNominee.php">';
		}
	mysqli_close($db);
}else{
				
		$_SESSION['message']="Invalid Email !";
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=CNominee.php">';
	}
?>
