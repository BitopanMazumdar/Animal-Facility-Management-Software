<?php include "include/sesionlauth.php"; ?>
<?php 

//session_start();

$species=filter_var($_POST['species'], FILTER_SANITIZE_STRING);
$strain = filter_var($_POST['strain'], FILTER_SANITIZE_STRING);
$strain=trim($strain);
if($species!="" && $strain!=""){

		include "DBconnect.php";
		$sqlck="SELECT Species, strain FROM animals WHERE strain= '$strain'";
		$resultck = mysqli_query($db, $sqlck);
		if(!$resultck){
			 $_SESSION['message']="Fail to add  ! contact admin";
			echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=AddStrain.php?species=".str_replace (' ', '%20',$species)."\">";
			die('Error: ' . mysqli_error($db));
		}else{
			if($passck = mysqli_fetch_array($resultck,MYSQLI_ASSOC)){
				$sp=$passck['Species'];
				$_SESSION['message']="Not Added, Strain:  $strain of species: $sp already exist ! ";
				echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=AddStrain.php?species=".str_replace (' ', '%20',$species)."\">";
			}else{
				$flag=0;
				$sql="";
				$sql1="SELECT strain FROM animals WHERE Species= '$species'";
				$result1 = mysqli_query($db, $sql1);
				if(!$result1)
				  {
					 $_SESSION['message']="Fail to add  ! contact admin";
					echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=AddStrain.php?species=".str_replace (' ', '%20',$species)."\">";
					die('Error: ' . mysqli_error($db));
				  }else{
					while($pass1 = mysqli_fetch_array($result1,MYSQLI_ASSOC)){
						$st= $pass1['strain'];
						if($st==""){
							$flag=1;
							$sql="UPDATE animals SET strain='$strain' WHERE Species='$species' AND strain='$st'";
						}
					}
					if($flag==0){
						$sql="INSERT IGNORE INTO animals(Species, strain ) values ('$species', '$strain')";
					}		
					mysqli_query($db, $sql);
					$Result = mysqli_affected_rows($db);
					if($Result >= 0)
					  {
						  $_SESSION['message']="Succssesfully added new strain  !";
						echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=AddStrain.php?species=".str_replace (' ', '%20',$species)."\">";
						 
					  }
					else
					{
						$_SESSION['message']="Fail to add  ! contact admin";
						echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=AddStrain.php?species=".str_replace (' ', '%20',$species)."\">";
						die('Error: ' . mysqli_error($db));			
					}
					
				}
			}
		}
		  
		  
		
		mysqli_close($db);
}else{
	$_SESSION['message']="Fail to add  ! Invalid input.";
	echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=AddStrain.php?species=".str_replace (' ', '%20',$species)."\">";
}

?>

