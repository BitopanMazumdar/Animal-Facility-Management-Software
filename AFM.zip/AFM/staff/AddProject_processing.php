<?php include "include/sesionlauth.php"; ?>

<?php 

$pcode=filter_var($_POST['code'], FILTER_SANITIZE_STRING);
$pname=filter_var($_POST['name'], FILTER_SANITIZE_STRING);
$pi=filter_var($_POST['pi'], FILTER_SANITIZE_STRING);
$doa=filter_var($_POST['doa'], FILTER_SANITIZE_STRING);
$dfrom=filter_var($_POST['dfrom'], FILTER_SANITIZE_STRING);
$dto=filter_var($_POST['dto'], FILTER_SANITIZE_STRING);
$piemail=filter_var($_POST['email'], FILTER_SANITIZE_STRING);
$rowno= filter_var($_POST['row_no'], FILTER_SANITIZE_STRING);

//echo "I m here........";
//echo $rowno;
for($i=1; $i<=$rowno; $i++){
	/*${'species'.$i} =filter_var($_POST[{'species'.$i}], FILTER_SANITIZE_STRING); 
	
	${'strain'.$i}=filter_var($_POST[{'strain'.$i}], FILTER_SANITIZE_STRING);
	${'gender'.$i}=filter_var($_POST[{'sex'.$i}], FILTER_SANITIZE_STRING);
	${'age'.$i}=filter_var($_POST[{'age'.$i}], FILTER_SANITIZE_STRING);
	${'iso'.$i}=filter_var($_POST[{'iso'.$i}], FILTER_SANITIZE_STRING);
	${'noa'.$i}=filter_var($_POST[{'no_of_an'.$i}], FILTER_SANITIZE_STRING); */
	
	
$strain[$i]=filter_var($_POST['strain'.$i], FILTER_SANITIZE_STRING);
$gender[$i]=filter_var($_POST['sex'.$i], FILTER_SANITIZE_STRING);
$age[$i]=filter_var($_POST['age'.$i], FILTER_SANITIZE_STRING);
//$iso[$i]=filter_var($_POST['iso'.$i], FILTER_SANITIZE_STRING);
$noa[$i]=filter_var($_POST['no_of_an'.$i], FILTER_SANITIZE_STRING);
}
$flag=0;

	include "DBconnect.php";  
	//INSERT INTO projects(ProjectCode, ProjectName, PrincipalInvestigator, ApprovalDate, FromDate, ToDate, PiEmail, created_at, updated_at, author) VALUES
			$sql1="INSERT INTO projects(ProjectCode, ProjectName, PrincipalInvestigator, ApprovalDate, FromDate, ToDate, PiEmail, created_at, updated_at, author) values ('$pcode', '$pname', '$pi', '$doa', '$dfrom', '$dto','$piemail',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,'$pie')";

			$result1 = mysqli_query($db, $sql1);
			
			if(!$result1)
			  {
				$flag=0;
				$_SESSION['message']="Error ! Contact admin  !";
				echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=AddProject.php\">";
				die('Error: ' . mysqli_error($db));
			  }
			  else{

				for($i=1; $i<=$rowno; $i++){
					$sql2="INSERT INTO projectanimal (ProjectCode,SpStrain, Gender,Weight_Age,NoAnimal) values ('$pcode','$strain[$i]','$gender[$i]', '$age[$i]', '$noa[$i]')";
					$result2 = mysqli_query($db, $sql2);
					if(!$result2)
					  {	
						$_SESSION['message']="Error ! Contact admin  !";
						echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=AddProject.php\">";
						die('Error: ' . mysqli_error($db));
					  }
					else
					{
						$flag=1;
					}
				}
			  }
			
		if($flag==1){
				$_SESSION['message']="Succesfully submitted  !";
				echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=AddProject.php\">";
			  
		}
		else{
			$sql3="DELET FROM projects WHERE ProjectCode=$code";

			$result3 = mysqli_query($db, $sql3);
			
			if(!$result3)
			  {
				$_SESSION['message']="Error ! Contact admin  !";
				echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=AddProject.php\">";
				die('Error: ' . mysqli_error($db));
			  }
			 $_SESSION['message']="Error ! Contact admin  !";
			echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=AddProject.php\">";
		}

mysqli_close($db);

?>
