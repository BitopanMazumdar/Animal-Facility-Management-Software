<?php include "include/sesionlauth.php"; ?>

<?php 
$sdate=filter_var($_POST['sdate'], FILTER_SANITIZE_STRING);
$SupplyTo=filter_var($_POST['bname'], FILTER_SANITIZE_STRING);
$billno=filter_var($_POST['billno'], FILTER_SANITIZE_STRING);
$SupplyFrom=filter_var($_POST['sname'], FILTER_SANITIZE_STRING);
$idate=filter_var($_POST['idate'], FILTER_SANITIZE_STRING);
$iaecno=filter_var($_POST['iaecno'], FILTER_SANITIZE_STRING);
$rowno= filter_var($_POST['row_no'], FILTER_SANITIZE_STRING);


for($i=1; $i<=$rowno; $i++){
$species[$i]=filter_var($_POST['species'.$i], FILTER_SANITIZE_STRING);
$strain[$i]=filter_var($_POST['strain'.$i], FILTER_SANITIZE_STRING);
$qm[$i]=filter_var($_POST['qm'.$i], FILTER_SANITIZE_STRING);
$qf[$i]=filter_var($_POST['qf'.$i], FILTER_SANITIZE_STRING);
$stock[$i]=filter_var($_POST['stock'.$i], FILTER_SANITIZE_STRING);
}
$flag=0;
if($sdate!="" && $SupplyTo!="" && $SupplyFrom!=""){
	include "DBconnect.php";
		////fsale(SaleID, Saledate, Scode, Bcode, IEACdate, IAECno, BillNo) 
		$sql1="INSERT INTO fsale (Saledate, Scode, Bcode, IEACdate, IAECno, BillNo) values ('$sdate', '$SupplyFrom','$SupplyTo', '$idate','$iaecno','$billno')";

		$result1 = mysqli_query($db, $sql1);
		
		if(!$result1)
		  {
			$flag=0;
			$_SESSION['message']="Error ! Contact admin  !";
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=FormE.php">';
			die('Error: ' . mysqli_error($db));
		  }
		  else{
			
			$s="select MAX(SaleID) AS sale FROM fsale";
				$r = mysqli_query($db, $s);
				if(!$r){
					$flag=0;
					$_SESSION['message']="Error ! Contact admin  !";
					echo '<META HTTP-EQUIV="Refresh" Content="0; URL=FormE.php">';
					die('Error: ' . mysqli_error($db));
				 }else{
					if($p=mysqli_fetch_array($r,MYSQLI_ASSOC)){
						$sid=$p['sale'];
						for($i=1; $i<=$rowno; $i++){
							$sql2="INSERT INTO sanimal(SaleID, Species, strain, StockType, MALE, Female) values ('$sid','$species[$i]','$strain[$i]','$stock[$i]','$qm[$i]','$qf[$i]')";
							
							$result2 = mysqli_query($db, $sql2);
							if(!$result2){	
								$_SESSION['message']="Error ! Contact admin  !";
								echo '<META HTTP-EQUIV="Refresh" Content="0; URL=FormE.php">';
								die('Error: ' . mysqli_error($db));
							  }
							else{
								$flag=1;
							}
						}
					}else{
						$flag=0;
						$_SESSION['message']="Error ! Contact admin  !";
						echo '<META HTTP-EQUIV="Refresh" Content="0; URL=FormE.php">';
						die('Error: ' . mysqli_error($db));
					}
				 }
			}
		
	if($flag==1){
		$_SESSION['message']="Succesfully submitted  !";
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=FormE.php">';		  
	}
	else{
		$sql1="DELET FROM fsale WHERE SaleID='$sid'";

		$result1 = mysqli_query($db, $sql1);
		
		if(!$result1)
		  {
			//$flag=0;
			$_SESSION['message']="Error ! Contact admin  !";
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=FormE.php">';
			die('Error: ' . mysqli_error($db));
		  }
		$_SESSION['message']="Error ! Please enter details properly or contact admin if error persist !";
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=FormE.php">';
	}

mysqli_close($db);
}else{
	$_SESSION['message']="Invalid input data !";
	echo '<META HTTP-EQUIV="Refresh" Content="0; URL=FormE.php">';
}
?>
