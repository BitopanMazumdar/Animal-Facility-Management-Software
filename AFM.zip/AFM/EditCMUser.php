<?php include "include/sesionlauth.php"; ?>
 
<?php 
//users(FName,LName,EmailID,Contact,UserType)
$email=filter_var($_POST['user'], FILTER_SANITIZE_STRING);

if($email!=""){
include"DBconnect.php";
	//cpcseanominee(Ctype, CName, CEmail, CPhone, CMobile, CAddress, Cpin)
	$result = mysqli_query($db,"SELECT DISTINCT Ctype, CName, CEmail, CPhone, CMobile, CAddress, Cpin FROM cpcseanominee WHERE CEmail='$email'");
	if($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
	?>
	<?php include "include/sesionlauth.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  <link rel="stylesheet" href="css/custom.css">
  
</head>
<body style="background-color:#F8F9FA">
<nav >
 <div class="container-fluid">
	<?php 
	include"include/headerboot.php"; 
	?>
  </div>
  <div class="container-fluid">
	<?php 
	include"include/MenuAi.php"; 
	?>		
  </div> 
</nav>
	<div>&nbsp;</div>

<script type="text/javascript">
$(document).ready(function(){
	$("#displaydiv").slideDown("slow");
});
</script>

<script type="text/javascript">
document.getElementById("email").onchange = function() {checkEmail()};
function checkEmail(){	
	var mail = document.getElementById('email').value;
	
	$.get("email_query.php",{mailid:mail}, function(data, status){
		 if(data==1){
			//$("#emailok").hide();
			 document.getElementById("emailexist").innerHTML = "Email Already exsist  !";
			 //document.getElementById('emailexist').innerHTML("<div>Email Already exsist!</div>");
			//document.getElementById("emailexist").show();
			 //document.getElementById('email').value("");
			 $("#emailexist").slideDown("slow");
			 $("#email").val("");
		 }else{
			 $("#emailexist").hide();
			 //document.getElementById('emailok').innerHTML="<img src='images/right.jpg' alt='Email ok' height='10' width='32' />";
			 //$("#emailok").slideDown("slow");
		 }
	});
	
}
</script>
<script language="javascript" type="text/javascript" >
	function valid()
	{
		frm = document.regform;
		var patt = /[%*+;<=>^]/;
		  if(frm.type.value =="")
		  {
				alert("Please enter the type of user ! ");
				frm.type.focus();
				return false;
		  }	
		  if(frm.name.value =="")
		  {
				alert("Please enter the Name ! ");
				frm.name.focus();
				return false;
		  }
		  if(frm.email.value =="")
		  {
				alert("Please enter the Email Id/User Id ! ");
				frm.email.focus();
				return false;
		  }
		  
		
		if(patt.test(frm.add.value)){
				alert("invalid address input ! special characters: %*+;<=>^ are not allowed");
				frm.add.focus();
				return false;
		}
		  		  
		   
		  r=confirm("confirm submission!");
		  if(r==true){
			  return true;
		  }else{
			  frm.name.focus;
			  return false;
		  }
		   
	}
</script>
	
	<div class="container" id="displaydiv" style="display:none">
		<div class="panel panel-default col-sm-10 col-sm-offset-1">
			<div class="panel-heading">
				<h4 class="text-primary"><i class="fa fa-user-plus "></i>  EDIT CPCSEA Nominee</h4>
			</div>
		  
		  <div class="panel-body">
       <form class="form-horizontal"  action="EditCNRegistration.php" name="myform" id="myform" method="post" onsubmit="return valid();"> 
        
        <!-- submit message -->
					<?php 
						
							if(isset($_SESSION['message'])){
								echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
								unset($_SESSION['message']);
							}
												
					?>
		<!-- submit message -->
			<div class="form-group">
				<label for="type" class="col-sm-3 control-label"><span style="color: red">*</span>User Type:</label>
				<div class="col-sm-6">
					<select class="form-control" required readonly id="type" name="type" > 
					<option value="<?php echo htmlspecialchars($pass['Ctype']); ?>" selected="Select"> <?php echo htmlspecialchars($pass['Ctype']); ?> </option>
											
					</select>
				</div>
			</div>
			<div class="form-group">
				<label for="name" class="col-sm-3 control-label"><span style="color: red">*</span>Name:</label>
				<div class="col-sm-6">
					<input class="form-control" required style="text-transform: capitalize;" pattern="[A-Za-z\s]*" title="Special characters and digit not allowed" name="name" type="text" id="name" placeholder="Enter name" value="<?php echo htmlspecialchars(htmlspecialchars($pass['CName'])); ?>" />
				</div>
			</div>
			<input readonly name="cemail" type="hidden" id="cemail" value="<?php echo htmlspecialchars($email); ?>" size="30"></td>
			<div class="form-group">
				<label for="email" class="col-sm-3 control-label"><span style="color: red">*</span>Email ID:</label>
				<div class="col-sm-6">
					<input class="form-control col-sm-6" readonly required name="email" type="email" id="email" onchange="checkEmail()"  placeholder="Enter email id" value="<?php echo htmlspecialchars($email); ?>"/> 
				<div class="alert alert-danger col-sm-4 col-sm-offset-9" id="emailexist" style="display:none"> </div>
					<!--
					<p id="emailok" style="display:none"></p>
					<div class="alert alert-success col-sm-1 col-sm-offset-9" id="emailok" style="display:none"> 
					</div>-->
				</div>
				
			</div>
			
			<div class="form-group">
				<label for="phone" class="col-sm-3 control-label">Ext/Phone:</label>

				<div class="col-sm-6">
					<input class="form-control"  type="text" name="phone" pattern="[0-9\/\+\s-]{9,}" type="tel" title="digit + - and / allowed only" id="phone" size="15" placeholder="Enter phone number" value="<?php echo htmlspecialchars($pass['CPhone']); ?>"/>
				</div>
			</div>
			<div class="form-group">
				<label for="mb" class="col-sm-3 control-label">Mobile:</label>

				<div class="col-sm-6">
					<input class="form-control" pattern="[0-9\+\s-]{9,}" title="digits + - allowed only minimum length:9 " name="mb" type="text" id="mb" size="15" placeholder="Enter mobile number" value="<?php echo htmlspecialchars($pass['CMobile']); ?>"/>
				</div>
			</div>
			
			<div class="form-group">
				<label for="add" class="col-sm-3 control-label">Address:</label>
				<div class="col-sm-6">
					<textarea class="form-control" style="text-transform: capitalize;" name="add" type="text" id="add" rows="4" cols="30" placeholder="Enter address" ><?php echo htmlspecialchars($pass['CAddress']); ?></textarea>
				</div>
			</div>
			<div class="form-group">
				<label for="pin" class="col-sm-3 control-label">Pin:</label>
				<div class="col-sm-6">
					<input class="form-control" pattern="[0-9]{6}" title="6 digit pin allowed only" name="pin" type="text" id="pin" placeholder="Enter pin number" value="<?php echo htmlspecialchars($pass['Cpin']); ?>" />
				</div>
			</div>
			
			
			<!-- Add Task Button -->
			<div class="form-group">
				<div class="col-sm-offset-5 col-sm-6">
					<button type="submit" class="btn btn-danger">
						<i class="fa fa-btn fa-edit"></i> Edit
					</button>
					<button type="submit" class="btn btn-primary" onClick="window.history.back()">
						<i class="fa fa-btn fa-arrow-left"></i> Back
					</button>
				</div>
			</div>
		</form>
    </div>
	</div>
</div>
	<div>&nbsp;</div>
	<div>&nbsp;</div>
	
	<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
	</div>
	
</body>
</html>
  
<?php 
	}
}
?> 
