<?php include "include/sesionlauth.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  <link rel="stylesheet" href="css/custom.css">
  
</head>
<body style="background-color:#F8F9FA">
<nav >
 <div class="container-fluid">
	<?php 
	include"include/headerboot.php"; 
	?>
  </div>
  <div class="container-fluid">
	<?php 
	include"include/MenuAi.php"; 
	?>		
  </div>
  <div class="container-fluid">
	<?php 
	include"include/moniRegMenu.php"; 
	?>		
  </div>
 
</nav>

<!-- Script start-->
<script type="text/javascript">
 $(document).ready(function(){
	 $("#main").slideDown("slow");
	 $.get("species_query.php", function(data, status){
	$("#species").html(data);
	
	});
	$.get("room_query.php", function(data, status){
		
    $("#room").html(data);
    });
});
</script>		
 
<script type="text/javascript">
function valid(){
	frm = document.myform;
	
	if(frm.strain.value =="" ){
		  $("#strain").css("background-color", "yellow");
	  }
	  if(frm.dob.value =="" ){
		  frm.dob.style.backgroundColor = "red";
	  }
	  if(frm.gdate.value =="")
	  {
			alert("Please select Sampling date ! ");
			frm.gdate.focus();
			return false;
	  }
	  
	  /* if(frm.room.value =="")
	  {
			alert("Please select Room ! ");
			frm.room.focus();
			return false;
	  } */
	  if(frm.species.value =="" && frm.strain.value =="" )
	  {
			alert("Please enter Species/Strain !");
			frm.species.focus();
			return false;
	  }
	  
	  if(frm.sex.value =="")
	  {
			alert("Please select Gender !");
			frm.sex.focus();
			return false;
	  }
	   if(frm.ano.value =="")
	  {
			alert("Please enter Animal No.!");
			frm.ano.focus();
			return false;
	  }
	 if(frm.sdby.value =="" )
	  {
			alert("Please enter Sample Collected By !");
			frm.sdby.focus();
			return false;
	  }
	  
	 var r = confirm("confirm submit!");
	  if (r == true) {
		return true;
	  } else {
		frm.gdate.focus();
		return false;
	  }
}
</script>		
<!-- End of validation -->
<script type="text/javascript">
function getStrain(val){
	
	$.get("strain_query.php", {sp:val}, function(data, status){
		
    $("#strain").html(data);
    });
}	
</script>

<!-- Script end-->
 
<div class="container" id="main" style="display:none">
<br>
<!-- submit message -->
	<?php 
		
		if(isset($_SESSION['message'])){
			echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
			unset($_SESSION['message']);
		}
								
	?>
<!-- submit message -->
<form class="form-horizontal" autocomplete="off" action="GeneticSampling_proccessing.php" name="myform" method="post" onSubmit="return valid();">

	<button type="button" class="btn btn-danger col-sm-offset-6" onClick="document.location.href='GSreport.php'"><i class="fa fa-btn fa-plus"></i> View Genetic Report
					</button>
	<div class="form-group" >
	<fieldset>
		<legend>Genetic Monitoring</legend>
		
		<label class="control-label"  for="mcode">Room No.<span id="red">*</span>:</label>
			<select required class="form-control" name="room" id="room" >
						<option value="">Select</option>
					</select>
		<label class="control-label" for="sdate">Sample Collection Date<span id="red">*</span>:</label>
			<input required class="form-control" name="gdate" type="date"  id="gdate" />  
		<label class="control-label" for="sdby">Sample Collected By<span id="red">*</span>:</label>
			<input required style="text-transform: capitalize;" pattern="[a-zA-Z ]*" class="form-control" name="sdby" type="text" id="sdby" />
		
	</fieldset>
	</div>
	<div class="form-group" >
	<fieldset>
		<legend>Animal Specification</legend>	
		<label class="control-label" for="species">Species<span id="red">*</span>:</label>
			<select required  class="form-control" name="species" id="species" onchange="getStrain(this.value);">
						<option value="">Select</option>
						 </select>
		<label class="control-label" for="strain">Strain<span id="red">*</span>:</label>
			 <select  id="strain" class="form-control" name="strain" >
					<option> Select </option>
			</select>
		
			
				<label class="control-label" for="sex">Gender<span id="red">*</span>:</label>
				<div class="radio">
					<label><input class="radio" name="sex" id="sex" type="radio" value="Male" checked />
				  Male</label> &nbsp;
				  <label><input class="radio" name="sex" id="sex" type="radio" value="Female"/>
				  Female</label>
				
				</div>
			<label class="control-label" for="dob">DOB<span id="red">*</span>:</label>
				<input class="form-control" name="dob" type="date"  id="dob">
			<label class="control-label" for="ano">Pedigree/Animal No.<span id="red">*</span>:</label>
			<input required  style="text-transform: capitalize;" pattern="[a-zA-Z\\0-9 .\-,/]*" class="form-control" name="ano" type="text" id="ano" />
		<div class="form-group">	
		
	</fieldset>
	</div>
		
	<!-- Add Task Button -->
	<div class="col-sm-offset-4 col-sm-6">
			<button type="submit" class="btn btn-danger">
				<i class="fa fa-btn fa-save"></i> Save
			</button>
			<button type="button" class="btn btn-primary" onclick="window.history.back()">
				<i class="fa fa-btn fa-arrow-left"></i> Back
			</button>
		</div>	
		</div>	
</form>
</div>
		
	<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
	</div>
	
</body>
</html>
