<?php include "include/sesionlauth.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  <link rel="stylesheet" href="css/custom.css">
  
</head>
<body style="background-color:#F8F9FA">
<nav >
 <div class="container-fluid">
	<?php 
	include"include/headerboot.php"; 
	?>
  </div>
  <div class="container-fluid">
	<?php 
	include"include/MenuAi.php"; 
	?>		
  </div>
  <div class="container-fluid">
	<?php 
	include"include/inventorynav.php"; 
	?>		
  </div>
 
</nav>

<!-- Script start-->
<script type="text/javascript">
$(document).ready(function(){
		$("#main").slideDown("slow");
});
</script>
<script type="text/javascript">
function getStrain(val,no)
{
	
$.get("strain_query.php",
  {
    sp:val
  },
  function(data,status){
  //sleep(1000);
 
    $("#strain"+no).html(data);
    //$("#strain"+no).css("width":"150px");
  });
}
function getSpecies(no){
	
	$.get("species_query.php", function(data, status){
		$("#species"+no).html(data);
	});
}
$(document).ready(function(){
   $("#addRow").click(function(){   
   val=$("#row_no").val();
   if(val!=7)
   {
   val++;
   getSpecies(val);
    $("#row_no").val(val);
    $("#row"+val).slideDown();
    $("#close"+val).show();
    val--;
    $("#close"+val).hide();
    }
  }); 
	 
});

function getBuyeradd(bname){
	
$.get("BuyerAdd_query.php",
  {
    bnam:bname
  },
  function(data,status){
      $("#add").val(data); 
	   $("#baddh").show();
	  });
$.get("BuyerPin_query.php",
  {
    bnam:bname
  },
  function(data,status){
      $("#pin").val(data); 
	 	 $("#bpinh").show();  
	  });
}

function Close(val)
{

 $("#row"+val).slideUp();
 val--;
 $("#row_no").val(val);
 $("#close"+val).show("slow");
 }
 
</script>

<script type="text/javascript">     
        
    $(document).ready(function(){
		
    $.get("species_query.php", function(data, status){
		$("#species1").html(data);
		
	});
	$.get("Buyer_query.php", function(data, status){
		$("#bname").html(data);
		
	});
	$.get("Supplier_query.php", function(data, status){
		$("#sname").html(data);
		
	});
});
</script>

<!-- Validation-->


<script type="text/javascript">
function valid(){
	frm = document.myform;
	no=frm.row_no.value;
		
	  if(frm.sdate.value ==""){
			alert("Please enter Supply date !");
			frm.sdate.focus();
			return false;
	  }
	  if(frm.bname.value ==""){
			alert("Please Select Buyer Code !");
			frm.bname .focus();
			return false;
	  }
	  /* if(frm.add.value =="")
	  {
			alert("Please enter Address !"); 
			frm.add.focus();
			return false;
	  }
	  if(frm.pin.value =="")
	  {
			alert("Please enter Pin !");
			frm.pin.focus();
			return false;
	  }*/
	   if(frm.bname.value =="New")
	  {
			alert("Please Register the buyer First!"); 
			//window.location.href="AnimalBuyer.php";
			return false;
	  }
	  if(frm.sname.value =="")
	  {
			alert("Please select Supplier Code !"); 
			frm.sname.focus();
			return false;
	  }
	  
	   if(frm.sname.value =="New")
	  {
			alert("Please Register the Supplier First !"); 
			//window.location.href="AnimalBuyer.php";
			return false;
	  }
	/*  if(frm.idate.value =="")
	  {
			alert("Please enter Date of the protocols against which animals sold!");
			frm.idate.focus();
			return false;
	  }
	  if(frm.iaecno.value =="")
	  {
			alert("Please enter IAEC No. of the protocols against which animals sold!");
			frm.iaecno.focus();
			return false;
	  } */
	  for(j=1;j<=no;j++)
		{
					
		  if(document.getElementById("strain" + j).value =="" && document.getElementById("species" + j).value =="")
		  {
				alert("Please enter species/starin !");
				document.getElementById("species" + j).focus();
				return false;
		  }
		  
		   if(document.getElementById("stock" + j).value =="")
		  {
				alert("Please specify Stock Type !");
				document.getElementById("stock" + j).focus();
				return false;
		  }		  
		  if(document.getElementById("qm" + j).value =="" && document.getElementById("qf" + j).value =="")
		  {
				alert("Please quantity (MALE/Female) !");
				document.getElementById("qm" + j).focus();
				return false;
		  }	 
		  		  
		}
		var flag=0;
		var r=false;
		for(j=1;j<=no;j++)
		{
			if(document.getElementById("strain" + j).value =="")
			  {
				  alert("Reminder: You have not selected Strain for row no. = "+j);
				  document.getElementById("strain" + j).focus();
				  flag=1;
			  }
		}
	  if(flag){
		  r=confirm("Confirm submission without selecting Strain !");
	  }else{
		  r=confirm("Confirm submission !");
	  }
	  if(r==true ){
		  return true;
	  }else{
		  return false;
	  }
	  
}
function malenumber(quantity,no){
	sp=$("#species"+no).val();
	st=$("#strain"+no).val();
	stock=$("#stock"+no).val();
	if(sp==""){
		alert("please select Species");
		$("#qm"+no).val(0);
		return false;
	}
	if(stock==""){
		alert("please select Stock Type");
		$("#qm"+no).val(0);
		return false;
	}
	$.get("checkmalenumber.php",{mq:quantity, sp:sp, st:st, stock:stock}, function(data, status){
		//alert(data);
		if(data==-1){
			return true;
		}else if(data==-2){
			$("#qm"+no).val(0);
			alert("stock not available in animal house! Species: "+sp+" Strain: "+st +" Stock Type: "+stock);
			return false;
		}else{
			$("#qm"+no).val(0);
			alert("Quantity is more than available stock! Available stock = "+data);
			return false;
			
		}
	});
}
function femalenumber(quantity,no){
	sp=$("#species"+no).val();
	st=$("#strain"+no).val();
	stock=$("#stock"+no).val();
	if(sp==""){
		alert("please select Species");
		$("#qf"+no).val(0);
		return false;
	}
	if(stock==""){
		alert("please select Stock Type");
		$("#qf"+no).val(0);
		return false;
	}
	$.get("checkfemalenumber.php",{fq:quantity, sp:sp, st:st, stock:stock}, function(data, status){
		//alert(data);
		if(data==-1){
			return true;
		}else if(data==-2){
			$("#qm"+no).val(0);
			alert("stock not available in animal house! Species: "+sp+" Strain: "+st +" Stock Type: "+stock);
			return false;
		}else{
			$("#qm"+no).val(0);
			alert("Quantity is more than available stock! Available stock = "+data);
			return false;
			
		}
	});
}
</script>	
<script type="text/javascript">
function CheckDuplicate(no)
{
	z=$("#row_no").val();
	for(x=1;x<=z;x++)
	{	
		if(x!=no)
		{
				
			if(($("#species"+x).val()==$("#species"+no).val()) && ($("#strain"+x).val()==$("#strain"+no).val()) && ($("#stock"+x).val()==$("#stock"+no).val())){
				$("#strain"+no).val("");
				$("#species"+no).val("");
				$("#stock"+no).val("");				
				alert("Species,Strain and stock type allready selected");
			}
				
		}
	}
}
</script>	
<!-- End of validation -->

<!-- Script end-->
 
<div class="container" id="main" style="display:none">
<br>
<!-- submit message -->
	<?php 
		
		if(isset($_SESSION['message'])){
			echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
			unset($_SESSION['message']);
		}
								
	?>
<!-- submit message -->
<form action="FormE_proccess.php" name="myform" method="post" onsubmit="return valid();">
<br>
	<button type="button" class="btn btn-danger col-sm-offset-6" onClick="document.location.href='SaleReport.php'"><i class="fa fa-btn fa-plus"></i> View Sale Report
					</button>
	<div class="form-group" id="box">
	<fieldset>
		<legend>Sale details</legend>
		<label class="control-label"  for="sdate">Sale Date<span id="red">*</span>:</label>
			<input  class="form-control" required name="sdate" type="date" id="sdate" size="15" required />
		<label class="control-label" for="mdate">Bill No<span id="red">*</span>:</label>
			<input  class="form-control" required pattern="[0-9A-Za-z/\\ -]*" name="billno" type="text" id="billno" size="15" required placeholder="Enter bill number, need for CPCSEA" />
		
	</fieldset>
	</div>
	<div class="form-group" id="box">
	<fieldset>
		<legend>Buyer</legend>
		<label class="control-label" for="species">Buyer Code<span id="red">*</span>:</label>
			<select class="form-control"  name="bname" type="text" id="bname" onchange="getBuyeradd(this.value)" required>
				<option value="">Select</option>
			</select>  
	
	<div id="baddh" style="cursor:pointer; display:none;">
	
		<label class="control-label" for="strain">Buyer Address:</label>
			<textarea class="form-control" name="add" readonly="true" type="text" id="add" rows="2" ></textarea>
		<label class="control-label" for="stock">Buyer pin<span id="red">*</span>:</label>
			<input  class="form-control" name="pin" readonly="true" type="text" id="pin" size="10" />	
	</fieldset>
	</div>
	<div class="form-group">
	<fieldset>
	<legend>Suplier</legend>
		<label class="control-label" for="qm">Supplier Code<span id="red">*</span>:</label>
			<select class="form-control" name="sname" type="text" id="sname" onchange="getSupplier(this.value)" required>
				<option value="">Select</option>
			</select>
		<label class="control-label" for="qf">IAEC Date<span id="red">*</span>:</label>
			<input  class="form-control" name="idate"  type="date" id="idate" required placeholder="Enter IAEC Date, need for CPCSEA" />
		<label class="control-label" for="qf">IAEC No.<span id="red">*</span>:</label>
			<input  class="form-control" name="iaecno" type="text" id="iaecno" size="15" pattern="[0-9A-Za-z/\\ -]*" required  placeholder="Enter IAEC Number, need for CPCSEA"/>
		
	</fieldset>
	</div>
	<div class="form-group">
	<fieldset>
	<legend>Animal details</legend>
		<?php include "anspecificationSpSt.php";?>
	</fieldset>
	</div>
	<!-- Add Task Button -->
	<div class="form-group">
	
		<div class="col-sm-offset-4 col-sm-6">
			<button type="submit" class="btn btn-danger">
				<i class="fa fa-btn fa-plus"></i> Add Sale
			</button>
			<button type="button" class="btn btn-warning" onclick="window.history.back()">
				<i class="fa fa-btn fa-arrow-left"></i> Back
			</button>
		</div>
	
	</div>
</form>
</div>
		
	<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
	</div>
	
</body>
</html>
