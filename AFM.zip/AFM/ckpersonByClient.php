<?php include "include/sesionlauth.php"; ?>
 <?php 
	$clientID= filter_var($_GET['clientID'], FILTER_SANITIZE_STRING);
	if($clientID!=""){
		include "DBconnect.php";
			//contactperson(cpId, clientID, cpName, cpDesignation, mobile1, mobile2, phone1, phone2, email1, email2, adderss)
			$query= "SELECT cpId, clientID, cpName, cpDesignation, mobile1, mobile2, phone1, phone2, email1, email2, adderss FROM contactperson WHERE clientID='$clientID'";
			$i=0;
			$result = mysqli_query($db,$query);
			$str="<div class=\"panel-heading\" id=\"ckfocus\" tabindex=\"1\">
                        <h4><span class=\"text-primary\" >Contact person, </span> <span class=\"text-danger\" >Client: $clientID</span></h4>								
                    </div>

                    <div class=\"panel-body table-responsive\">
                        <table class=\"table table-striped \">
                            <thead>
                                <th>Name</th>
								<th>Designation</th>
                                <th>Mobile</th>
								<th>Mobile2</th>
								<th>Phone</th>
								<th>Phone2</th>
								<th>Email</th>
								<th>Email2</th>
								<th>Addess</th>
								<th><button type=\"button\" class=\"btn btn-success\" onclick=\"showClient()\"><i class=\"fa fa-btn fa-arrow-circle-left\"></i> Back</button></th>
                            </thead>
                            <tbody>";
							//cpId, clientID, cpName, cpDesignation, mobile1, mobile2, phone1, phone2, email1, email2, adderss
							while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
								$str=$str."
								<tr>
									<td class=\"table-text\"><div>".$pass['cpName']."</div></td>
									<td class=\"table-text\"><div>".$pass['cpDesignation']."</div></td>
									<td class=\"table-text\"><div>".$pass['mobile1']."</div></td>
									<td class=\"table-text\"><div>".$pass['mobile2']."</div></td>
									<td class=\"table-text\"><div>".$pass['phone1']."</div></td>
									<td class=\"table-text\"><div>".$pass['phone2']."</div></td>
									<td class=\"table-text\"><div>".$pass['email1']."</div></td>
									<td class=\"table-text\"><div>".$pass['email2']."</div></td>
									<td class=\"table-text\"><div>".$pass['adderss']."</div></td>
									<!-- Task Delete Button -->
									<td>
										<form action=\"cpEdit.php\" method=\"POST\">
											<input type=\"hidden\" readonly name=\"cpId\" id=\"cpId\" value=\"".$pass['cpId']."\" />
											<button type=\"submit\" class=\"btn btn-primary\">
												<i class=\"fa fa-btn fa-edit\"></i> Edit
											</button>
										</form>
									</td>
									
								</tr>";
								$i++;
							}
							if ($i== 0){
								$str=$str. "<tr><td colspan=\"9\" class=\"table-text text-danger\"><div>*No Records found</div></td></tr>";
							}
							$str=$str."</tbody>
                        </table>
                    </div>
                </div>";
			
			//knownperson(kpId, clientID, kpName, kpDesignation, mobile1, mobile2, phone1, phone2, email1, email2, adderss)
			$query= "SELECT kpId, clientID, kpName, kpDesignation, mobile1, mobile2, phone1, phone2, email1, email2, adderss FROM knownperson WHERE clientID='$clientID'";
			$j=0;
			$result = mysqli_query($db,$query);
			$strk="<div class=\"panel-heading\">
                        <h4><span class=\"text-primary\" >Known person, </span> <span class=\"text-danger\" >Client: $clientID</span></h4>
                    </div>

                    <div class=\"panel-body table-responsive\">
                        <table class=\"table table-striped task-table\">
                            <thead>
                                <th>Name</th>
								<th>Designation</th>
                                <th>Mobile</th>
								<th>Mobile2</th>
								<th>Phone</th>
								<th>Phone2</th>
								<th>Email</th>
								<th>Email2</th>
								<th>Addess</th>
								<th><button type=\"button\" class=\"btn btn-success\" onclick=\"showClient()\"><i class=\"fa fa-btn fa-arrow-circle-left\"></i> Back</button></th>
                            </thead>
                            <tbody>";
							//cpId, clientID, cpName, cpDesignation, mobile1, mobile2, phone1, phone2, email1, email2, adderss
							//knownperson(kpId, clientID, kpName, kpDesignation, mobile1, mobile2, phone1, phone2, email1, email2, adderss)
							while($passkp=mysqli_fetch_array($result,MYSQLI_ASSOC)){
								$strk=$strk."
								<tr>
									<td class=\"table-text\"><div>".$passkp['kpName']."</div></td>
									<td class=\"table-text\"><div>".$passkp['kpDesignation']."</div></td>
									<td class=\"table-text\"><div>".$passkp['mobile1']."</div></td>
									<td class=\"table-text\"><div>".$passkp['mobile2']."</div></td>
									<td class=\"table-text\"><div>".$passkp['phone1']."</div></td>
									<td class=\"table-text\"><div>".$passkp['phone2']."</div></td>
									<td class=\"table-text\"><div>".$passkp['email1']."</div></td>
									<td class=\"table-text\"><div>".$passkp['email2']."</div></td>
									<td class=\"table-text\"><div>".$passkp['adderss']."</div></td>
									
									<!-- Task Delete Button -->
									<td>
										<form action=\"kpEdit.php\" method=\"POST\">
											<input type=\"hidden\" readonly name=\"kpId\" id=\"kpId\" value=\"".$passkp['kpId']."\" />
											<button type=\"submit\" class=\"btn btn-primary\">
												<i class=\"fa fa-btn fa-edit\"></i> Edit
											</button>
										</form>
									</td>
									
								</tr>";
								$j++;
							}
							if ($j== 0){
								$str=$str. "<tr><td colspan=\"9\" class=\"table-text text-danger\"><div>*No Records found</div></td></tr>";
							}
							$strk=$strk."<tr><td class=\"table-text\"><div><button type=\"button\" class=\"btn btn-success\" onclick=\"showClient()\"><i class=\"fa fa-btn fa-arrow-circle-left\"></i> Back</button></div></td></tr>";
							$strk=$strk."</tbody>
                        </table>
                    </div>
                </div>";
			$strcpkp=$str.$strk;
			echo $strcpkp;
			
	mysqli_free_result($result);
	mysqli_close($db);
	}else{
		$_SESSION['message']="Invalid data !";
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=viewClient.php">';
	}
?>