<?php include "include/sesionlauth.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  <link rel="stylesheet" href="css/custom.css">
  
</head>
<body style="background-color:#F8F9FA">
<nav >
 <div class="container-fluid">
	<?php 
	include"include/headerboot.php"; 
	?>
  </div>
  <div class="container-fluid">
	<?php 
	include"include/MenuAi.php"; 
	?>		
  </div>
  
</nav>
	<div>&nbsp;</div>
<script type="text/javascript">

$(document).ready(function(){
		$("#displaydiv").slideDown("slow");
		$("#userlist").hide();
		var xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = function() {
		  if (this.readyState == 4 && this.status == 200) {
			  $(document.getElementById("userlist").innerHTML = this.responseText).slideDown("slow");
			  //alert(this.responseText);
			  $("#userlist").slideDown('slow');
		  }
		};
		
		xmlhttp.open("GET", "profileByAll.php", true);
		xmlhttp.send();
});

</script>
<script language="javascript" type="text/javascript" >
	function valid(){
		frm = document.profileform;
		 if(frm.cpass.value =="")
		  {
				alert("Please enter current password !");
				frm.cpass.focus();
				return false;
		  }
		  if(frm.pass.value =="")
		  {
				alert("Please enter new password !");
				frm.pass.focus();
				return false;
		  }
		  if(frm.re_pass.value =="")
		  {
				alert("Please Re-type Password !");
				frm.re_pass.focus();
				return false;
		  }
		  if(frm.pass.value != frm.re_pass.value)
		  {
				alert("Confirm Password Does Not Match !");
				frm.pass.focus();
				return false;
		  }
		  r=confirm("confirm submission!");
		  if(r==true){
			  return true;
		  }else{
			  frm.pass.focus;
			  return false;
		  }
	}
</script>

	<div class="container" id="displaydiv" style="display:none">
        <div class="col-sm-offset-2 col-sm-8">
			<!-- submit message -->
					<?php 
						
							if(isset($_SESSION['message'])){
								echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
								unset($_SESSION['message']);
							}
												
					?>
		<!-- submit message -->
            <div class="panel panel-default">
                <div class="panel-heading" >
                   <h5 class="text-primary"> Profile Management</h5>
								
                </div>
				
                <div class="panel-body">
                    <form action="profile_process.php" name="profileform" method="POST" class="form-horizontal" onsubmit="return valid();">
					<!-- submit message -->
						<?php if(isset($_SESSION['message'])){
									echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
									unset($_SESSION['message']);
								}					
						?>
					<!-- submit message -->
						<div class="form-group">
							<label for="cpass" class="col-sm-3 control-label"><i class="fa fa-key icon"></i> <span style="color: red">*</span>Current Password:</label>
							<div class="col-sm-6">
								<input class="form-control" required name="cpass" type="password" id="cpass" size="18" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" placeholder="Enter  Current password"/>
							</div>
						</div>
						<div class="form-group">
							<label for="pass" class="col-sm-3 control-label"><span style="color: red">*</span>New Password:</label>
							<div class="col-sm-6">
								<input class="form-control" required name="pass" type="password" id="pass" size="18" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" placeholder="Enter  new password"/>
							</div>
						</div>
						
						<div class="form-group">
							<label for="re_pass" class="col-sm-3 control-label"><span style="color: red">*</span>Confirm Password:</label>
							<div class="col-sm-6">
								<input class="form-control" required name="re_pass" type="password" id="re_pass" size="18" placeholder="Enter same password"/>
							</div>
						</div>
						<div class="form-group">
                            <div class="col-sm-offset-4 col-sm-6">
                                <button type="submit" class="btn btn-success">
                                    <i class="fa fa-btn fa-key"></i>  Change password
                                </button>
								
                            </div>
                        </div>
                    </form>
                                        
                </div>
            </div>
			
		</div>
    </div>
	<div class="col-sm-12">
		<div id="userlist" class="panel panel-default">
	
		</div>
	</div>
	<div>&nbsp;</div><div>&nbsp;</div>
	<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
	</div>
</body>
</html> 
	