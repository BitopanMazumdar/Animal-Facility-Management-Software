<?php include "include/sesionlauth.php"; ?>
 <?php 
	
	$fdate = filter_var($_GET['sd'], FILTER_SANITIZE_STRING);	
	$tdate = filter_var($_GET['sd1'], FILTER_SANITIZE_STRING);	
	$str="<div class=\"panel-heading\">
				<button type=\"button\" class=\"btn btn-danger\" onclick=\"javascript:printDiv()\" ><i class=\"fa fa-btn fa-print\"></i> Print</button>
				<span class=\"text-primary\" >&nbsp;&nbsp;&nbsp;&nbsp;	List ofExperiment data</span>
			</div>

			<div class=\"panel-body  table-responsive\" id=\"printdiv\">
				<table class=\"table table-bordered table-hover\">
				<thead>
					<th width=\"14%\" align=\"center\" bgcolor=\"#CCCCCC\"><strong>Date</strong></th>
					<th width=\"32%\" align=\"left\" bgcolor=\"#CCCCCC\"><strong>Species</strong></th>
					<th width=\"22%\" align=\"left\" bgcolor=\"#CCCCCC\"><strong>Strain</strong></th>
					<th width=\"16%\" align=\"center\" bgcolor=\"#CCCCCC\"><strong>Quantity</strong></th>
					
					<th class=\"remOnPrint\" bgcolor=\"#CCCCCC\"><strong>&nbsp;</strong></th>
				</thead>
				<tbody>";	
	if($tdate != "" && $fdate != ""){
		include "DBconnect.php";
			if($tdate != $fdate)
				{$query= "SELECT * FROM experimentanimal WHERE ExpeirmentDate BETWEEN '$fdate' AND '$tdate' ORDER BY ExperimentID DESC";}
			else
			{$query= "SELECT * FROM experimentanimal WHERE ExpeirmentDate = '$tdate' ORDER BY ExperimentID DESC";}
			
			$result = mysqli_query($db,$query);
			if($result){
				$i=1; 
				while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
					$str=$str."<tr bgcolor=\"#FFFFFF\">";
					$str=$str."<td >".$pass['ExpeirmentDate']."</td>";
							
					$str=$str."<td >".$pass['Species']. "</td>";
					$str=$str."<td >".$pass['strain']. "</td>";
					$str=$str."<td >".$pass['MALE']."(M)+" .$pass['Female']."(F)</td>";
					
					$str=$str."<td class=\"remOnPrint\">
								<form action=\"EditExperiment.php\" method=\"POST\">
									<input type=\"hidden\" name=\"exno\" value=\"".$pass['ExperimentID']."\">
									<button type=\"submit\" class=\"btn btn-danger\">
										<i class=\"fa fa-btn fa-edit\"></i> Edit
									</button>
								</form>
							</td>";
					$str=$str."</tr>";
					$i=$i+1;
				}
									
				if ($i== 1){
						$str=$str. "<tr><td colspan=\"7\" class=\"table-text text-danger\"><div>*No Records found</div></td></tr>";
					}							
				mysqli_free_result($result);
			}else{
				$str=$str. "<tr><td colspan=\"7\" class=\"table-text text-danger\"><div>*Error, Contact Admin.</div></td></tr>";
			}
			mysqli_close($db);
	}else{
			$str=$str. "<tr><td colspan=\"8\" class=\"table-text text-danger\"><div>*Error, Contact Admin.</div></td></tr>";
	}
	$str=$str."</tbody>
			</table>
		</div>
	</div>";
	echo $str;
		
	?>
 