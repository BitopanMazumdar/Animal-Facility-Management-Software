<?php 
	if(session_id() == '' || !isset($_SESSION)){
							// session isn't started
							session_start();
	}
				$e=$_GET['email'];
				$pass=$_GET['code'];
								
				$msg="";
				$flag=0;
				include "DBconnect.php";
				//forgot_pass(emailId, , created_at)
			$result = mysqli_query($db,"SELECT * FROM forgot_pass WHERE emailId='$e' AND tocken='$pass'");
						
				if(!$pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
					echo "<script>alert('Invalid Email !'); window.history.go(-1);</script>";
					exit();
				}else{
					?>
					
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">  
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  
  <link rel="stylesheet" href="css/bootstrap.min.css"> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  
  <script src="jquery/bootstrap.min.js"></script>
  <script src="jquery/jquery.validate.min.js"></script>
  <script src="jquery/jquery-3.3.1.min.js"></script>
</head>
<body style="background-color:#F8F9FA">
<nav >
	  <div class="container-fluid">
		<?php 
		include"include/header1.php"; 
		?>
	  </div>
	  <div class="container-fluid">
		<?php 
		include"include/header2.php"; 
		?>
	  </div>
</nav>
<script language="javascript" type="text/javascript" >
function valid(){
	frm = document.resetpassform;
	if(frm.pass.value ==""){
		alert("Please enter Password !");
		frm.pass.focus();
		return false;
	}
	if(frm.re_pass.value ==""){
		alert("Please Re type Password !");
		frm.re_pass.focus();
		return false;
	}
	if(frm.pass.value != frm.re_pass.value){
		alert("Password Does Not Match !");
		frm.pass.focus();
		return false;
	}
	r=confirm("confirm submission!");
	if(r==true){
	  return true;
	}else{
	  frm.name.focus;
	  return false;
	}
}
</script>
<!-- body-->
<div class="container" id="displaydiv" >
<div class="col-sm-12">&nbsp;</div>
	<div class="col-sm-offset-2 col-sm-8">
		<div class="panel panel-default">
			<div class="panel-heading">
				Reset Password
			</div>

			<div class="panel-body">
				<!-- Display Validation Errors -->
				<!--@include('common.errors')-->
				<!-- submit message -->
					<?php 
						
							if(isset($_SESSION['message'])){
								echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
								unset($_SESSION['message']);
							}						
					?>
				<!-- submit message -->

				<!-- New Task Form -->
				<form action="newPass_proccess.php" name="resetpassform" method="post" onsubmit="return valid();" class="form-horizontal">
					
					<!-- Task Name -->
					<div class="form-group">
						<label for="email" class="col-sm-3 control-label"><span style="color: red">*</span>Email Id:</label>
						<div class="col-sm-6">
							<input readonly required class="form-control" name="email" type="email" id="email"  value="<?php echo $e; ?>">
						</div>
						
					</div>
					<div class="form-group">
						<label for="pass" class="col-sm-3 control-label"><span style="color: red">*</span>New Password:</label>
						<div class="col-sm-6">
							<input class="form-control" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required name="pass" type="password" id="pass" >
						</div>
					</div>
					<div class="form-group">
						<label for="re_pass" class="col-sm-3 control-label"><span style="color: red">*</span>Confirm Password:</label>
						<div class="col-sm-6">
							<input pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" class="form-control" required name="re_pass" type="password" id="re_pass" >
						</div>
					</div>
					<!-- Add Task Button -->
					<div class="form-group">
						<div class="col-sm-offset-3 col-sm-6">
							<button type="submit" class="btn btn-default">
								<i class="fa fa-btn fa-key"></i> Reset password
							</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<div class="footer" >
		<?php 
			include"include/footerboot.php"; 
		?>
</div>			
</body>
</html>
				  
<?php } ?>