<?php include "include/sesionlauth.php"; ?>
<?php 
$name = filter_var($_POST['name'], FILTER_SANITIZE_STRING);
$code = filter_var($_POST['code'], FILTER_SANITIZE_STRING);
$rno = filter_var($_POST['rno'], FILTER_SANITIZE_STRING);
$rdate = filter_var($_POST['rdate'], FILTER_SANITIZE_STRING);
 
$address = filter_var($_POST['address'], FILTER_SANITIZE_STRING);

$pin = filter_var($_POST['pin'], FILTER_SANITIZE_STRING);
$email = filter_var($_POST['email1'], FILTER_SANITIZE_STRING);

$mobile = filter_var($_POST['mobile1'], FILTER_SANITIZE_STRING);

$phone = filter_var($_POST['phone1'], FILTER_SANITIZE_STRING);


	
	if($code != ""){
	$sqlflag=0;
	include "DBconnect.php" ;
	$sql="INSERT INTO anbuyer(BCode, Bname, BRegNum, BRdate, BAddress, Bpin, Bphone, Bmobile, BEmail) values ('$code','$name','$rno','$rdate','$address','$pin','$phone','$mobile','$email')";
		

			$result = mysqli_query($db, $sql);

			if(!$result){
				$sqlflag=0;
				$_SESSION['message']="Error ! contact admin !";
				echo "<script> window.history.go(-1); </script>";
				die('Error: ' . mysqli_error($db));
			}
			else{
				$_SESSION['message']="Successfully submited data  !";
				echo '<META HTTP-EQUIV="Refresh" Content="0; URL=client.php">';
			}
		
		mysqli_close($db);
	}


?>