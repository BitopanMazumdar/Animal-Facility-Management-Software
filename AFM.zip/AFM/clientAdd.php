<?php include "include/sesionlauth.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  <link rel="stylesheet" href="css/custom.css">
  
</head>
<body style="background-color:#F8F9FA">
<nav >
 <div class="container-fluid">
	<?php 
	include"include/headerboot.php"; 
	?>
  </div>
  <div class="container-fluid">
	<?php 
	include"include/MenuAi.php"; 
	?>		
  </div>
  <div class="container-fluid">
	<?php 
	include"include/moniRegMenu.php"; 
	?>		
  </div>
 
</nav>
 

<script language="javascript" type="text/javascript" >
	function valid()
	{
		frm = document.clientform;
		var patt = /[%*+;<=>^]/;
		
		if(frm.caddress.value !=""){
			if(patt.test(frm.caddress.value)){
				alert("invalid contact person address ! special characters: %*+;<=>^ are not allowed");
				frm.caddress.focus();
				return false;
			}
		}
		
		r=confirm("confirm submission!");
		if(r==true){
		  return true;
		}else{
		  frm.cname.focus;
		  return false;
		}
		   
	}
</script>		

<div>&nbsp;</div>

<div class="container">
  
  <form class="form-horizontal" name="clientform" action="clientAdd_process.php" method="POST" onsubmit="return valid();">
	<!-- submit message -->
		<?php 
			
				if(isset($_SESSION['message'])){
					echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
					unset($_SESSION['message']);
				}
								
		?>
	<!-- submit message -->
<div class="row mt-4 border-top">
		
			<div class="row mb-3 mt-3">
				<div class="col-lg-12 p-add-head">
					<h4 class="text-primary">Add Contact Person</h4>
				</div>
			</div>
			<div class="row mb-2 mt-2">
				
				<div class="col-lg-6">
					<label for="caddress">Client</label>
					<input required readonly type="text" class="form-control" id="name" name="name" value="<?php echo filter_var($_POST['addclientID'], FILTER_SANITIZE_STRING);?>"/>
				</div>
				
			</div>
			<div class="row mb-2 mt-2">
				<div class="col-lg-6">
					<label for="cname">Person Name<span style="color: red">*</span></label>
					<input style="text-transform: capitalize;" pattern="[A-Za-z0-9\s.-]*" title="Special characters: . - are allowed only" required type="text" class="form-control" id="cname" placeholder="Contact Name" name="cname"/>
					
															</div>
				<div class="col-lg-6">
					<label for="cdesignation">Designation</label>
					<input style="text-transform: capitalize;" pattern="[A-Za-z0-9\s.-]*" title="Special characters: . - are allowed only" type="text" class="form-control" id="cdesignation" placeholder="Enter Email" name="cdesignation"/>
				</div>
			</div>
			
			<div class="row mb-2 mt-2">
				<div class="col-lg-6">
					<label for="cemail1">Email</label>
					<input type="text" class="form-control" id="cemail1" placeholder="Enter Email" name="cemail1"/>
				</div>
				<div class="col-lg-6">
					<label for="cemail2">Alternate Email</label>
					<input type="text" class="form-control" id="cemail2" placeholder="Alternate Email" name="cemail2"/>
				</div>
			</div>

			<div class="row mb-2 mt-2">
				<div class="col-lg-6">
					<label for="cmobile1">Mobile No.</label>
					<input pattern="[0-9\+\s-]{9,}" title="digits + - allowed only minimum length:9 " type="text" class="form-control" id="cmobile1" placeholder="Enter Mobile No." name="cmobile1"/>
				</div>
				<div class="col-lg-6">
					<label for="cmobile2">Alternate Mobile No.</label>
					<input pattern="[0-9\+\s-]{9,}" title="digits + - allowed only minimum length:9 " type="text" class="form-control" id="cmobile2" placeholder="Alternate Mobile No." name="cmobile2"/>
				</div>
			</div>
			<div class="row mb-2 mt-2">
				<div class="col-lg-6">
					<label for="cphone1">Phone No.</label>
					<input pattern="[0-9\/\+\s-]{9,}" type="tel" title="digit + - and / allowed only" type="text" class="form-control" id="cphone1" placeholder="Enter Phone No." name="cphone1"/>
				</div>
				<div class="col-lg-6">
					<label for="cphone2">Alternate Phone No.</label>
					<input pattern="[0-9\/\+\s-]{9,}" type="tel" title="digit + - and / allowed only" type="text" class="form-control" id="cphone2" placeholder="Alternate Phone No." name="cphone2"/>
				</div>
			</div>
			<div class="row mb-2 mt-2">
				
				<div class="col-lg-6">
					<label for="caddress">Address</label>
					<textarea style="text-transform: capitalize;" class="form-control col-lg-6" id="caddress" placeholder="Enter Address" name="caddress"></textarea>
				</div>
				
			</div>
			<div class="row mb-2 mt-2">	
				<div class="form-group">
					<div>&nbsp;</div>
				  <div class="col-sm-offset-5 col-sm-8">
					<button type="submit" class="btn btn-danger">
					<i class="fa fa-btn fa-user-plus"></i> Add 
					</button>
					
					<button type="button" class="btn btn-primary" onclick="window.history.back()"><i class="fa fa-btn fa-arrow-circle-left"></i> Back</button>
				  </div>
				</div>
			</div>
		</div>
	</form>
</div>
<div>&nbsp;</div><div>&nbsp;</div>
<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
</div>
</body>
</html>	
