<?php include "include/sesionlauth.php"; ?>
  <?php 
	$sd = filter_var($_GET['sd'], FILTER_SANITIZE_STRING);
	$sd1 = filter_var($_GET['sd1'], FILTER_SANITIZE_STRING);	
	$str="<div class=\"panel-heading\">
				<button type=\"button\" class=\"btn btn-danger\" onclick=\"javascript:printDiv()\" ><i class=\"fa fa-btn fa-print\"></i> Print</button>
				<span class=\"text-primary\" >&nbsp;&nbsp;&nbsp;&nbsp;	List of sale data</span>
			</div>

			<div class=\"panel-body  table-responsive\" id=\"printdiv\">
				<table class=\"table table-bordered table-hover\">
				<tr>
					<th width=\"7%\" rowspan=\"2\" align=\"center\" >Date</th>
					<th width=\"7%\" rowspan=\"2\" align=\"center\" >Species</th>
					<th width=\"6%\" rowspan=\"2\"align=\"center\" >Strain</th>
					<th width=\"4%\" rowspan=\"2\" align=\"center\" >Quantity (M+F = Total)
					</th><th width=\"6%\" rowspan=\"2\" align=\"center\" >Bill No.</th>
					<th colspan=\"3\" class=\"text-center\" >Sold to</th>
					<th width=\"6%\" rowspan=\"2\" align=\"center\" >Date & IAEC No.</th>
					
				</tr>
				<tr>
					<th width=\"10%\" align=\"center\" >Name</th>
					<th width=\"9%\" align=\"center\" >Address</th>
					<th width=\"10%\" align=\"center\" >Reg. No.</th>
				</tr>
				<tbody>";	
	if($sd != "" && $sd1 != ""){
		include "DBconnect.php";
	
			//fsale(SaleID, Saledate, Scode, Bcode, IEACdate, IAECno, BillNo)
			
			$query= "SELECT SaleID, Saledate, Scode, Bcode, IEACdate, IAECno, BillNo FROM fsale WHERE Saledate BETWEEN '$sd' AND '$sd1' ORDER BY SaleID";
			
			$result = mysqli_query($db,$query);
			$i=1; 
		if($result){
			while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
				$spid=$pass['SaleID'];
				$spdata=$pass['Saledate'];
				$spto=$pass['Bcode'];
				$spfrom=$pass['Scode'];
				$IEACdate=$pass['IEACdate'];
				$IAECno=$pass['IAECno'];
				$BillNo=$pass['BillNo'];
				//animalbuyer`(`BCode`, `Bname`, `BRegNum`, `BAddress`, `Bpin`, `Bphone`, `Bmobile`, `BEmail`)
					$Bname="";
					$BRegNum="";
					$BAddress="";
					$Bpin="";
					$queryBuyer= "SELECT Bname, BRegNum, BAddress,Bpin FROM anbuyer WHERE BCode ='$spto' ";
				
					$resultBuyer = mysqli_query($db,$queryBuyer);
					if($passBuyer=mysqli_fetch_array($resultBuyer,MYSQLI_ASSOC)){
						$Bname=$passBuyer['Bname'];
						$BRegNum=$passBuyer['BRegNum'];
						$BAddress=$passBuyer['BAddress'];
						$Bpin=$passBuyer['Bpin'];
					} 
												
				//supplyanimal(EntrySupplyNumber, SupplyID, Species, strain, StockType, MALE, Female)
				$query1= "SELECT EntrySaleNumber, Species, strain, StockType, MALE, Female FROM sanimal WHERE SaleID ='$spid' ";
			
				$result1 = mysqli_query($db,$query1);
				while($pass1=mysqli_fetch_array($result1,MYSQLI_ASSOC)){
					
					$str=$str. "<tr><td >".$spdata."</td>";
					$str=$str. "<td >" .$pass1['Species']. "</td>";
					$str=$str. "<td >" .$pass1['strain']."</td>";
					$quantity= $pass1['MALE'] + $pass1['Female'];
					$str=$str. "<td >".$pass1['MALE']." + ".$pass1['Female']." = ".$quantity."</td>";
					
					$str=$str. "<td >".$BillNo."</td>";
					$str=$str. "<td >".$Bname."</td>";
					
					$str=$str. "<td >".$BAddress."-".$Bpin."</td>";
					$str=$str. "<td >".$BRegNum."</td>";
					$str=$str. "<td >".$IEACdate." \n ".$IAECno."</td>";
					$str=$str."</tr>";
					$i=$i+1;
				}
			}
			if ($i== 1){
					$str=$str. "<tr><td colspan=\"10\" class=\"table-text text-danger\"><div>*No Records found</div></td></tr>";
				}	
				
				mysqli_free_result($result);
			}else{
				$str=$str. "<tr><td colspan=\"10\" class=\"table-text text-danger\"><div>*Error, Contact Admin.</div></td></tr>";
			}
	
			mysqli_close($db);
		
		}else{
			$str=$str. "<tr><td colspan=\"10\" class=\"table-text text-danger\"><div>*Error, You have not selected any option .</div></td></tr>";			
		}
		$str=$str."</tbody>
			</table>
		</div>
	</div>";
	echo $str;		
	?>		
	