
<!DOCTYPE html >
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>APPLICATION FORM FOR PHD PROGRAMME � 2018</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">  
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  
  <link rel="stylesheet" href="css/bootstrap.min.css"> 
  <link rel="stylesheet" href="CSS/custom.css">
  
  <script src="jquery/bootstrap.min.js"></script>
  <script src="jquery/jquery.validate.min.js"></script>
  <script src="jquery/jquery-3.3.1.min.js"></script>
</head>

<body>
<header class="demo-header">
		<hgroup>
			<h1 class="text-center"> National Institute of Technology Meghalaya</h1>

			<h1 class="text-center">Application form for Admission to Ph D Programme<br> Autumn 2019</h1>
			<h3 class="text-center">On-line Application Form</h3></hgroup>
	</header>
<div class="container" id="main">
<form action="/index.php" method="POST">
<br>
<div class="form-group">
 <fieldset>
 <p class="alert alert-danger">If  any difficulties/queries while filling the online application form contact email:  <strong>phdadmission@nitm.ac.in</strong></p>
 </fieldset>
<div>
<div class="form-group">

      <fieldset>
<legend>Application</legend>
 <label for="course">Category <span id="red">*</span>:</label>
     
    <select class="form-control" name="category" id="category" onChange="checkcategory(this.value);">
     <option value="NULL" >Please Select option</option>
      <option value="GENERAL" >GENERAL</option>
      <option value="SC" >SC</option>
      <option value="ST" >ST</option>
      <option value="OBC" >OBC</option>
          <option value="PWD" >PWD</option>
            </select>
                 <label for="course">Department <span id="red">*</span>:</label>
     
   <select class="form-control" name="dept" id="dept">
     <option value="NULL" >Please Select option</option>
      <option value="CS" >CS</option>
      <option value="CE" >CE</option>
      <option value="EC" >EC</option>
      <option value="EE" >EE</option>
      <option value="ME" >ME</option>
     <option value="MA" >MA</option>
      <option value="CY" >CY</option>
      <option value="PH" >PH</option>
      <option value="HS" >HS</option>
    
      </select>
           <label for="candidature">category of Candidature<span id="red">*</span>:</label>
     
    <select class="form-control" name="candidature" id="candidature">
     <option value="NULL" >Please Select option</option>
      <option value="Fulltime" >Fulltime</option>
      <option value="Parttime" >Parttime</option>
      
      </select>            </fieldset>
</div>
<div class="form-group" id="box">
<fieldset>
<legend>Payment details</legend>
<label class="control-label" for="paymentref">Payment Reference No.<span id="red">*</span>:</label>

  <input type="text" class="form-control" name="paymentref" id="paymentref" value="">
           <label class="control-label" for="paymentdt">Dated<span id="red">*</span>:</label>

<input type="text" class="form-control" name="paymentdt" placeholder="MMDDYYYY" id="paymentdt" value="">    
         <label class="control-label"   for="paymentref">Application Fee<span id="red">*</span>:</label>

  <input type="text" class="form-control" name="fee" id="fee" value="">
     
      </fieldset>
</div>
<div class="form-group">
<fieldset>
<legend>Personal details</legend>

<label class="control-label" for="name">Name of the Candidate<span id="red">*</span>:</label>
<input type="text" class="form-control" name="name" id="name" value=""><label class="control-label" for="name">Father's/Mother's Name<span id="red">*</span>:</label>
<input type="text" class="form-control" name="father" id="father" value="">

     
      </fieldset>
</div>

<div class="form-group">
<fieldset>
<legend>Address with contact Details</legend>
<label class="control-label" for="present_addr">Postal Address (For Communication)<span id="red">*</span>:</label>
<input type="text" class="form-control" name="present_addr" id="present_addr" value=""><label class="control-label" for="permanent_addr">Permanent Address<span id="red">*</span>:</label>
<input type="text" class="form-control" name="permanent_addr" id="permanent_addr" value=""><label class="control-label" for="dob" >Date of Birth <span id="red">*</span>:</label>
<input type="date" class="form-control" name="dob" id="dob"  value=""><label class="control-label" for="nationality">Nationality<span id="red">*</span>:</label>
<input type="text" class="form-control" name="nationality" id="nationality" value=""><label class="control-label" for="email">Email<span id="red">*</span>:</label>
<input type="text" class="form-control" name="email" id="email" value=""><label class="control-label" for="p_no">Phone No.<span id="red">*</span>:</label>
<input type="text" class="form-control" name="p_no" id="p_no" value=""><label for="course">Gender <span id="red">*</span>:</label>
     
    <select class="form-control" name="gender" id="gender">
     <option value="NULL" >Please Select option</option>
      <option value="MALE" >MALE</option>
      <option value="FEMALE" >FEMALE</option>
      
      </select>
           
          </fieldset>
</div>
<div class="form-group">
<fieldset>
<legend>Educational qualifications</legend>
<table class="table table-bordered">
      <th>
      <td>Year</td>
      <td>Board/University</td>
      <td>Pecentage/ CGPA</td>
       <td>Division/ Class</td>
        <td>Subject/ Specialization</td>
      </th>
      <tr>
      <td>Class X</td>
      <td><input type="text" class="form-control" name="x_passingyr" id="x_passingyr" placeholder=""  value=""></td>
      <td> <input type="text" class="form-control" name="x_board" id="x_board" placeholder=""  value=""></td>
      <td><input type="text" class="form-control" name="x_percent" id="x_percent" placeholder=""  value=""></td>
     <td> <input type="text" class="form-control" name="x_division" id="x_division" placeholder=""  value=""></td>
     <td><input type="text" class="form-control" name="x_specl" id="x_specl" placeholder=""  value=""></td>
 
      </tr>
      <td>Class XII/Diploma</td>
        <td><input type="text" class="form-control" name="xii_passingyr" id="xii_passingyr" placeholder=""  value=""></td>
      <td> <input type="text" class="form-control" name="xii_board" id="xii_board" placeholder=""  value=""></td>
      <td><input type="text" class="form-control" name="xii_percent" id="xii_percent" placeholder=""  value=""></td>
     <td> <input type="text" class="form-control" name="xii_division" id="xii_division" placeholder=""  value=""></td>
     <td><input type="text" class="form-control" name="xii_specl" id="xii_specl" placeholder=""  value=""></td>
     </tr>
       
      </table>
      <hr/>
      <table class="table table-bordered">
      <th>
      <td>Year</td>
      <td>Board/University</td>
      <td>Pecentage/ CGPA</td>
       <td>Division/ Class</td>
        <td>Subject/ Specialization</td>
      </th>
      <tr>
      <td>UG</td>
      <td><input type="text" class="form-control" name="b_passingyr" id="b_passingyr" placeholder=""  value=""></td>
      <td> <input type="text" class="form-control" name="b_board" id="b_board" placeholder=""  value=""></td>
      <td><input type="text" class="form-control" name="b_percent" id="b_percent" placeholder=""  value=""></td>
      <td> <input type="text" class="form-control" name="b_division" id="b_division" placeholder=""  value=""></td>
      <td><input type="text" class="form-control" name="b_specl" id="b_specl" placeholder=""  value=""></td>
 

     </tr>
      <td>PG</td>
     <td><input type="text" class="form-control" name="m_passingyr" id="m_passingyr" placeholder=""  value=""></td>
      <td> <input type="text" class="form-control" name="m_board" id="m_board" placeholder=""  value=""></td>
      <td><input type="text" class="form-control" name="m_percent" id="m_percent" placeholder=""  value=""></td>
     <td> <input type="text" class="form-control" name="m_division" id="m_division" placeholder=""  value=""></td>
     <td><input type="text" class="form-control" name="m_specl" id="m_specl" placeholder=""  value=""></td>
      </tr>
       
      </table>
      <div class="form-group">

</div>
     
      </fieldset>
</div>
<div class="form-group">

<fieldset>
<legend>Experience</legend>
<label for="details_org">Details of Employment and Experience:<span id="red">*</span>:</label>
    <table class="table-condensed">
        <tr>
       <td>Orginization</td>
      <td>From Date</td>
      <td>To Date</td>
      <td>Position</td>
       <td>Regular/Temporary</td>
        <td>Duties</td>
      </tr>
      <tr>
      <td><input type="text" class="form-control" name="eploy1_org" id="eploy1_org" placeholder=""  value=""></td>
      <td><input type="date" class="form-control" name="eploy1_from" id="eploy1_from" placeholder=""  value=""></td>
      <td> <input type="date" class="form-control" name="eploy1_to" id="eploy1_to" placeholder=""  value=""></td>
      <td> <input type="text" class="form-control" name="eploy1_position" id="eploy1_position" placeholder=""  value=""></td>
      <td><input type="text" class="form-control" name="eploy1_type" id="eploy1_type" placeholder=""  value=""></td>
      <td><input type="text" class="form-control" name="eploy1_duties" id="eploy1_duties" placeholder=""  value=""></td>

     </tr>
     <tr>
      <td><input type="text" class="form-control" name="eploy2_org" id="eploy2_org" placeholder=""  value=""></td>
      <td><input type="date" class="form-control" name="eploy2_from" id="eploy2_from" placeholder=""  value=""></td>
      <td> <input type="date" class="form-control" name="eploy2_to" id="eploy2_to" placeholder=""  value=""></td>
      <td> <input type="text" class="form-control" name="eploy2_position" id="eploy2_position" placeholder=""  value=""></td>
      <td><input type="text" class="form-control" name="eploy2_type" id="eploy2_type" placeholder=""  value=""></td>
      <td><input type="text" class="form-control" name="eploy2_duties" id="eploy2_duties" placeholder=""  value=""></td>

        </tr>
        <tr>
         <td><input type="text" class="form-control" name="eploy3_org" id="eploy3_org" placeholder=""  value=""></td>
      <td><input type="date" class="form-control" name="eploy3_from" id="eploy3_from" placeholder=""  value=""></td>
      <td> <input type="date" class="form-control" name="eploy3_to" id="eploy3_to" placeholder=""  value=""></td>
      <td> <input type="text" class="form-control" name="eploy3_position" id="eploy3_position" placeholder=""  value=""></td>
      <td><input type="text" class="form-control" name="eploy3_type" id="eploy3_type" placeholder=""  value=""></td>
      <td><input type="text" class="form-control" name="eploy3_duties" id="eploy3_duties" placeholder=""  value=""></td>

        </tr>
         <tr>
         <td><input type="text" class="form-control" name="eploy4_org" id="eploy4_org" placeholder=""  value=""></td>
      <td><input type="date" class="form-control" name="eploy4_from" id="eploy4_from" placeholder=""  value=""></td>
      <td> <input type="date" class="form-control" name="eploy4_to" id="eploy4_to" placeholder=""  value=""></td>
      <td> <input type="text" class="form-control" name="eploy4_position" id="eploy4_position" placeholder=""  value=""></td>
      <td><input type="text" class="form-control" name="eploy4_type" id="eploy4_type" placeholder=""  value=""></td>
      <td><input type="text" class="form-control" name="eploy4_duties" id="eploy4_duties" placeholder=""  value=""></td>

        </tr>
         <tr>
      <td><input type="text" class="form-control" name="eploy5_org" id="eploy5_org" placeholder=""  value=""></td>
      <td><input type="date" class="form-control" name="eploy5_from" id="eploy5_from" placeholder=""  value=""></td>
      <td> <input type="date" class="form-control" name="eploy5_to" id="eploy5_to" placeholder=""  value=""></td>
      <td> <input type="text" class="form-control" name="eploy5_position" id="eploy5_position" placeholder=""  value=""></td>
      <td><input type="text" class="form-control" name="eploy5_type" id="eploy5_type" placeholder=""  value=""></td>
      <td><input type="text" class="form-control" name="eploy5_duties" id="eploy5_duties" placeholder=""  value=""></td>


        </tr>
      </table>
            <p> Furnish the details of experience from latest position and organization onwards</p>
 <label class="control-label" for="achiev"><strong>Duties Performed and Achievements:</strong><span id="red">*</span>:</label>
        <textarea class="form-control" rows="5" name="achiev" id="achiev"></textarea>
      <div class="form-group">
<fieldset>
      <label for="details_org">Details of Sponsoring Organisation and Address:<span id="red">*</span>:</label>
  <textarea class="form-control" rows="5" name="details_org" id="details_org"></textarea><p>*Candidate must submit Sponsorship form in Official Letter Head as prescribed<a href="docs/Updated_form_III, Sponsorship Certificate_2ndNov(1).docx"> Link </a></p>
</fieldset>
</div>
   </fieldset>
   <fieldset>
      <label for="purpose">Specialized training  /Refresher courses/other knowledge up gradation courses attended<span id="red">*</span>:</label>
  <textarea class="form-control" rows="5" name="training" id="training"></textarea></fieldset>
</div>
<div class="form-group">
<fieldset>
      <label for="purpose">List of publications (if any, submit details with testimonials):<span id="red">*</span>:</label>
  <textarea class="form-control" rows="5" name="publications" id="publications"></textarea></fieldset>
</div>

<div class="form-group">
<fieldset>
      <label for="purpose">Statement of purpose(Write about the topic you are interested, if required attached extra pages.)<span id="red">*</span>:</label>
  <textarea class="form-control" rows="5" name="purpose" id="purpose"></textarea></fieldset>
</div>
<div class="form-group">
<fieldset>
      <label for="scholarship">Scholarship/fellowship awarded for research (if any):<span id="red">*</span>:</label>
  <textarea class="form-control" rows="5" name="scholarship" id="scholarship"></textarea></fieldset>
</div>
<div class="form-group">
<fieldset>
      <label for="gate">Qualified for NET/GATE/Other: Score and  Year(Enclose Certificate)(If any)<span id="red">*</span>:</label>
  <textarea class="form-control" rows="5" name="gate" id="gate"></textarea></fieldset>
</div>
<div class="form-group">
<fieldset>
<legend></legend>
     <p>Candidates are advised to check the application before pressing the submit button. A printout of the application is to be taken for submission of hardcopy of application.</p>
   </fieldset>
 
</div>


<div class="form-group">
<button type="submit" id="action" name="action" value="submit" class="btn btn-danger">Submit</button>
</div>
</form>

</div>

<!--add Here The error messages-->

</body>
</html>
<script type="text/javascript">
function checkcategory(val){
 var element=document.getElementById('box');
 if(val=='Please Select option'||val=='PWD')
   element.style.display='none';
 else  
   element.style.display='block';
}
</script>
