<?php include "include/sesionlauth.php"; ?>
  <?php 
	$utype = $_GET['usertype'];	
	$str="<div class=\"panel-heading\">
				<button type=\"button\" class=\"btn btn-danger\" onclick=\"javascript:printDiv()\" ><i class=\"fa fa-btn fa-print\"></i> Print</button>
				<span class=\"text-primary\" >&nbsp;&nbsp;&nbsp;&nbsp;	IAEC Member</span>
			</div>

			<div class=\"panel-body  table-responsive\" id=\"printdiv\">
				<table class=\"table table-bordered table-hover\">
				<thead>
					<th width=\"4%\" ><strong>S.No. </strong></th>
		<th width=\"10%\" ><strong>Type </strong></th>
        <th width=\"20%\" ><strong>Name </strong></th>
		<th width=\"15%\" ><strong>Phone </strong></th>
		<th width=\"15%\" ><strong>Mobile </strong></th>
        <th width=\"20%\" ><strong>Email ID </strong></th>
		<th width=\"25%\" ><strong>Address </strong></th>
					<th width=\"10%\"  class=\"remOnPrint\" >&nbsp;</th>
				</thead>
				<tbody>";	
	if($utype != ""){
		include "DBconnect.php";
		//iaecmember(Itype, IName, IEmail, IPhone, IMobile, IAddress, Ipin)
		$sql="SELECT Itype, IName, IEmail, IPhone, IMobile, IAddress, Ipin FROM iaecmember WHERE Itype = '$utype' "; 
		$result = mysqli_query($db,$sql);
		if($result){
	$i=1;
		
	while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){				
								
		$str=$str. "<tr>";
		$str=$str. "<td >";
		$str=$str. "<b>".$i."<b>";
		$str=$str. "</td>";
			
		$str=$str. "<td >";
		$str=$str. "<b>".$pass['Itype']. "<b>";
		$str=$str. "</td>";
		$str=$str. "<td >";
		$str=$str. "<b>".$pass['IName']. "<b>";
		$str=$str. "</td>";
		$str=$str. "<td >";
		$str=$str. "<b>".$pass['IPhone']. "<b>";
		$str=$str. "</td>";
		
		$str=$str. "<td >";
		$str=$str. "<b>".$pass['IMobile']."<b>";
		$str=$str. "</td>";
		$str=$str. "<td >";
		$str=$str. "<b>".$pass['IEmail']."<b>";
		$str=$str. "</td>";
		$str=$str. "<td >";
		$str=$str. "<b>".$pass['IAddress']." - ".$pass['Ipin']."<b>";
		$str=$str. "</td>";
		$str=$str."<td class=\"remOnPrint\">
				<form action=\"EditIMUser.php\" method=\"POST\">
					<input type=\"hidden\" name=\"user\" value=\"".$pass['IEmail']."\">
					<button type=\"submit\" class=\"btn btn-danger\">
						<i class=\"fa fa-btn fa-edit\"></i> Edit
					</button>
				</form>
			</td>";
		$str=$str."</tr>";
				
		$i++;		 
	}
	if ($i== 1){
				$str=$str. "<tr><td colspan=\"8\" class=\"table-text text-danger\"><div>*No Records found</div></td></tr>";
			}	
		
		mysqli_free_result($result);
	}else{
		$str=$str. "<tr><td colspan=\"8\" class=\"table-text text-danger\"><div>*Error, Contact Admin.</div></td></tr>";
	}
	
	mysqli_close($db);
	}else{
			$str=$str. "<tr><td colspan=\"8\" class=\"table-text text-danger\"><div>*Error, Invalid input.</div></td></tr>";
	}
	$str=$str."</tbody>
			</table>
		</div>
	</div>";
	echo $str;
	?>