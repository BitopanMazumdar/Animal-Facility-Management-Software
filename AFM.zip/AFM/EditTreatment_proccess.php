<?php include "include/sesionlauth.php"; ?>
 <?php 

$TreatmentID=$_POST['TreatmentID'];
$tdate=$_POST['tdate'];
$room=$_POST['room'];
$species=$_POST['species'];
$strain=$_POST['strain'];
$ano=$_POST['ano'];
$csign=$_POST['csign'];
$trmt=$_POST['trmt'];
$tdbye=$_POST['tdby'];

include "DBconnect.php" ;

//treatmentregister(TreatmentID, TreatmentDate, RoomNo, Species, strain, ClinicalSigns, Treatment, TreatmentBy) 
//('$tdate', '$room', '$species', '$strain', '$csign', '$trmt', '$tdbye')";
if($TreatmentID!=""){
	include "DBconnect.php";
	
	$query="UPDATE treatmentregister SET TreatmentDate='$tdate', RoomNo='$room', Species='$species', strain='$strain', idanimal='$ano', ClinicalSigns='$csign', Treatment='$trmt', TreatmentBy='$tdbye' WHERE TreatmentID= '$TreatmentID'" ;
	mysqli_query($db,$query);
		$result = mysqli_affected_rows($db);
		if($result){
			$_SESSION['message']="Successfully edited   !";
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=TreatmentReport.php">';
			$str="Successfully edited ";
		}else{
			$_SESSION['message']="Error, Contact Admin !";
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=TreatmentReport.php">';
		}
		
		mysqli_close($db);
	
}else{
	$_SESSION['message']="Error, Invalid input  !";
	echo '<META HTTP-EQUIV="Refresh" Content="0; URL=TreatmentReport.php">';
}