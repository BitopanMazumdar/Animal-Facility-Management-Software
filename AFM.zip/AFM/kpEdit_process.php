<?php include "include/sesionlauth.php"; ?>
 <?php 
$kpold=filter_var($_POST['kpold'], FILTER_SANITIZE_STRING);
$kname = filter_var($_POST['kname'], FILTER_SANITIZE_STRING);
$kdesignation = filter_var($_POST['kdesignation'], FILTER_SANITIZE_STRING);
$kmobile1 = filter_var($_POST['kmobile1'], FILTER_SANITIZE_STRING);
$kmobile2 = filter_var($_POST['kmobile2'], FILTER_SANITIZE_STRING);
$kphone1 = filter_var($_POST['kphone1'], FILTER_SANITIZE_STRING);
$kphone2 = filter_var($_POST['kphone2'], FILTER_SANITIZE_STRING);
$kemail1 = filter_var($_POST['kemail1'], FILTER_SANITIZE_STRING);
$kemail2 = filter_var($_POST['kemail2'], FILTER_SANITIZE_STRING);
$kaddress = filter_var($_POST['kaddress'], FILTER_SANITIZE_STRING);

//knownperson(kpId, clientID, kpName, kpDesignation, mobile1, mobile2, phone1, phone2, email1, email2, adderss)

if($kpold!=""){
	include "DBconnect.php";
	
	$query="UPDATE knownperson SET kpName='$kname', kpDesignation='$kdesignation', mobile1='$kmobile1', mobile2='$kmobile2', phone1='$kphone1', phone2='$kphone2', email1='$kemail1', email2='$kemail2', adderss='$kaddress', author='$pie' WHERE kpId='$kpold'" ;
	mysqli_query($db,$query);
		$result = mysqli_affected_rows($db);
		if($result >=0){
			$_SESSION['message']="Successfully edited !";
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=viewClient.php">';			
		}else{
			$_SESSION['message']="Error  ! Contact admin !";
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=viewClient.php">';
		}
		mysqli_close($db);
	
}else{
	$_SESSION['message']="Invalid data !";
	echo '<META HTTP-EQUIV="Refresh" Content="0; URL=viewClient.php">';
}
?>