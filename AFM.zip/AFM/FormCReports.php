<?php include "include/sesionlauth.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Form C	</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  
</head>
<body style="background-color:#F8F9FA">
	<nav >
		 <div class="container-fluid">
			<?php 
			include"include/headerboot.php"; 
			?>
		  </div>
		  <div class="container-fluid">
			<?php 
			include"include/MenuAi.php"; 
			?>		
		  </div> 
	</nav>
<!-- Script start-->
<script type="text/javascript">
function printDiv(divID) {
	
        //Get the HTML of div
        var divElements = document.getElementById(divID).innerHTML;
        //Get the HTML of whole page
        var oldPage = document.body.innerHTML;
        //Reset the page's HTML with div's HTML only
		var htmlToPrint = '' +
        '<style type="text/css">' +
        'table th, table td {' +
        'border:1px solid #000;' +
        'padding;0.5em;' +
        '}' +
        '</style>';
        document.body.innerHTML = 
          "<html><head><title></title></head><body>" +  htmlToPrint + divElements + "</body>";
        //Print Page
        window.print();
        //Restore orignal HTML
        document.body.innerHTML = oldPage;

    }
</script>

<script type="text/javascript">
function formCBY(type)
{
	$("#viewdata").hide();
	$("#loader").show();
	if(type==1){
		//window.location='SupplyByPc.php?page=ahreports&pg=supprep&type='+type+'&pc='+pc+'';
		var xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = function() {
		  if (this.readyState == 4 && this.status == 200) {
			document.getElementById("viewdata").innerHTML = this.responseText;
			$("#viewdata").slideDown("slow");
			$("#loader").hide();
			
		  }
		};
		
		xmlhttp.open("GET", "FormCBreed.php", true);
		xmlhttp.send();
	}
	if(type==2){
		//window.location='SupplyByPi.php?page=ahreports&pg=supprep&type='+type+'&pi='+pi+'';
		var xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = function() {
		  if (this.readyState == 4 && this.status == 200) {
			document.getElementById("viewdata").innerHTML = this.responseText;
			$("#viewdata").slideDown("slow");
			$("#loader").hide();
		  }
		};
		
		xmlhttp.open("GET", "FormCAcquired.php", true);
		xmlhttp.send();
	}
	if(type==3){
	
		
			//window.location='SupplyByDate.php?page=ahreports&pg=supprep&type='+type+'&sd='+vdate+'&sd1='+vdate1+'';
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() {
			  if (this.readyState == 4 && this.status == 200) {
				document.getElementById("viewdata").innerHTML = this.responseText;
				$("#viewdata").slideDown("slow");
				$("#loader").hide();
			  }
			};
			
			xmlhttp.open("GET", "FormCTransffered.php", true);
			xmlhttp.send();
	}
	if(type==4){
			
		var xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = function() {
		  if (this.readyState == 4 && this.status == 200) {
			document.getElementById("viewdata").innerHTML = this.responseText;
			$("#viewdata").slideDown("slow");
			$("#loader").hide();
		  }
		};
		
		xmlhttp.open("GET", "FormCByAll.php", true);
		xmlhttp.send();
		}
}
function getBydatetype(){
	
	type=$('#gby').val();
	//alert(type);
	vdate=$('#vdate').val();
	vdate1=$('#vdate1').val();
	if(vdate==""){
		alert("Enter: From Date");
	}else if(vdate1==""){
		alert("Enter: To Date");
	}else if (new Date(vdate) > new Date(vdate1)){ 
		alert("To Date must be greater than From date");
	}else{
		if(type==1){
			//window.location='SupplyByPc.php?page=ahreports&pg=supprep&type='+type+'&pc='+pc+'';
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() {
			  if (this.readyState == 4 && this.status == 200) {
				 
				document.getElementById("viewdata").innerHTML = this.responseText;
				$("#viewdata").slideDown("slow");
				$("#loader").hide();
			  }
			};
			
			xmlhttp.open("GET", "FormCBydateBreed.php?type="+type+"&sd="+vdate+"&sd1="+vdate1, true);
			xmlhttp.send();
		}
		if(type==2){
			//window.location='SupplyByPi.php?page=ahreports&pg=supprep&type='+type+'&pi='+pi+'';
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() {
			  if (this.readyState == 4 && this.status == 200) {
				document.getElementById("viewdata").innerHTML = this.responseText;
				$("#viewdata").slideDown("slow");
				$("#loader").hide();			  
				}
			};
			
			xmlhttp.open("GET", "FormCBydateAcquired.php?type="+type+"&sd="+vdate+"&sd1="+vdate1, true);
			xmlhttp.send();
		}
		if(type==3){
		
			
				//window.location='SupplyByDate.php?page=ahreports&pg=supprep&type='+type+'&sd='+vdate+'&sd1='+vdate1+'';
				var xmlhttp = new XMLHttpRequest();
				xmlhttp.onreadystatechange = function() {
				  if (this.readyState == 4 && this.status == 200) {
					document.getElementById("viewdata").innerHTML = this.responseText;
					$("#viewdata").slideDown("slow");
					$("#loader").hide();
				  }
				};
				
				xmlhttp.open("GET", "FormCBydateTransffered.php?type="+type+"&sd="+vdate+"&sd1="+vdate1, true);
				xmlhttp.send();
		}
		if(type==4){
		var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() {
			  if (this.readyState == 4 && this.status == 200) {
				document.getElementById("viewdata").innerHTML = this.responseText;
				$("#viewdata").slideDown("slow");
				$("#loader").hide();
			  }
			};
			
			xmlhttp.open("GET", "FormCBydate.php?sd="+vdate+"&sd1="+vdate1, true);
			xmlhttp.send();
		}
	}
}

</script>

<script type="text/javascript">
$(document).ready(function(){
	$("#displaydiv").show("slow"); 
	
	var xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = function() {
		  if (this.readyState == 4 && this.status == 200) {
			document.getElementById("viewdata").innerHTML = this.responseText;
			$("#viewdata").slideDown("slow");
			$("#loader").hide();
		  }
		};
		
		xmlhttp.open("GET", "FormCByAll.php", true);
		xmlhttp.send();	
	
});

</script>

<!-- Script end-->
<div>&nbsp;</div>
<div class="container" id="displaydiv" style="display:none">
        <div class="col-sm-offset-2 col-sm-8">
            <div class="panel panel-default">
                <div class="panel-heading">
                   Form C Record (type: breed, acquired and transferred): <span class="text-danger">*Select type to view particular type record. Click search to Filter record by date.</span>
                </div>

                <div class="panel-body table-responsive">
                    <!-- submit message -->
						<?php 
								if(isset($_SESSION['message'])){
									echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
									unset($_SESSION['message']);
								}		
						?>
					<!-- submit message -->	

                    <!-- New Task Form -->
                    <form action="" method="post" name="archive_form" class="form-horizontal">
						<div class="form-group">
							<label for="gby" class="col-sm-3 control-label"><span style="color: red">*</span>Type:</label>
							<div class="col-sm-6">
								<select class="form-control" name="gby" id="gby"  onchange="formCBY(this.value)" >
									<option value="4">All</option>
									<option value="1">Breed</option>
									<option value="2">Acquired</option>
									<option value="3">Transffered</option>
								</select>
							</div>
						</div>
						<div class="row">
							
								<label for="vdate" class="col-sm-3 control-label">Date From:</label>
								<div class="col-sm-3">
									<input class="form-control col-sm-3" type="date" name="vdate" id="vdate" />
								</div>
							
								<label for="vdate1" class="col-sm-2 control-label">Date To:</label>
								<div class="col-sm-3">
									<input class="form-control col-sm-3" type="date" name="vdate1" id="vdate1" />
								</div>
							
						</div>
						
						<div class="form-group">
							<div class="col-sm-offset-1 col-sm-3">
								<button type="button" onClick="getBydatetype();" class="btn btn-success">
									<i class="fa fa-btn fa-search"></i> Search
								</button>
							</div>
						</div>
					
					</form>
                </div>
            </div>
		</div>
	</div>
	<div class="container-fluid">
       
            <div id="viewdata" class="panel panel-default" style="display:none">
			<!-- load data-->	
			</div>
	</div>
    
	<div class="container" >
		<div id="loader" class="col-sm-offset-5 col-sm-7 loader">
		</div>
	</div>
	
	<div>&nbsp;</div><div>&nbsp;</div>
	<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
	</div>
	
</body>
</html>				 