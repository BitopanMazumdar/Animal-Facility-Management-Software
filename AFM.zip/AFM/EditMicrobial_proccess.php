<?php include "include/sesionlauth.php"; ?>
 <?php 

$MSamplingID=filter_var($_POST['MSamplingID'], FILTER_SANITIZE_STRING);
$sdate=filter_var($_POST['sdate'], FILTER_SANITIZE_STRING);
$room=filter_var($_POST['room'], FILTER_SANITIZE_STRING);
$species=filter_var($_POST['species'], FILTER_SANITIZE_STRING);
$strain=filter_var($_POST['strain'], FILTER_SANITIZE_STRING);
$sex=filter_var($_POST['sex'], FILTER_SANITIZE_STRING);
$ano=filter_var($_POST['ano'], FILTER_SANITIZE_STRING);
$sdbye=filter_var($_POST['sdby'], FILTER_SANITIZE_STRING);


//microbialsampling(MSamplingID, MCollectionDate, RoomNo, Species, strain, Gender, AnimalNo, MCollectedBy) 
//('$sdate', '$room', '$species', '$strain', '$sex', '$ano', '$sdbye')
if($MSamplingID!=""){
	include "DBconnect.php";
	
	$query="UPDATE microbialsampling SET MCollectionDate='$sdate', RoomNo='$room', Species='$species', strain='$strain', Gender='$sex', AnimalNo='$ano', MCollectedBy='$sdbye' WHERE MSamplingID= '$MSamplingID'" ;
	mysqli_query($db,$query);
		$result = mysqli_affected_rows($db);
		if($result>=0){
			$_SESSION['message']="Successfully edited  !";
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=MicrobialReport.php">';
			
		}else{
			$_SESSION['message']="Error, Contact Admin  !";
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=MicrobialReport.php">';
		}
		
		mysqli_close($db);
	
}else{
	$_SESSION['message']="Error, Invalid input  !";
	echo '<META HTTP-EQUIV="Refresh" Content="0; URL=MicrobialReport.php">';
}