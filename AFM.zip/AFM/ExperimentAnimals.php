<?php include "include/sesionlauth.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  <link rel="stylesheet" href="css/custom.css">
  
</head>
<body style="background-color:#F8F9FA">
<nav >
 <div class="container-fluid">
	<?php 
	include"include/headerboot.php"; 
	?>
  </div>
  <div class="container-fluid">
	<?php 
	include"include/MenuAi.php"; 
	?>		
  </div>
  <div class="container-fluid">
	<?php 
	include"include/inventorynav.php"; 
	?>		
  </div>
 
</nav>

<!-- Script start-->
<script type="text/javascript">
 $(document).ready(function(){
	 $("#main").slideDown("slow");
	 $.get("species_query.php", function(data, status){
	$("#species").html(data);
	
	});
});
</script>		
<script type="text/javascript">
function valid(){
	frm = document.myform;
	
	  
	  if(frm.species.value =="" && frm.strain.value =="" )
	  {
			alert("Please enter Species/Strain !");
			frm.species.focus();
			return false;
	  }
	  /*if(frm.strain.value =="")
	  {
			alert("Please enter Password !");
			frm.strain.focus();
			return false;
	  }
	  */
	  
	   if(frm.edate.value =="")
	  {
			alert("Please enter Experiment date !");
			frm.edate.focus();
			return false;
	  }
	 if(frm.qm.value =="" && frm.qf.value =="" )
	  {
			alert("Please enter Male/Female quantity !");
			frm.qm.focus();
			return false;
	  }
	  if(document.getElementById("strain").value =="")
	  {
		  //alert("Reminder: You have not selected Strain");
		 
		  var r = confirm("confirm submit without selecting strain!");
		  if (r == true) {
			return true;
		  } else {
			frm.strain.focus();
			return false;
		  }
	  }
	 var r = confirm("confirm submit!");
	  if (r == true) {
		return true;
	  } else {
		frm.species.focus();
		return false;
	  }
	  
}
function malenumber(quantity){
	sp=$("#species").val();
	st=$("#strain").val();
	stock=$("#stock").val();
	if(sp==""){
		alert("please select Species");
		$("#qm").val(0);
		return false;
	}
	if(stock==""){
		alert("please select Stock Type");
		$("#qm").val(0);
		return false;
	}
	$.get("checkmalenumber.php",{mq:quantity, sp:sp, st:st, stock:stock}, function(data, status){
		//alert(data);
		if(data==-1){
			return true;
		}else if(data==-2){
			$("#qm").val(0);
			alert("stock not available in animal house! Species: "+sp+" Strain: "+st +" Stock Type: "+stock);
			return false;
		}else{
			$("#qm").val(0);
			alert("Quantity is more than available stock! Available stock = "+data);
			return false;
			
		}
	});
}
function femalenumber(quantity){
	sp=$("#species").val();
	st=$("#strain").val();
	stock=$("#stock").val();
	if(sp==""){
		alert("please select Species");
		$("#qf").val(0);
		return false;
	}
	if(stock==""){
		alert("please select Stock Type");
		$("#qf").val(0);
		return false;
	}
	$.get("checkfemalenumber.php",{fq:quantity, sp:sp, st:st, stock:stock}, function(data, status){
		//alert(data);
		if(data==-1){
			return true;
		}else if(data==-2){
			$("#qf").val(0);
			alert("stock not available in animal house! Species: "+sp+" Strain: "+st +" Stock Type: "+stock);
			return false;
		}else{
			$("#qf").val(0);
			alert("Quantity is more than available stock! Available stock = "+data);
			return false;
			
		}
	});
}
</script>		
<!-- End of validation -->

<script type="text/javascript">
function getStrain(val){
	
	$.get("strain_query.php", {sp:val}, function(data, status){
		
    $("#strain").html(data);
    });
}	
</script>
<!-- Script end-->
 
<div class="container" id="main" style="display:none">
<br>
<!-- submit message -->
	<?php 
		
		if(isset($_SESSION['message'])){
			echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
			unset($_SESSION['message']);
		}
								
	?>
<!-- submit message -->
<form action="ExperimentAnimals_proccessing.php" name="myform" id="myform" method="post" onSubmit="return valid();">
<br>
	<button type="button" class="btn btn-danger col-sm-offset-6" onClick="document.location.href='ExpAnimalReport.php'"><i class="fa fa-btn fa-plus"></i> View Experiment Report
					</button>
	<div class="form-group" id="box">
	<fieldset>
		<legend>Experiment Animals details</legend>
		
		<label class="control-label" for="mdate">Experiment Date<span id="red">*</span>:</label>
			<input class="form-control" required name="edate" type="date" id="edate">
		
	</fieldset>
	</div>
	<div class="form-group" id="box">
	<fieldset>
		
		<label class="control-label" for="species">Species Name<span id="red">*</span>:</label>
			<select class="form-control" required name="species" id="species" onchange="getStrain(this.value);">
				<option value="">Select</option>
			 </select>  
		<label class="control-label" for="strain">Strain Name:</label>
			<select class="form-control" id="strain" name="strain">
				<option value=""> select </option>
			</select>
		<label class="control-label" for="stock">Stock Type<span id="red">*</span>:</label>
			<select class="form-control" required  name="stock" id="stock">
				<option value="">Select</option>
				<option value="Breeding Pair">Breeding Pair</option>
				<option value="Issue Stock">Issue Stock</option>
			</select>
			
			
	</fieldset>
	</div>
	<div class="form-group">
	<fieldset>
	<legend>Quantity</legend>
		<label class="control-label" for="qm">Male<span id="red">*</span>:</label>
			<input class="form-control" name="qm" type="number" id="qm" min="1"  onchange="malenumber(this.value);" />
		<label class="control-label" for="qf">Female<span id="red">*</span>:</label>
			<input class="form-control" name="qf" type="number" id="qf" min="1" onchange="femalenumber(this.value);" />

	</fieldset>
	</div>
	<!-- Add Task Button -->
	<div class="form-group">
	
		<div class="col-sm-offset-4 col-sm-6">
			<button type="submit" class="btn btn-danger">
				<i class="fa fa-btn fa-plus"></i> Add Experiment
			</button>
			<button type="button" class="btn btn-warning" onclick="window.history.back()">
				<i class="fa fa-btn fa-arrow-left"></i> Back
			</button>
		</div>
	
	</div>
</form>
</div>
		
	<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
	</div>
	
</body>
</html>
