<?php include "include/sesionlauth.php"; ?>
 <?php 
	$sc = filter_var($_GET['sc'], FILTER_SANITIZE_STRING);
	
		if($sc != ""){
		include "DBconnect.php";
			//client(name, clientID, cType, status, mobile1, mobile2, phone1, phone2, email1, email2, region, cState, city, adderss, pin, cRegNum, cRdate)
			$query= "SELECT name, clientID, cType, status, mobile1, mobile2, phone1, phone2, email1, email2, region, cState, city, adderss, pin, cRegNum, cRdate FROM client WHERE cType='$sc'";
			$i=0;
			$result = mysqli_query($db,$query);
			$str="<div class=\"panel-heading\" id=\"rempbdiv\">
						<h4><button type=\"button\" class=\"btn btn-danger\" onclick=\"printDiv()\"><i class=\"fa fa-btn fa-print\"></i> Print</button> <span class=\"text-primary\" >Clients List</span></h4>
                    </div>

                    <div class=\"panel-body table-responsive\" >
                        <table class=\"table table-striped task-table\" id=\"clientall\">
                            <thead>
                                <th>Company name</th>
								<th>Type</th>
                                <th>Statue</th><th>Region</th><th>State</th><th>City</th><th>Contact</th><th>Email</th>
								<th class=\"remOnPrint\">&nbsp;</th>
								
                            </thead>
                            <tbody>";
							//client(name, clientID, cType, status, mobile1, mobile2, phone1, phone2, email1, email2, region, cState, city, adderss, pin, cRegNum, cRdate)
							while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
								$i++;
								$str=$str."
								<tr>
									<td class=\"table-text\"><div>".$pass['name']."</div></td>
									<td class=\"table-text\"><div>".$pass['cType']."</div></td>
									<td class=\"table-text\"><div>".$pass['status']."</div></td>
									<td class=\"table-text\"><div>".$pass['region']."</div></td>
									<td class=\"table-text\"><div>".$pass['cState']."</div></td>
									<td class=\"table-text\"><div>".$pass['city']."</div></td>
									<td class=\"table-text\"><div>".$pass['mobile1']."</div></td>
									<td class=\"table-text\"><div>".$pass['email1']."</div></td>
									<!-- Task Delete Button -->
									<td class=\"remOnPrint\">
										<form action=\"clientEdit.php\" method=\"POST\">
											<input type=\"hidden\" readonly name=\"clientID\" id=\"clientID\" value=\"".$pass['clientID']."\" />
											<button type=\"submit\" class=\"btn btn-primary\">
												<i class=\"fa fa-btn fa-edit\"></i> Edit
											</button>
										</form>
									</td>
									
								</tr>";
							}
							if ($i== 0){
								$str=$str. "<tr><td colspan=\"9\" class=\"table-text text-danger\"><div>*No Records found</div></td></tr>";
							}
							$str=$str."</tbody>
							
                        </table>
                    </div>
                </div>";
				
			echo $str;
			
	mysqli_free_result($result);
	mysqli_close($db);
		}else{
			$_SESSION['message']="Invalid data !";
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=viewClient.php">';
		}
?>