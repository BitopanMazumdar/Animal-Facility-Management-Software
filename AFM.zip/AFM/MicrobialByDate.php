<?php include "include/sesionlauth.php"; ?>
  <?php 
	$fdate = filter_var($_GET['sd'], FILTER_SANITIZE_STRING);	
	$tdate = filter_var($_GET['sd1'], FILTER_SANITIZE_STRING);
	$str="<div class=\"panel-heading\">
				<button type=\"button\" class=\"btn btn-danger\" onclick=\"javascript:printDiv()\" ><i class=\"fa fa-btn fa-print\"></i> Print</button>
				<span class=\"text-primary\" >&nbsp;&nbsp;&nbsp;&nbsp;	Microbial Sampling Record</span>
			</div>

			<div class=\"panel-body  table-responsive\" id=\"printdiv\">
				<table class=\"table table-bordered table-hover\">
				<thead>
					<th  align=\"center\" bgcolor=\"#CCCCCC\">Date </th>
					<th  align=\"left\" bgcolor=\"#CCCCCC\">Species</th>
					<th  align=\"left\" bgcolor=\"#CCCCCC\">Strain</th>
					<th align=\"center\" bgcolor=\"#CCCCCC\">Sex</th>
					<th width=\"14%\" align=\"center\" bgcolor=\"#CCCCCC\">Animal No/DOB</th>
					<th  align=\"center\" bgcolor=\"#CCCCCC\">Room No. </th>
					<th align=\"center\" bgcolor=\"#CCCCCC\">Done By </th>
					<th width=\"10%\"  class=\"remOnPrint\" bgcolor=\"#CCCCCC\">&nbsp;</th>
				</thead>
				<tbody>";	
	
	if($tdate != "" && $fdate != ""){
			include "DBconnect.php";
			if($tdate != $fdate)
				{$query= "SELECT * FROM microbialsampling WHERE MCollectionDate BETWEEN '$fdate' AND '$tdate' ORDER BY MSamplingID DESC";}
			else
			{$query= "SELECT * FROM microbialsampling WHERE MCollectionDate = '$tdate' ORDER BY MSamplingID DESC ";}
			
			$result = mysqli_query($db,$query);
			if($result){
				$i=1; 
			
				while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
									
					$str=$str. "<tr>";
					$str=$str. "<td >".$pass['MCollectionDate']."</td>";
								
					$str=$str. "<td >".$pass['Species']. "</td>";
					$str=$str. "<td >".$pass['strain']. "</td>";
					$str=$str. "<td >".$pass['Gender']."</td>";
					
					$str=$str. "<td >" .$pass['AnimalNo']. "</td>";
					$str=$str. "<td >" .$pass['RoomNo']. "</td>";
					$str=$str. "<td >".$pass['MCollectedBy']."</td>";
					$str=$str."<td class=\"remOnPrint\">
							<form action=\"EditMicrobial.php\" method=\"POST\">
								<input type=\"hidden\" name=\"prno\" value=\"".$pass['MSamplingID']."\">
								<button type=\"submit\" class=\"btn btn-danger\">
									<i class=\"fa fa-btn fa-edit\"></i> Edit
								</button>
							</form>
						</td>";
					$str=$str."</tr>";
					
					$i=$i+1;
				}
									
				if ($i== 1){
					$str=$str. "<tr><td colspan=\"8\" class=\"table-text text-danger\"><div>*No Records found</div></td></tr>";
				}	
				
				mysqli_free_result($result);
			}else{
				$str=$str. "<tr><td colspan=\"8\" class=\"table-text text-danger\"><div>*Error, Contact Admin.</div></td></tr>";
			}
			
		mysqli_close($db);
	}else{
			$str=$str. "<tr><td colspan=\"8\" class=\"table-text text-danger\"><div>*Error, Contact Admin.</div></td></tr>";
	}
	$str=$str."</tbody>
			</table>
		</div>
	</div>";
	echo $str;			
	?>
 