<?php include "include/sesionlauth.php"; ?>
 <?php 
	
	/*<td width=\"15%\" align=\"center\" bgcolor=\"#CCCCCC\">Stock Type </td>
	<td width=\"17%\" align=\"center\" bgcolor=\"#CCCCCC\">Production Type </td>
	Date species sex age (Animals acquired Name, Address and date) */
	
	include "DBconnect.php";
		//production(ProductionNo, ProductionCode, Species, strain, StockType, MALE, Female, ProductionDate)
		
		$query2= "SELECT * FROM production WHERE ProductionCode='In house' ORDER BY ProductionDate DESC";
		$result2 = mysqli_query($db,$query2);
		$i=1;
		$str="<div class=\"panel-heading\">
				<button type=\"button\" class=\"btn btn-danger\" onclick=\"javascript:printDiv('printdiv')\" ><i class=\"fa fa-btn fa-print\"></i> Print</button>
				<span class=\"text-primary\" >&nbsp;&nbsp;&nbsp;&nbsp;	Form C data</span>
			</div>

			<div class=\"panel-body  table-responsive\" id=\"printdiv\">
			<table class=\"table table-bordered table-hover\">";
			
		$str=$str."<tr width=\"100%\"> <td width=\"100%\"> 
		<table class=\"table table-bordered table-hover\" width=\"100%\"> 
		<caption class=\"text-success\"> <strong>Bred(In House) </strong></caption>";
		$str=$str."<tr>
			<th width=\"20%\" align=\"center\" bgcolor=\"#CCCCCC\">Date</th>
			<th width=\"25%\" align=\"left\" bgcolor=\"#CCCCCC\">Species</th>
			<th width=\"25%\" align=\"left\" bgcolor=\"#CCCCCC\">Strain</th>
			<th width=\"15%\" align=\"center\" bgcolor=\"#CCCCCC\">Male </th>
			<th width=\"15%\" align=\"center\" bgcolor=\"#CCCCCC\">Female</th>
			</tr>";
		while($pass2=mysqli_fetch_array($result2,MYSQLI_ASSOC)){
			$str=$str."<tr bgcolor=\"#FFFFFF\"><td width=\"20%\">".$pass2['ProductionDate']."</td>";
			//$str=$str."<td width=\"30%\">".$pass2['ProductionCode']."</td>";
			$str=$str."<td width=\"25%\">" .$pass2['Species']. "</td>";
			$str=$str. "<td width=\"25%\">" .$pass2['strain']. "</td>";
			//$str=$str. "<td >".$pass2['StockType']. "</td>";
			$str=$str."<td width=\"15%\">".$pass2['MALE']."</td>";
			$str=$str."<td width=\"15%\">".$pass2['Female']."</td>";
			
			$i++; 
		}
			
		if ($i== 1 ){
			$str=$str."<tr height="."30"."><td colspan="."6"." align="."center"." class="."norecord"." >No Records found.</td></tr>";
		}
		$str=$str."</table></td></tr>";
		echo $str;
	
	mysqli_free_result($result2);
	//end of Bred.....start of acuired
		$query2= "SELECT * FROM production WHERE ProductionCode <> 'In house' ORDER BY ProductionDate DESC";
		$result2 = mysqli_query($db,$query2);
		$i=1;
		$str="<tr width=\"100%\"> <td width=\"100%\"> <table class=\"table table-bordered table-hover\" width=\"100%\"> <caption class=\"text-success\"><strong>Acquired</strong> </caption>";
		$str=$str."<tr>
			<th width=\"20%\" align=\"center\" bgcolor=\"#CCCCCC\">Date</th>
			<th width=\"25%\" align=\"left\" bgcolor=\"#CCCCCC\">Species</th>
			<th width=\"25%\" align=\"left\" bgcolor=\"#CCCCCC\">Strain</th>
			<th width=\"15%\" align=\"center\" bgcolor=\"#CCCCCC\">Male </th>
			<th width=\"15%\" align=\"center\" bgcolor=\"#CCCCCC\">Female</th>
			</tr>";
		while($pass2=mysqli_fetch_array($result2,MYSQLI_ASSOC)){
			$str=$str."<tr bgcolor=\"#FFFFFF\" width=\"20%\"><td>".$pass2['ProductionDate']."</td>";
			//$str=$str."<td >".$pass2['ProductionCode']."</td>";
			$str=$str."<td width=\"25%\">" .$pass2['Species']. "</td>";
			$str=$str. "<td width=\"25%\">" .$pass2['strain']. "</td>";
			//$str=$str. "<td >".$pass2['StockType']. "</td>";
			$str=$str."<td width=\"15%\">".$pass2['MALE']."</td>";
			$str=$str."<td width=\"15%\">".$pass2['Female']."</td>";
			
			$i++; 
		}
			
		if ($i== 1 ){
			$str=$str."<tr height="."30"."><td colspan="."9"." align="."center"." class="."norecord"." >No Records found.</td></tr>";
		}
		$str=$str."</table></td></tr>";
		echo $str;
	
	mysqli_free_result($result2);
	
	//end of aquired ...start of Transferred
	
	
	$query= "SELECT SupplyID,SupplyTo, Supplydate, SupplyFrom, SupplyBillNo,PorT FROM supply ORDER BY Supplydate DESC";
			
			$result = mysqli_query($db,$query);
			$i=1; 
			$str="<tr width=\"100%\"> <td width=\"100%\"> <table class=\"table table-bordered table-hover\" width=\"100%\"> <caption class=\"text-success\"><strong>Transferred</strong></caption>";
			$str=$str."<tr>
				<th bgcolor=\"#CCCCCC\" width=\"7%\" rowspan=\"2\" align=\"center\" >Date</th>
				<th bgcolor=\"#CCCCCC\" width=\"7%\" rowspan=\"2\" align=\"center\" >Species</th>
				<th bgcolor=\"#CCCCCC\" width=\"6%\" rowspan=\"2\"align=\"center\" >Strain</th>
				<th bgcolor=\"#CCCCCC\" width=\"4%\" rowspan=\"2\" align=\"center\" >Male</th>
				<th bgcolor=\"#CCCCCC\" width=\"6%\"rowspan=\"2\" align=\"center\" >Female</th>
				<th bgcolor=\"#CCCCCC\" width=\"6%\" rowspan=\"2\" align=\"center\" >Bill No.</th>
				<th bgcolor=\"#CCCCCC\" colspan=\"3\" align=\"center\" >Transferred to </th>
				</tr>
				<tr>
				<th bgcolor=\"#CCCCCC\" width=\"10%\" align=\"center\" >Name</th>
				<th bgcolor=\"#CCCCCC\" width=\"9%\" align=\"center\" >Address</th>
				<th bgcolor=\"#CCCCCC\" width=\"10%\" align=\"center\" >Registration Number </th>
				</tr>";
			while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
				$spid=$pass['SupplyID'];
				$spdata=$pass['Supplydate'];
				$spto=$pass['SupplyTo'];
				$spfrom=$pass['SupplyFrom'];
				$SupplyBillNo=$pass['SupplyBillNo'];
				$port=$pass['PorT'];
				//animalbuyer(BCode, Bname, BRegNum, BAddress, Bpin, Bphone, Bmobile, BEmail)
				//anbuyer(BCode, Bname, BRegNum, BRdate, BAddress, Bpin, Bphone, Bmobile, BEmail)
				$Bname="";
				$BRegNum="";
				$BAddress="";
				$Bpin="";
				if($port==1){
					$queryBuyer= "SELECT DISTINCT Piname, PiAddress, Pin FROM projectincharge WHERE PiEmail IN (SELECT DISTINCT PiEmail FROM projects WHERE ProjectCode='$spto')";
				//projectincharge(Piname, PiDesignation, PiDepartment, Piphone, Pimobile, PiEmail, PiExperience, PiPasscode, Role, PiAddress, Pin)
				//`projects`(`ProjectCode`, `ProjectName`, `PrincipalInvestigator`, `ApprovalDate`, `FromDate`, `ToDate`, `PiEmail`,
					$resultBuyer = mysqli_query($db,$queryBuyer);
					if($passBuyer=mysqli_fetch_array($resultBuyer,MYSQLI_ASSOC)){
						$Bname=$passBuyer['Piname'];
						$BRegNum=$spto;
						$BAddress=$passBuyer['PiAddress'];
						$Bpin=$passBuyer['Pin'];
					}
				}else{
					$queryBuyer= "SELECT Bname, BRegNum, BAddress,Bpin FROM anbuyer WHERE BCode ='$spto' ";
				
					$resultBuyer = mysqli_query($db,$queryBuyer);
					if($passBuyer=mysqli_fetch_array($resultBuyer,MYSQLI_ASSOC)){
						$Bname=$passBuyer['Bname'];
						
						$BAddress=$passBuyer['BAddress'];
						$BRegNum=$passBuyer['BRegNum'];
						$Bpin=$passBuyer['Bpin'];
					} 
				}
				//supplyanimal(EntrySupplyNumber, SupplyID, Species, strain, StockType, MALE, Female)
				$query1= "SELECT Species, strain, StockType, MALE, Female FROM supplyanimal WHERE SupplyID ='$spid' ";
			
				$result1 = mysqli_query($db,$query1);
				while($pass1=mysqli_fetch_array($result1,MYSQLI_ASSOC)){
					$str=$str."<tr>";
					$str=$str. "<td >".$spdata."</td>";
					$str=$str. "<td >" .$pass1['Species']. "</td>";
					$str=$str. "<td >" .$pass1['strain']."</td>";
					$str=$str. "<td >" .$pass1['MALE']."</td>";
					$str=$str. "<td >" .$pass1['Female']."</td>";
					$str=$str. "<td >".$SupplyBillNo."</td>";
					$str=$str. "<td >".$Bname."</td>";
					
					$str=$str. "<td >".$BAddress."-".$Bpin."</td>";
					$str=$str. "<td >".$BRegNum."</td>";
					$str=$str."</tr>";
					$i=$i+1;
				}
			}
								
			if ($i== 1){
				$str=$str."<tr height="."30"."><td colspan="."10"." align="."center"." class="."norecord"." >No Records found.</td></tr>";
			}	
			
			mysqli_free_result($result);
			
	
	mysqli_close($db);
	$str=$str."</table></td></tr>";
			$str=$str."
				</div>
			</div>";
			echo $str;	
	?>