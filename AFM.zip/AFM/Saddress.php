<?php include "include/sesionlauth.php"; ?>
 <?php 
	//session_start();
	
	$ascode = $_GET['ascode'];
						
	include "DBconnect.php" ;
	//`ansupplier`(`SCode`, `Sname`, `RegNum`, `Rdate`, `SAddress`, `Spin`, `Sphone`, `Smobile`, `SEmail`)
	$result = mysqli_query($db,"SELECT DISTINCT SAddress,Spin FROM ansupplier WHERE SCode = '$ascode'" );
	
	$str = "";
	if($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
		
		$str = $pass['SAddress']."\nPin-".$pass['Spin'];
		
	}
	echo $str;
	mysqli_free_result($result);
	mysqli_close($db);
		
	?>