<?php include "include/sesionlauth.php"; ?>
 <?php 
		include "DBconnect.php";
			//client(name, clientID, cType, status, mobile1, mobile2, phone1, phone2, email1, email2, region, cState, city, adderss, pin, cRegNum, cRdate)
			$query= "SELECT * FROM anbuyer";
			$i=0;
			$result = mysqli_query($db,$query);
			$str="<div class=\"panel-heading\" id=\"rempbdiv\">
						<h4><button type=\"button\" class=\"btn btn-danger\" onclick=\"printDiv()\"><i class=\"fa fa-btn fa-print\"></i> Print</button> <span class=\"text-primary\" >Clients List</span></h4>
                    </div>

                    <div class=\"panel-body table-responsive\" >
                        <table class=\"table table-striped task-table\" id=\"clientall\">
                            <thead>
                                <th>S.No. </th>
								<th width=\"15%\" > Code </th>
								<th width=\"20%\" > Name </th>
								<th width=\"15%\" > Reg. No. </th>
								<th width=\"20%\" >Email </th>
								<th width=\"18%\" >Contact</th>
								<th width=\"20%\" >Address </th>
								<th class=\"remOnPrint\">&nbsp;</th>
								
                            </thead>
                            <tbody>";
							//client(name, clientID, cType, status, mobile1, mobile2, phone1, phone2, email1, email2, region, cState, city, adderss, pin, cRegNum, cRdate)
							while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
								$i++;
								$str=$str."
								<tr>
									<td >".$i."</td>
									 		
									<td >".$pass['BCode']."</td>
									<td >".$pass['Bname']."</td>
									
									<td >" .$pass['BRegNum']."</td>
									<td >" .$pass['BEmail']."</td>
									<td >" .$pass['Bphone']." / ".$pass['Bmobile']."</td>
									<td >" .$pass['BAddress']." - ".$pass['Bpin']."</td>
									<!-- Task Delete Button -->
									<td class=\"remOnPrint\">
										<form action=\"clientEdit.php\" method=\"POST\">
											<input type=\"hidden\" readonly name=\"clientID\" id=\"clientID\" value=\"".$pass['BCode']."\" />
											<button type=\"submit\" class=\"btn btn-primary\">
												<i class=\"fa fa-btn fa-edit\"></i> Edit
											</button>
										</form>
									</td>
									
								</tr>";
							}
							if ($i== 0){
								$str=$str. "<tr><td colspan=\"9\" class=\"table-text text-danger\"><div>*No Records found</div></td></tr>";
							}
							$str=$str."</tbody>
							
                        </table>
                    </div>
                </div>";
				
			echo $str;
			
	mysqli_free_result($result);
	mysqli_close($db);
?>