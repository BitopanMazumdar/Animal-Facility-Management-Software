<?php include "include/sesionlauth.php"; ?>
 
<?php 

$room=filter_var($_POST['room'], FILTER_SANITIZE_STRING);
$edate=filter_var($_POST['edate'], FILTER_SANITIZE_STRING);
$time=filter_var($_POST['time'], FILTER_SANITIZE_STRING);
$emin=filter_var($_POST['emin'], FILTER_SANITIZE_STRING);
$emax=filter_var($_POST['emax'], FILTER_SANITIZE_STRING);
$havg=filter_var($_POST['havg'], FILTER_SANITIZE_STRING); 
$lintensity=filter_var($_POST['lintensity'], FILTER_SANITIZE_STRING); 
$av=filter_var($_POST['av'], FILTER_SANITIZE_STRING);
$sound=filter_var($_POST['sound'], FILTER_SANITIZE_STRING);

if($room!=""){
	include "DBconnect.php" ;

	$sql="INSERT INTO temperature(RoomNo, EntryDate, EntryTime, MinTemperature, MaxTemperature, Humidity,Lintensity, Avelocity, Sound) values ('$room', '$edate', '$time', '$emin', '$emax', '$havg','$lintensity','$av','$sound')";

	$Result = mysqli_query($db, $sql);


	if(!$Result)
	  {
		$_SESSION['message']="Error, Contact admin  !";
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=MonitoringRegister.php">';
		die('Error: ' . mysqli_error($db));
		
	  }
	else
	{	
		$_SESSION['message']="Successfully submitted  !";
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=MonitoringRegister.php">';
		
	}

	mysqli_close($db);
}else{
	$_SESSION['message']="Error, Invalid input  !";
	echo '<META HTTP-EQUIV="Refresh" Content="0; URL=MonitoringRegister.php">';
}
?>
