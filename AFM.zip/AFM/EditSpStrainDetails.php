<?php include "include/sesionlauth.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  
</head>
<body style="background-color:#F8F9FA">
	<nav >
		 <div class="container-fluid">
			<?php 
			include"include/headerboot.php"; 
			?>
		  </div>
		  <div class="container-fluid">
			<?php 
			include"include/MenuAi.php"; 
			?>		
		  </div> 
	</nav>
	
 <!-- srcipt strat -->
<script type="text/javascript">
$(document).ready(function(){
	$("#displaydiv").slideDown("slow");
});

function getStrain(val,no)
{
	
$.get("strain_query.php",
  {
    sp:val
  },
  function(data,status){
  //sleep(1000);
 
    $("#strain"+no).html(data);
    //$("#strain"+no).css("width":"150px");
  });
}
</script>

 <!-- srcipt end -->
<div>&nbsp;</div>

<?php $pcode=filter_var($_POST['pid'], FILTER_SANITIZE_STRING); ?>
 <div class="container" >
        <div class="col-sm-offset-2 col-sm-8 ">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="row col-sm-12">
						<div class="col-sm-6">
						<h4><span class="col-sm-12 text-primary"><i class="fa fa-archive"></i> Protocol Management </span></h4>
						</div>
						<div class="col-sm-3">
						<form class="form horizontal" action="EditSpStrainDetails.php" method="POST" name="editanimal">
							<input class="col-sm-8" type="hidden" name="pid" value="<?php echo $pcode; ?>">
							<button type="submit" class="btn btn-danger">
								<i class="fa fa-btn fa-edit"></i>Edit Animal
							</button>
						</form>
						</div>
						<div class="col-sm-3">
						<form class="form horizontal" action="AddProjSpStrain.php" method="POST" name="addanimal">
							<input class="col-sm-8" type="hidden" name="pid" value="<?php echo $pcode; ?>">
							<button type="submit" class="btn btn-success">
								<i class="fa fa-btn fa-plus"></i>ADD Animal
							</button>
						</form>
						</div>
					</div>	
                </div>

                <div class="panel-body">
                    <!-- submit message -->
						<?php 
								if(isset($_SESSION['message'])){
									echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
									unset($_SESSION['message']);
								}		
						?>
					                    
                </div>
            </div>
		</div>
</div>
 <div class="container" id="displaydiv" style="display:none">
	
		<?php 
			 //projects(ProjectCode, ProjectName, PrincipalInvestigator, ApprovalDate, FromDate, ToDate, PiEmail, created_at, updated_at, author)
			
			//$str="";
			if($pcode!=""){
				include"DBconnect.php";
				$query= "SELECT * FROM projectanimal WHERE ProjectCode = '$pcode' ORDER BY IssueYear";
				$result = mysqli_query($db,$query);
				if($result){
					$str="<div class=\"panel-heading\">
							<h4 class=\"text-primary\"><i class=\"fa fa-edit\"></i> Edit Animal information of Protocol: ".$pcode."</h4>
						</div>

                    <div class=\"panel-body  table-responsive\" >
						<form name=\"myform\" action=\"EditSD_proccess.php\" method=\"post\" >
                        <table class=\"table table-striped table-hover\">
                            <thead>
                                <th>Species</th>
								<th>Strain</th>
								<th>Gender</th>
								<th>No. Of animal</th>
								<th>Weight/Age</th>
								<th>Year</th>
                            </thead>
                            <tbody>";
					echo $str;
					$j=1;
					while($pass1=mysqli_fetch_array($result,MYSQLI_ASSOC)){
			 
						echo "<tr>
							<td>
								<select required  id=\"species".$j."\" class=\"form-control\" name=\"species".$j."\" onchange=\"getStrain(this.value,".$j.")\" required >
								<option value=\"\" >Select</option>";
								
									$resultsp = mysqli_query($db,"SELECT DISTINCT Species FROM animals");
									while($passsp=mysqli_fetch_array($resultsp,MYSQLI_ASSOC)){
									echo "<option value=\"".htmlspecialchars($passsp['Species'])."\">".htmlspecialchars($passsp['Species'])."</option>";
									}
									mysqli_free_result($resultsp);            
							echo " </select>
						</td>
						<td align=\"center\" id=\"selstrain1\">
							<select required id=\"strain".$j."\" class=\"form-control\" name=\"strain".$j."\">
								<option value=\"".htmlspecialchars($pass1['strain'])."\" selected=\"selected\">".htmlspecialchars($pass1['strain'])."</option>
							</select>
						</td>
						
											
						  
						  <td><select class=\"form-control\" id=\"sex".$j."\" name=\"sex".$j."\" />
								<option value=\"".htmlspecialchars($pass1['Gender'])."\">".htmlspecialchars($pass1['Gender'])."</option>
								<option value=\"Male\">Male</option>
								<option value=\"Female\">Female</option>
						  </select>
						  </td>";
						  
						  echo "<input type=\"hidden\" id=\"rowno\" name=\"rowno\" value=\"".$j."\"  />
						  <input type=\"hidden\" id=\"EntryNumber".$j."\" name=\"EntryNumber".$j."\" value=\"".htmlspecialchars($pass1['EntryNumber'])."\"  />";		  
						  
						  echo "<td><input class=\"form-control\" size=\"10%\" type=\"number\" name=\"noa".$j."\" id=\"noa".$j."\" value=\"".htmlspecialchars($pass1['NoAnimal'])."\" onchange=\"checkNo(this.value,".htmlspecialchars($pass1['NoAnimal']).",".$j.")\" /></td>
						  <td><input class=\"form-control\" type=\"text\" id=\"age".$j."\" name=\"age".$j."\" value=\"".htmlspecialchars($pass1['Weight_Age'])."\"  /></td>
						  <td><input class=\"form-control\" type=\"text\" id=\"issueyear".$j."\" name=\"issueyear".$j."\" value=\"".htmlspecialchars($pass1['IssueYear'])."\"  /></td>
						</tr>"; 
						$j++;
					}
					
					mysqli_free_result($result);
					mysqli_close($db);
				}else{
					$_SESSION['message']="Error  ! Contact admin !";	
				}
			}else{
				$_SESSION['message']="Invalid Input !";
			}
		?> 
	</tbody>
	
	<input type="hidden" id="prcode" name="prcode" value="<?php echo $pcode; ?>" />
		</table>
		<div class="form-group">
		<div class="col-sm-offset-4 col-sm-6">
			<button type="submit" class="btn btn-danger">
				<i class="fa fa-btn fa-edit"></i> Edit
			</button>
			<button type="button" class="btn btn-warning" onclick="parent.location='Projects.php'">
				<i class="fa fa-btn fa-arrow-left"></i> Back
			</button>
		</div>
	</div>
</form>
	</div>
</div>

	<div>&nbsp;</div>
	<div>&nbsp;</div>
	
	<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
	</div>
	
</body>
</html>	

	