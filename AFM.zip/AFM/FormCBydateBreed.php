<?php include "include/sesionlauth.php"; ?>
 <?php 
	$sd = $_GET['sd'];
	$sd1 = $_GET['sd1'];
	$str="<div class=\"panel-heading\">
				<button type=\"button\" class=\"btn btn-danger\" onclick=\"javascript:printDiv('printdiv')\" ><i class=\"fa fa-btn fa-print\"></i> Print</button>
				<span class=\"text-primary\" >&nbsp;&nbsp;&nbsp;&nbsp;	Form C data</span>
			</div>

			<div class=\"panel-body  table-responsive\" id=\"printdiv\">
				<table class=\"table table-bordered table-hover\">
				<caption class=\"text-success\"><strong>Breed (In house)</strong></caption>
				<tr>
				<th width=\"17%\" align=\"center\" bgcolor=\"#CCCCCC\">Date</th>
				<th width=\"25%\" align=\"left\" bgcolor=\"#CCCCCC\">Species</th>
				<th width=\"30%\" align=\"left\" bgcolor=\"#CCCCCC\">Strain</th>
				<th width=\"13%\" align=\"center\" bgcolor=\"#CCCCCC\">Male </th>
				<th width=\"13%\" align=\"center\" bgcolor=\"#CCCCCC\">Female</th>
				</tr>
				<tbody>";		
	if($sd != "" && $sd1 != ""){
	
	/*<td width=\"15%\" align=\"center\" bgcolor=\"#CCCCCC\">Stock Type </td>
	<td width=\"17%\" align=\"center\" bgcolor=\"#CCCCCC\">Production Type </td>
	Date species sex age (Animals acquired Name, Address and date) */
	
	include "DBconnect.php";
		//production(ProductionNo, ProductionCode, Species, strain, StockType, MALE, Female, ProductionDate)
		
		$query2= "SELECT * FROM production WHERE (ProductionCode='In house' AND ProductionDate BETWEEN '$sd' AND '$sd1') ORDER BY ProductionDate DESC";
		$result2 = mysqli_query($db,$query2);
		$i=1;
		
		while($pass2=mysqli_fetch_array($result2,MYSQLI_ASSOC)){
			$str=$str."<tr>";
			$str=$str."<td>".$pass2['ProductionDate']."</td>";
			//$str=$str."<td >".$pass2['ProductionCode']."</td>";
			$str=$str."<td >" .$pass2['Species']. "</td>";
			$str=$str. "<td >" .$pass2['strain']. "</td>";
			//$str=$str. "<td >".$pass2['StockType']. "</td>";
			$str=$str."<td >".$pass2['MALE']."</td>";
			$str=$str."<td >".$pass2['Female']."</td>";
			$str=$str."</tr>";
			$i++; 
		}
			
		if ($i== 1 ){
			$str=$str."<tr height="."30"."><td colspan="."8"." align="."center"." class="."norecord"." >No Records found.</td></tr>";
		}
		$str=$str."</table></td></tr>";
		
	
	mysqli_free_result($result2);
	mysqli_close($db);
		
	
	}else{
		$str=$str."<tr bgcolor=\" #9F5E45\"> <td colspan=\"5\" align=\"center\" > You have not select Date! </td></tr>";
	}
$str=$str."
		</div>
	</div>";
	echo $str;		
	?>