<?php include "include/sesionlauth.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  <link rel="stylesheet" href="css/custom.css">
</head>
<body style="background-color:#F8F9FA">
	<nav >
		 <div class="container-fluid">
			<?php 
			include"include/headerboot.php"; 
			?>
		  </div>
		  <div class="container-fluid">
			<?php 
			include"include/MenuAi.php"; 
			?>		
		  </div> 
	</nav>
	
 <!-- srcipt strat -->
<script type="text/javascript">
$(document).ready(function(){
	$("#displaydiv").slideDown("slow");
	$("#displaydiv2").slideDown("slow");
});
</script>

<script type="text/javascript">
$(document).ready(function(){
	
	$.get("Supplier_query.php", function(data, status){
		$("#AIFcode").html(data);
		
	});	
		
});

</script>
<!-- srcipt end -->

<!-- Script start-->
<script type="text/javascript">     

function getStrain(val,no)
{
prj=$("#pcode").val();
type=$("input[name='spt']:checked").val();
	  
	   if(type==0){
		   $.get("strain_query.php",
			  {
				sp:val
			  },
			  function(data,status){
			  //sleep(1000);
			 
				$("#strain"+no).html(data);
				//$("#strain"+no).css("width":"150px");
			  });
	   }else{
		   
		   $.get("strainByProject.php",
		  {
			sp:val,
			prcode:prj
		  },
		  function(data,status){
		  //sleep(1000);
		 
			$("#strain"+no).html(data);
			//$("#strain"+no).css("width":"150px");
		  });
	   }

}
function getSpecies(no,prjcode){
	
	$.get("SpStrainByProjSupply.php", {prcode:prjcode},function(data, status){
		
		$("#species"+no).html(data);
	});
}


$(document).ready(function(){
   $("#addRow").click(function(){   
   val=$("#row_no").val();
   pval=$("#pcode").val();
   if(val!=7)
   {
	   val++;
	   //type=$("#spt").val(); //calling function for getting species for transfer and project
	   type=$("input[name='spt']:checked").val();
	   
	   if(type==1){
		   getSpecies(val,pval);
	   }else{
		   
		   getSpeciesTransfer(val);
	   }
		$("#row_no").val(val);
		$("#row"+val).slideDown();
		$("#close"+val).show();
		val--;
		$("#close"+val).hide();
    }
  }); 
	 
});



function Close(val)
{

 $("#row"+val).slideUp();
 val--;
 $("#row_no").val(val);
 $("#close"+val).show("slow");
 }

</script>

<script type="text/javascript">   

function SpeciesByProjectcode(projcode){
	
	$.get("SpStrainByProjSupply.php",{prcode:projcode}, function(data, status){
		//alert(data);
		$("#species1").html(data);
	});
}
</script>

<!-- Validation-->


<script type="text/javascript">
function valid(){
	frm = document.myform;
	no=frm.row_no.value;
		
	  if(frm.spt.value ==""){
			alert("Please select Supply to ! ");
			frm.spt.focus();
			return false;
	  }
	  if(frm.sdate.value ==""){
			alert("Please enter Supply date !");
			frm.sdate.focus();
			return false;
	  }
	   if(frm.spt.value !="1" && frm.bname.value ==""){
			alert("Please select institute code ! ");
			frm.bname.focus();
			return false;
	  }
	  
	  if(frm.spt.value =="1" && (frm.iname.value =="" || frm.iname.value =="select")){
			alert("Please enter Investigator Name !");
			frm.iname.focus();
			return false;
	  }
	  if(frm.spt.value =="1" && (frm.pcode.value =="" || frm.iname.value =="select"))
	  {
			alert("Please select Project Code ! ");
			frm.pcode.focus();
			return false;
	  }
	  if(frm.sname.value ==""){
			alert("Please Select Supplier Code !");
			frm.sname.focus();
			return false;
	  }
	  for(j=1;j<=no;j++)
		{
					
		  if(document.getElementById("strain" + j).value =="" && document.getElementById("species" + j).value =="")
		  {
				alert("Please enter species/starin !");
				document.getElementById("species" + j).focus();
				return false;
		  }
		  if(document.getElementById("stock" + j).value =="")
		  {
				alert("Please specify Stock Type !");
				document.getElementById("stock" + j).focus();
				return false;
		  }
		  		  
		 if(document.getElementById("qm" + j).value =="" && document.getElementById("qf" + j).value =="")
		  {
				alert("Please enter quantity (MALE/Female) !");
				document.getElementById("qm" + j).focus();
				return false;
		  }
		  
		  		  
		}
		for(j=1;j<=no;j++)
		{
			if(document.getElementById("strain" + j).value =="")
			  {
				  alert("Reminder: You have not selected Strain for row no. = "+j);
				  document.getElementById("strain" + j).focus();
			  }
		}			  
	  r=confirm("confirm submission!");
	  if(r==true){
		  return true;
	  }else{
		  frm.name.focus;
		  return false;
	  }
	  
}
function malenumber(quantity,no){
	sp=$("#species"+no).val();
	st=$("#strain"+no).val();
	stock=$("#stock"+no).val();
	if(sp==""){
		alert("please select Species");
		$("#qm"+no).val(0);
		return false;
	}
	if(stock==""){
		alert("please select Stock Type");
		$("#qm"+no).val(0);
		return false;
	}
	$.get("checkmalenumber.php",{mq:quantity, sp:sp, st:st, stock:stock}, function(data, status){
		//alert(data);
		if(data==-1){
			return true;
		}else if(data==-2){
			$("#qm"+no).val(0);
			alert("stock not available in animal house! Species: "+sp+" Strain: "+st +" Stock Type: "+stock);
			return false;
		}else{
			$("#qm"+no).val(0);
			alert("Quantity is more than available stock! Available stock = "+data);
			return false;
			
		}
	});
}
function femalenumber(quantity,no){
	sp=$("#species"+no).val();
	st=$("#strain"+no).val();
	stock=$("#stock"+no).val();
	if(sp==""){
		alert("please select Species");
		$("#qf"+no).val(0);
		return false;
	}
	if(stock==""){
		alert("please select Stock Type");
		$("#qf"+no).val(0);
		return false;
	}
	$.get("checkfemalenumber.php",{fq:quantity, sp:sp, st:st, stock:stock}, function(data, status){
		//alert(data);
		if(data==-1){
			return true;
		}else if(data==-2){
			$("#qm"+no).val(0);
			alert("stock not available in animal house! Species: "+sp+" Strain: "+st +" Stock Type: "+stock);
			return false;
		}else{
			$("#qm"+no).val(0);
			alert("Quantity is more than available stock! Available stock = "+data);
			return false;
			
		}
	});
}
</script>
<script type="text/javascript">
function CheckDuplicate(no)
{
	z=$("#row_no").val();
	for(x=1;x<=z;x++)
	{	
		if(x!=no)
		{
				
			if(($("#species"+x).val()==$("#species"+no).val()) && ($("#strain"+x).val()==$("#strain"+no).val()) && ($("#stock"+x).val()==$("#stock"+no).val())){
				$("#strain"+no).val("");
				$("#species"+no).val("");
				$("#stock"+no).val("");				
				alert("Species,Strain and stock type allready selected");
			}
				
		}
	}
}
</script>
<!-- Script end-->
<div>&nbsp;</div>

<?php 
$pcode=htmlspecialchars($_POST['pcode']);
$inumber=htmlspecialchars($_POST['inumber']);  
?>
 <div class="container" >
    <div class="col-sm-offset-2 col-sm-8 ">
	<!-- submit message -->
		<?php 
				if(isset($_SESSION['message'])){
					echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
					unset($_SESSION['message']);
				}		
		?>		                    
    </div>
		<h4><span class="col-sm-12 text-primary"><i class="fa fa-check"></i>Animal Request Management </span></h4>
                   
</div>
 <div class="container" id="displaydiv" style="display:none">
	<!-- submit message -->
						<?php 
								if(isset($_SESSION['message'])){
									echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
									unset($_SESSION['message']);
								}		
						?>
					<!-- submit message -->	
	 <form action="IssueReply_process.php" method="post" name="issue_form" id="issue_form" onsubmit="return valid();" class="form-horizontal">
		<?php 
			include "DBconnect.php";
			$result = mysqli_query($db,"SELECT IndentNumber, Projectcode, Title,  RName, ARDate,IndentTime, Duration, TAssistance, SRequest FROM indentform WHERE IndentNumber='$inumber'");
			
			if($result){
				$str="<div class=\"container\" >
				<div class=\"panel panel-success\">
				<div class=\"panel-heading\">
					Animal Request Details
				</div>
				<div class=\"panel-body  table-responsive\" >
					<table class=\"table table-striped table-hover\">
						<thead>
							<th>Protocol</th>
							<th>Title</th>
							<th>Requested By</th>
							<th>Needed On</th>
							<th>Time</th>
							<th>Duration</th>
							<th>Assistant</th>
							<th>Sp. Request</th>
						</thead>
						<tbody>";
					
				$i=1;
				while($pass=mysqli_fetch_array($result,MYSQLI_BOTH)){
					//IndentNumber, Projectcode, Title,  RName, ARDate,IndentTime, Duration, TAssistance, SRequest
					$str=$str."<tr> 
							<td class=\"table-text\"><div>".htmlspecialchars($pass['Projectcode'])."</div></td>
							<td class=\"table-text\"><div>".htmlspecialchars($pass['Title'])."</div></td>
							<td class=\"table-text\"><div>".htmlspecialchars($pass['RName'])."</div></td>
							<td class=\"table-text\"><div>".htmlspecialchars($pass['ARDate'])."</div></td>
							<td class=\"table-text\"><div>".htmlspecialchars($pass['IndentTime'])."</div></td>
							<td class=\"table-text\"><div>".htmlspecialchars($pass['Duration'])."</div></td>
							<td class=\"table-text\"><div>".htmlspecialchars($pass['TAssistance'])."</div></td>
							<td class=\"table-text\"><div>".htmlspecialchars($pass['SRequest'])."</div></td>
						</tr>";
						$i++;
					//responseanimal(ResponseEntryId, ResponseNumber, SPStrain, Gender, Weight_Age, NoAnimal, IndentNumber)	
					$result1 = mysqli_query($db,"SELECT ResponseEntryId, ResponseNumber, SPStrain, Gender, Weight_Age, NoAnimal FROM responseanimal WHERE IndentNumber='$inumber'");
					$j=0;
					if($result){
						$str=$str."<tr>
						<td colspan=\"9\">
						<div class=\"table responsive\">
						<table class=\"table\" border=\"1\" style=\"border-color: #666;border-collapse:collapse;width:80%;\" cellpadding=\"10\" align=\"center\">
							<tr>
								<th>Line</th>
								<th>Animal</th>
								<th>Gender</th>
								
								<th>Quantity</th>
								<th>Wieght/Age</th> 
								<th>StockType</th>  
							</tr>
								
								<input type=\"hidden\" id=\"inum\" name=\"inum\" value=\"".$inumber."\"  />
								";
							
						while($pass1=mysqli_fetch_array($result1,MYSQLI_BOTH)){
							$j++;
							$str=$str."<tr>
								<input type=\"hidden\" name=\"pc\" value=\"".htmlspecialchars($pass1['ResponseNumber'])."\" />
								<input type=\"hidden\" name=\"ResponseEntryId".$j."\" value=\"".htmlspecialchars($pass1['ResponseEntryId'])."\" />
								<td class=\"table-text\"><div>".$j."</div></td>
								<td class=\"table-text\"><div>
									<input class=\"form-control\" type=\"text\" readonly id=\"strain".$j."\" name=\"strain".$j."\" value=\"".htmlspecialchars($pass1['SPStrain'])."\" />
								</div></td>
								
								<td class=\"table-text\"><div>
									<input class=\"form-control\" type=\"text\" readonly  id=\"sex".$j."\" name=\"sex".$j."\" value=\"".htmlspecialchars($pass1['Gender'])."\"  />
								</div></td>
								
								<td class=\"table-text\"><div>
									<input class=\"form-control\" size=\"10%\" type=\"number\" min=\"1\" name=\"isno".$j."\" id=\"isno".$j."\"  value=\"".htmlspecialchars($pass1['NoAnimal'])."\"   />
								</div></td>
								<td class=\"table-text\"><div>
									<input class=\"form-control\" readonly type=\"text\" id=\"age".$j."\" name=\"age".$j."\" value=\"".htmlspecialchars($pass1['Weight_Age'])."\"  />
								</div></td>
								<td class=\"table-text\"><div>
									<select required class=\"form-control\" name=\"stock".$j."\" id=\"stock".$j."\" onchange=\"CheckDuplicate(2);\" >
										<option value=\"\">Select</option>
										<option value=\"Breeding Pair\">Breeding Pair</option>
										<option value=\"Issue Stock\">Issue Stock</option>
									</select> 
								</div></td>
							</tr>";			  
						
						}
					$str=$str."<input type=\"hidden\" id=\"rowno\" name=\"rowno\" value=\"".$j."\"  />	
								</table>
							</div>
						</td>
					</tr>
					</tbody>
				</table>
			</div>
	
		";
					}else{
						//
					}
				}
			}else{
				//
			}
					
			echo $str;
			
			mysqli_free_result($result);
			mysqli_close($db);
				 					
		?> 
		<div class="form-group">
			<div class="col-sm-offset-4 col-sm-6">
				<button type="submit" class="btn btn-success">
					delivered <i class="fa fa-btn fa-paper-plane"></i>
				</button>
				<button type="button" class="btn btn-warning" onclick="window.history.back()">
					<i class="fa fa-btn fa-arrow-left"></i> Back
				</button>
			</div>
		</div>
	</form>
</div>
	
	
	<div>&nbsp;</div>
	<div>&nbsp;</div>
	
	<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
	</div>
	
</body>
</html>	