<?php include "include/sesionlauth.php"; ?>
 <?php 

$FumigationID=$_POST['FumigationID'];
$fdate=filter_var($_POST['fdate'], FILTER_SANITIZE_STRING); 
$room=filter_var($_POST['room'], FILTER_SANITIZE_STRING);
$durt=filter_var($_POST['durt'], FILTER_SANITIZE_STRING);
$fdbye=filter_var($_POST['fdby'], FILTER_SANITIZE_STRING);

	//fumigationregister(FumigationID, FumigationDate, RoomNo, Duration, FumigationBy) ('$fdate', '$room', '$durt','$fdbye')

	if($FumigationID!="" && $room!=""){
		include "DBconnect.php";
		
		$query="UPDATE fumigationregister SET  FumigationDate='$fdate', RoomNo='$room', Duration='$durt', FumigationBy='$fdbye' WHERE FumigationID= '$FumigationID'" ;
		mysqli_query($db,$query);
		$result = mysqli_affected_rows($db);
		if($result>=0){
			$_SESSION['message']="Successfully edited";
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=FumigationReport.php">';
		}else{
			$_SESSION['message']="Error, Contact admin";
				echo '<META HTTP-EQUIV="Refresh" Content="0; URL=FumigationReport.php">';
		}
		
		mysqli_close($db);
		
	}else{
		$_SESSION['message']="Invalid input.";
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=FumigationReport.php">';
	}
