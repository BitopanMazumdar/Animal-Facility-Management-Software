<?php include "include/sesionlauth.php"; ?>
 
<?php 
$SupplyID= htmlspecialchars($_POST['prno']);

if($SupplyID!=""){
include"DBconnect.php";

	//supply(SupplyID, SupplyTo, Supplydate, SupplyFrom, SupplyBillNo, PorT)
	$result = mysqli_query($db,"SELECT DISTINCT SupplyID, SupplyTo, Supplydate, SupplyFrom, SupplyBillNo, PorT FROM supply WHERE SupplyID ='$SupplyID'");
	$str="";
	if($result){
	while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
		$prcode=htmlspecialchars($pass['SupplyTo']);
		$PorT=htmlspecialchars($pass['PorT']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta class="form-control" name="viewport" content="width=device-width, initial-scale=1">
 
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  <link rel="stylesheet" href="css/custom.css">
  
</head>
<body style="background-color:#F8F9FA">
<nav >
 <div class="container-fluid">
	<?php 
	include"include/headerboot.php"; 
	?>
  </div>
  <div class="container-fluid">
	<?php 
	include"include/MenuAi.php"; 
	?>		
  </div>
   
</nav>
<!-- Script start-->
<script type="text/javascript">
$(document).ready(function(){
		$("#displaydiv").slideDown("slow");
});
</script>
<script type="text/javascript">  

function getSupplier(sname){
	$.get("SupRegno_query.php",
  {
    snam:sname
  },
  function(data,status){
	 
      $("#srnodate").html(data);
	  });
}
</script>
<script type="text/javascript">  

function getStrain(val,no)
{

prj=$("#suppliedto").val();
type=$("#port").val();
	
	   if(type==0){
		   $.get("strain_query.php",
			  {
				sp:val
			  },
			  function(data,status){
			  //sleep(1000);
				
				$("#strain"+no).html(data);
				//$("#strain"+no).css("width":"150px");
			  });
	   }else{
		   
		   $.get("strainByProject.php",
		  {
			sp:val,
			prcode:prj
		  },
		  function(data,status){
		  //sleep(1000);
			
			$("#strain"+no).html(data);
			//$("#strain"+no).css("width":"150px");
		  });
	   }

}
</script>
<script type="text/javascript">  

function getPain(val,no)
{
alert("hi");
alert(val);
prj=$("#suppliedto").val();
type=$("#port").val();
	
	   if(type==0){
		   $.get("strain_query.php",
			  {
				sp:val
			  },
			  function(data,status){
			  //sleep(1000);
				alert(data);
				$("#strain"+no).html(data);
				//$("#strain"+no).css("width":"150px");
			  });
	   }else{
		   
		   $.get("strainByProject.php",
		  {
			sp:val,
			prcode:prj
		  },
		  function(data,status){
		  //sleep(1000);
			alert(data);
			$("#strain"+no).html(data);
			//$("#strain"+no).css("width":"150px");
		  });
	   }

}
</script>
<!-- Validation-->

<script type="text/javascript">
function valid(){
	//frm = document.myform;				  
	  r=confirm("confirm submission!");
	  if(r==true){
		  return true;
	  }else{
		 return false;
	  }
	  
}
</script>
<script type="text/javascript">
function malenumber(quantity,no){
	sp=$("#species"+no).val();
	st=$("#strain"+no).val();
	stock=$("#stock"+no).val();
	if(sp==""){
		alert("please select Species");
		$("#qm"+no).val(0);
		return false;
	}
	if(stock==""){
		alert("please select Stock Type");
		$("#qm"+no).val(0);
		return false;
	}
	$.get("checkmalenumber.php",{mq:quantity, sp:sp, st:st, stock:stock}, function(data, status){
		//alert(data);
		if(data==1){
			$("#qm"+no).val(0);
			alert("Quantity is more than available stock!");
			return false;
		}else if(data==2){
			$("#qm"+no).val(0);
			alert("stock not available! Species: "+sp+" Strain: "+st +" Stock Type: "+stock);
			return false;
		}else{
			return true;
		}
	});
}
function femalenumber(quantity,no){
	sp=$("#species"+no).val();
	st=$("#strain"+no).val();
	stock=$("#stock"+no).val();
	if(sp==""){
		alert("please select Species");
		$("#qf"+no).val(0);
		return false;
	}
	if(stock==""){
		alert("please select Stock Type");
		$("#qf"+no).val(0);
		return false;
	}
	$.get("checkmalenumber.php",{mq:quantity, sp:sp, st:st, stock:stock}, function(data, status){
		//alert(data);
		if(data==1){
			$("#qf"+no).val(0);
			alert("Quantity is more than available stock!");
			return false;
		}else if(data==2){
			$("#qf"+no).val(0);
			alert("stock not available! Species: "+sp+" Strain: "+st +" Stock Type: "+stock);
			return false;
		}else{
			return true;
		}
	});
}
</script>
<!-- Script end-->
<div class="container" id="displaydiv" style="display:none">
<br>
<!-- submit message -->
	<?php 
		
		if(isset($_SESSION['message'])){
			echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
			unset($_SESSION['message']);
		}
								
	?>
<!-- submit message -->
		<div  class="col-sm-10 col-sm-offset-1">
				<form action="EditSupply_proccess.php" class="form-horizontal" name="myform" method="post" onsubmit="return valid();">
					<div class="form-group">
					<fieldset>
					<legend>Edit supply information</legend>
					<table class="table" align="center" width="70%">
					   <tr id="pcodeh">
						<td width="25%" ><strong>Supplied To</strong></td>
						 <td width="70%" ><input type="text" readonly class="form-control" value="<?php echo htmlspecialchars($pass['SupplyTo']); ?>" />
						  <input type="hidden" id="suppliedto" class="form-control" name="suppliedto"  value="<?php echo htmlspecialchars($pass['SupplyTo']); ?>" />
						 <input type="hidden" id="port" class="form-control" name="port"  value="<?php echo htmlspecialchars($pass['PorT']); ?>" />
						 </td> 
					  </tr>
					 <!-- <tr>
						<td ><strong>Supplied To </strong></td>
						<td ><label for="Project" onclick="changeMode(1)" >
						  <input class="form-control" name="spt" id="Project" type="radio" value="1" checked="checked" />
						  Project </label>
						  <label for="Transferred" onclick="changeMode(0)">
						  <input class="form-control" name="spt" id="Transferred" type="radio" value="0" />
						  Transferred</label></td> 
					  </tr>  -->
					  <tr>
						<td ><strong>Supply Date  </strong></td>
						<td><input required class="form-control" name="sdate" type="date" id="sdate" value="<?php echo htmlspecialchars($pass['Supplydate']); ?>"></td>
					  </tr>	  
					  <tr>
						<td ><strong>Supplier Code</strong></td>
						
							   <?php 
							
								$result2 = mysqli_query($db,"SELECT DISTINCT SCode FROM ansupplier");
								$str="<td><select required class=\"form-control\" name=\"sname\" type=\"text\" id=\"sname\" >
								<option value=\"".htmlspecialchars($pass['SupplyFrom'])."\" >".htmlspecialchars($pass['SupplyFrom'])."</option>";
								
								while($pass2=mysqli_fetch_array($result2,MYSQLI_ASSOC)){
									
									$str = $str ."<option value=\"".htmlspecialchars($pass2['SCode'])."\" >".htmlspecialchars($pass2['SCode'])."</option>";
											
								}
								$str = $str ."</select></td>";
								echo $str;
								mysqli_free_result($result2);
													
								?>   
						</tr>
						<tr >
					<th><strong>Bill No. </strong></th>
				   <td><input required class="form-control" name="billno"  type="text" id="billno" size="15" value="<?php echo htmlspecialchars($pass['SupplyBillNo']); ?>"/> </td> 
				  </tr> 
					  
					</table>
					</fieldset>
				</div>
				<div class="form-group">
					<fieldset>
					<legend>Edit animal details</legend>
					<div class="table-responsive">
						<table class="table anspecification" width="70%" border="0" align="center" cellpadding="5" cellspacing="1">
						<?php
						$str="
						<input type=\"hidden\" id=\"row_no\"  class=\"form-control\" name=\"row_no\" value=\"1\" />
						<input type=\"hidden\" class=\"form-control\" name=\"ai1\" value=\"155\" />
						<input type=\"hidden\" id=\"inum\" class=\"form-control\" name=\"inum\" value=\"".$SupplyID."\"  />
						  <thead  id=\"row1\">
							<th width=\"15%\"  align=\"center\" ><strong> Species </strong></th>
							<th width=\"15%\"  align=\"center\" ><strong>Strain</strong></th>
							<th width=\"15%\"  align=\"center\" ><strong>Stock Type </strong></th>
							<th width=\"5%\" align=\"center\" ><strong>Male</strong></th>
							<th width=\"5%\" align=\"center\" ><strong>Female</strong></th>
							
						  </thead>
						  <tbody>";
						  echo $str;				  
									 //query for spstrain  
									//supplyanimal(EntrySupplyNumber, SupplyID, Species, strain, StockType, MALE, Female) 
									$result1 = mysqli_query($db,"SELECT EntrySupplyNumber, Species, strain, StockType, MALE, Female FROM supplyanimal WHERE SupplyID='$SupplyID' ");
									$j=1;
									
									while($pass1=mysqli_fetch_array($result1,MYSQLI_BOTH)){
										$str="";
										$strsp="";
									//query ends	
													  
											$strsp= "<tr>
											  <td> <select required id=\"species".$j."\" class=\"form-control\" name=\"species".$j."\" onchange=\"getStrain(this.value,".$j.");\" >
											<option value=\"".htmlspecialchars($pass1['Species'])."\">".htmlspecialchars($pass1['Species'])."</option>";
											
											if($PorT){
											$sql="SELECT DISTINCT Species FROM animals WHERE (strain IN (SELECT DISTINCT SpStrain FROM projectanimal WHERE ProjectCode='$prcode')) OR (Species IN (SELECT DISTINCT SpStrain FROM projectanimal WHERE ProjectCode='$prcode')) ";
											}else{
												$sql="SELECT DISTINCT Species FROM animals";
											}
											$resultspecies = mysqli_query($db,$sql);									
											
											while($passspecies=mysqli_fetch_array($resultspecies,MYSQLI_ASSOC)){
												
												$strsp = $strsp ."<option value=\"".htmlspecialchars($passspecies['Species'])."\">".htmlspecialchars($passspecies['Species'])."</option>";
														
											}
											$strsp= $strsp."</select></td>";
											$str= $str.$strsp;
											mysqli_free_result($resultspecies);	        
										
										$str= $str."<td>
										<select id=\"strain".$j."\" class=\"form-control\" name=\"strain".$j."\" >
										
										<option value=\"".htmlspecialchars($pass1['strain'])."\">".htmlspecialchars($pass1['strain'])."</option>
										
										</select></td>";	
											  $str= $str. "<input type=\"hidden\" id=\"rowno\" class=\"form-control\" name=\"rowno\" value=\"".$j."\"  />";		  
											  $str= $str."<input type=\"hidden\" id=\"EntrySupplyNumber".$j."\" class=\"form-control\" name=\"EntrySupplyNumber".$j."\" value=\"".htmlspecialchars($pass1['EntrySupplyNumber'])."\"  />";
											  $str= $str. "<td> <input required size=\"10%\" type=\"text\" class=\"form-control\" name=\"stock".$j."\" id=\"stock".$j."\" value=\" ".htmlspecialchars($pass1['StockType'])." \" onkeypress=\"return isNumberKey(event)\" /></td>
											  <td> <input type=\"text\" id=\"qm".$j."\" class=\"form-control\" name=\"qm".$j."\" value=\"".htmlspecialchars($pass1['MALE'])."\"  /> </td>
											  <td> <input type=\"text\" id=\"qf".$j."\" class=\"form-control\" name=\"qf".$j."\" value=\"".htmlspecialchars($pass1['Female'])."\"  /> </td>
											</tr>"; 
											$j++;
											echo $str;
											}
											
						?>  
						</tbody>						
					</table>
				</div>
			</fieldset>
		</div>
				
						
		<div class="form-group">
				
					<div class="col-sm-offset-4 col-sm-6">
						<button type="submit" class="btn btn-danger">
							<i class="fa fa-btn fa-edit"></i> Edit Supply
						</button>
						<button type="button" class="btn btn-warning" onclick="window.history.back()">
							<i class="fa fa-btn fa-arrow-left"></i> Back
						</button>
					</div>
				
				</div>
			</form>
		</div>
</div>	
	<div>&nbsp;</div><div>&nbsp;</div>				
	<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
	</div>

</body>
</html>
<?php 
		}
	}else{
		$_SESSION['message']="Edit Error, Contact Admin  !";
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=SupplyReport.php">';
	}
}else{
	$_SESSION['message']="Edit Error, Invalid input data  !";
	echo '<META HTTP-EQUIV="Refresh" Content="0; URL=SupplyReport.php">';
}
?>

