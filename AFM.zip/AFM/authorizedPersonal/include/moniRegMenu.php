
<head>
<style>
.navbar-custom {
    background-color:black;
    color:#ffffff;
    border-radius:0;
	
  text-decoration: none;
  font-size: 14px;
  width:50%;
}

.navbar-custom .navbar-nav > li > a {
    color:#fff;
}

.navbar-custom .navbar-nav > .active > a {
    color: #ffffff;
    background-color:transparent;
}

.navbar-custom .navbar-nav > li > a:hover,
.navbar-custom .navbar-nav > li > a:focus,
.navbar-custom .navbar-nav > .active > a:hover,
.navbar-custom .navbar-nav > .active > a:focus,
.navbar-custom .navbar-nav > .open >a {
    text-decoration: none;
    background-color: #33aa33;
}

.navbar-custom .navbar-brand {
    color:#eeeeee;
}
.navbar-custom .navbar-toggle {
    background-color:#eeeeee;
}
.navbar-custom .icon-bar {
    background-color:#33aa33;
}
</style>
</head>
<body>
<nav class="navbar navbar-custom pull-right">
  
    <ul class="nav navbar-nav">
      <li ><a href="MonitoringRegister.php">Room Parameter</a></li>
      <li><a href="TreatmentRegister.php">Treatment</a></li>
	  <li><a href="RoomFumigation.php">Fumigation</a></li>
	  <li><a href="MicrobialSampling.php">Microbial Sampling</a></li>
	  <li><a href="GeneticSampling.php">Genetic Sampling</a></li>
    </ul>
  
</nav>
