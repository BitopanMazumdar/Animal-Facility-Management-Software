<head>
  
<style>
.navbar-custom {
    background-color:black;
    color:#ffffff;
    border-radius:0;
	
  text-decoration: none;
  font-size: 14px;
  width:40%;
}

.navbar-custom .navbar-nav > li > a {
    color:#fff;
}

.navbar-custom .navbar-nav > .active > a {
    color: #ffffff;
    background-color:transparent;
}

.navbar-custom .navbar-nav > li > a:hover,
.navbar-custom .navbar-nav > li > a:focus,
.navbar-custom .navbar-nav > .active > a:hover,
.navbar-custom .navbar-nav > .active > a:focus,
.navbar-custom .navbar-nav > .open >a {
    text-decoration: none;
    background-color: #33aa33;
}

.navbar-custom .navbar-brand {
    color:#eeeeee;
}
.navbar-custom .navbar-toggle {
    background-color:#eeeeee;
}
.navbar-custom .icon-bar {
    background-color:#33aa33;
}
</style>
</head>
<body>
<nav class="navbar navbar-custom pull-right">
  
    <ul class="nav navbar-nav">
      <li ><a href="InventoryRegister.php">Production</a></li>
      <li><a href="Supply.php">Supply</a></li>
	  <li><a href="FormE.php">Sale</a></li>
	  <li><a href="Mortality.php">Mortality</a></li>
	  <li><a href="ExperimentAnimals.php">Experiment</a></li>
    </ul>
  
</nav>
