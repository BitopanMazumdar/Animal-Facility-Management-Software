 <div id="submenu"><table align="left"> <tr>
 <td align="left" class="submenu" style=" height:2.5em;" ><a href="MonitoringRegister.php?page=room_monitoring&pg=temp_humidity">Room Parameter</a></td>
    <td align="left" class="submenu" style=" height:2.5em;" ><a href="TreatmentRegister.php?page=room_monitoring&pg=treatment">Treatment Register</a></td>
    <td align="left" class="submenu" style=" height:2.5em;" ><a href="RoomFumigation.php?page=room_monitoring&pg=fumigation">Room Fumigation</a></td>
    <td align="left" class="submenu" style=" height:2.5em;" ><a href="MicrobialSampling.php?page=room_monitoring&pg=microbial">Microbial Sampling</a></td>
    <td align="left" class="submenu" style=" height:2.5em;" ><a href="GeneticSampling.php?page=room_monitoring&pg=genetic">Genetic Sampling</a></td>
	</tr></table></div>
	<!--
	<td width="20%" align="center" ><input style="width:10em; height:2.5em" type="button" onclick="window.location.assign('MonitoringRegister.php')" value="Room Parameter" /></td>
	<td width="20%" align="center" ><input style="width:10em; height:2.5em" type="button" onclick="window.location.assign('TreatmentRegister.php')" value="Treatment register" /></td>


	<td width="20%" align="center" ><input style="width:10em; height:2.5em" type="button" onclick="window.location.assign('MonitoringRegister.php')" value="Room Parameter" /></td>
    <td width="20%" align="center" ><input style="width:10em; height:2.5em" type="button" onclick="window.location.assign('TreatmentRegister.php')" value="Treatment " /></td>
	<td width="20%" align="center" ><input style="width:10em; height:2.5em" type="button" onclick="window.location.assign('RoomFumigation.php')" value="Room Fumigation" /></td>
    <td width="20%" align="center" ><input style="width:10em; height:2.5em" type="button" onclick="window.location.assign('MicrobialSampling.php')" value="Microbial Sampling" /></td>
    <td width="20%" align="center" ><input style="width:10em; height:2.5em" type="button" onclick="window.location.assign('GeneticSampling.php')" value="Genetic Sampling" /></td>
		-->
