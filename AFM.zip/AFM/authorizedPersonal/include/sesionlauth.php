
<?php
if(session_id() == '' || !isset($_SESSION)) {
    // session isn't started
    session_start();
} 

if(isset($_SESSION['PREV_USERAGENT'])){
	if(sha1($_SERVER['HTTP_USER_AGENT']) !== $_SESSION['PREV_USERAGENT']){
		session_destroy();
		exit();
	}	
}else{
	header("Location: index.php", true, 301);
	exit();
}

if(isset($_SESSION['pie'])){
  $pie=$_SESSION['pie'];
  $piname=$_SESSION['piname'];
}else{
	header("Location: index.php", true, 301);
	exit();
}
?>