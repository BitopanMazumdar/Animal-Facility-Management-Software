<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Animal Facility Management Software</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script> 
<script src="Jquery/jquery-3.js"></script> 
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
.topnav {
  overflow: hidden;
  background-color: black; /* 86af49*/
  
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 10px 12px;
  text-decoration: none;
  font-size: 14px;
  font-weight:600;
}

.active {
  background-color: #86af49;
  color: white;
}

.topnav .icon {
  display: none;
}

.dropdownboot {
  float: left;
  overflow: hidden;
}

.dropdownboot .dropbtnboot {
  font-size: 14px; 
  font-weight:600;
  border: none;
  outline: none;
  color: white;
  padding: 10px 12px;
  text-align: center;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.dropdownboot-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdownboot-content a {
  float: none;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.topnav a:hover, .dropdownboot:hover .dropbtnboot {
  background-color: red;
  color: white;
}

.dropdownboot-content a:hover {
  background-color: #ddd;
  color: black;
}

.dropdownboot:hover .dropdownboot-content {
  display: block;
}

@media screen and (max-width: 900px) {
  .topnav a:not(:first-child), .dropdownboot .dropbtnboot {
    display: none;
  }
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 900px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
  .topnav.responsive .dropdownboot {float: none;}
  .topnav.responsive .dropdownboot-content {position: relative;}
  .topnav.responsive .dropdownboot .dropbtnboot {
    display: block;
    width: 100%;
    text-align: left;
  }
}
</style>
</head>
<body>

<script type="text/javascript">
function profile(){
		
		$("#welcome").hide();
		$("#profile").show();
}

function welcome(){
		
		$("#welcome").show();
		$("#profile").hide();
}
</script> 
<div class="topnav" id="myTopnav">

	<a href="Pihome.php" class="active"><i class="fa fa-home"></i> Home</a>
	
	<div class="dropdownboot">
		<button class="dropbtnboot">Requisition 
		  <i class="fa fa-caret-down"></i>
		</button>
		<div class="dropdownboot-content">
			<a href="IndentForm.php?page=indent_form">Request Animal </a>
		  <a href="indentResponse.php?page=indent_requests">AH Response</a> 
		  <a href="indentHistory.php?page=indent_requests">Request History</a>
		</div>
	</div>
	<a href="UtilizedAnimals.php?page=view_util">Utilization</a>
	<div class="dropdownboot">
		<button class="dropbtnboot">Register 
		  <i class="fa fa-caret-down"></i>
		</button>
		<div class="dropdownboot-content">
			<a href="ExperimentationAi.php?page=view_util">Experimentation Register</a> 
		  <a href="DisposalAi.php?page=view_util">Disposal Register</a>
		</div>
	</div>
	<div class="dropdownboot">
		<button class="dropbtnboot">Report 
		  <i class="fa fa-caret-down"></i>
		</button>
		<div class="dropdownboot-content">
			<a href="ViewExperimentationAi.php?page=view_util">Experimentation Report</a>
		  <a href="ViewDisposalAi.php?page=view_util">Disposal Report</a>
		</div>
	</div>
	<a href="ViewMeeting.php"><i class="fa fa-file"></i> CPCSEA summary</a>
	<div class="dropdownboot">
		<button class="dropbtnboot">Project Member 
		  <i class="fa fa-caret-down"></i>
		</button>
		<div class="dropdownboot-content">
			<a href="AddProjectMember.php?page=view_students">ADD Member </a>
		  <a href="ViewPM.php?page=view_students">View Member </a>
		</div>
	</div>
	<a href="profile.php"><i class="fa fa-user"></i> Profile</a>
      <a href="Logout.php"><i class="fa fa-sign-out"></i> Logout</a>
	<a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
</div>
	<!--
	<div id="welcome" class="profile" onmouseover="profile();"> Welcome : 		
	</div>
	<div id="profile" class="profile" style="display:none" onmouseleave="welcome();">
			<a style="text-decoration:none;" href="profile.php?page=profile">Profile</a>
	</div> 
	-->

<script>
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
</script>

</body>
</html>
