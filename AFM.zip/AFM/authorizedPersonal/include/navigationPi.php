<!DOCTYPE html>
<html lang="en">
<head>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  <style>
.navbar-custom {
    background-color:black;
    color:#ffffff;
    border-radius:0;
}

.navbar-custom .navbar-nav > li > a {
    color:#fff;
}

.navbar-custom .navbar-nav > .active > a {
    color: #ffffff;
    background-color:transparent;
}

.navbar-custom .navbar-nav > li > a:hover,
.navbar-custom .navbar-nav > li > a:focus,
.navbar-custom .navbar-nav > .active > a:hover,
.navbar-custom .navbar-nav > .active > a:focus,
.navbar-custom .navbar-nav > .open >a {
    text-decoration: none;
    background-color: #33aa33;
}

.navbar-custom .navbar-brand {
    color:#eeeeee;
}
.navbar-custom .navbar-toggle {
    background-color:#eeeeee;
}
.navbar-custom .icon-bar {
    background-color:#33aa33;
}
</style>
</head>
<body>
<nav class="navbar navbar-custom">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="https://www.hylascobio.com">Comapany Name</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="Pihome.php">Home</a></li>
	    
	  <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Requisition<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li> <a href="IndentForm.php?page=indent_form">Request Animal </a></li>
		  <li> <a href="indentResponse.php?page=indent_requests">AH Response</a></li> 
		  <li> <a href="indentHistory.php?page=indent_requests">Request History</a></li>
        </ul>
      </li>
	  <li> <a href="UtilizedAnimals.php?page=view_util">Utilization</a></li>
	  <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Register<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li> <a href="Experimentation.php?page=view_util">Experimentation Register</a></li> 
		  <li> <a href="Disposal.php?page=view_util">Disposal Register</a></li>
        </ul>
      </li>
	   <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Report<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li> <a href="ViewExperimentation.php?page=view_util">Experimentation Report</a></li>
		  <li> <a href="ViewDisposal.php?page=view_util">Disposal Report</a></li>	
        </ul>
      </li>
		<li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Project Member<span class="caret"></span></a>
				<ul class="dropdown-menu">
				  <li> <a href="AddProjectMember.php?page=view_students">ADD Member </a></li>
		  <li> <a href="ViewPM.php?page=view_students">View Member </a></li>	
				</ul>
			  </li> 	  
      
      <li><a href="Logout.php?page=logout">Logout</a></li>
    </ul>
  </div>
</nav>
</body>
</html>