<td  height="45" class="hide-l" id="hide-l">
	<table width="100%" border="0" cellspacing="0" cellpadding="3">
      <tr>
        <td width="17%" ><img src="images/niablogoA.jpg" alt="Company Logo" /></td>
        <td width="62%" height="45" align="center"><span class="title">Animal Facility Management Software</span></td>
        <td width="21%">&nbsp;</td>
      </tr>
	  
    </table></td>