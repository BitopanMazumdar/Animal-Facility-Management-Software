 <div id="submenu"><table align="left">
<tr>
	<td  align="left" style=" height:2.5em; " class="submenu" ><a href="InventoryReports.php">Production</a></td>
    <td  align="left" style=" height:2.5em; " class="submenu" ><a href="SupplyReport.php">Supply&nbsp;</a></td>
	<td  align="left" style=" height:2.5em; " class="submenu" ><a href="SaleReport.php">&nbsp;&nbsp;Sale&nbsp;&nbsp;</a></td>
    <td  align="left" style=" height:2.5em; " class="submenu"><a href="MortalityReport.php">Mortality</a></td>
	<td  align="left" style=" height:2.5em; " class="submenu"><a href="ExpAnimalReport.php">Exp. Animal </a></td>
    <td  align="left" style=" height:2.5em; " class="submenu"><a href="Census.php">Census&nbsp;</a></td> 
</tr>
<tr>
		<td colspan="5" >&nbsp;</td>
</tr>
</table> </div>
	<!-- <td  align="left" ><input style=" height:2.5em; " type="button" onclick="window.location.assign('InventoryReports.php?page=ahreports&pg=prodrep')" value="Production" /></td>
    <td  align="left" ><input style=" height:2.5em; " type="button" onclick="window.location.assign('SupplyReport.php?page=ahreports&pg=supprep')" value="Supply" /></td>
	<td  align="left" ><input style=" height:2.5em; " type="button" onclick="window.location.assign('SaleReport.php?page=ahreports&pg=supprep')" value="Sale" /></td>
	<td  align="left" ><input style=" height:2.5em; " type="button" onclick="window.location.assign('MortalityReport.php?page=ahreports&pg=mortrep')" value="Mortality" /></td>
    <td  align="left" >
	<input style=" height:2.5em; " type="button" onclick="window.location.assign('ExpAnimalReport.php?page=ahreports&pg=expanmrep')" value="Exp. Animal" /></td>
	<td  align="left" ><input style=" height:2.5em; " type="button" onclick="window.location.assign('Census.php?page=ahreports&pg=census')" value="Census"  /></td> -->