<div class="container-fluid" style="background-color:white">
	<div class="col-sm-2">
		<img src="images/niablogoA.jpg" alt="Company Logo" />
	</div>
	<div class="col-sm-8 text-center" width="62%" height="45" align="center">
		<h2> Animal Facility Management Software </h2>
	</div>
</div>
        