<!--animal specification -->
						<div class="col-sm-12 table-responsive">
							<table  class="anspecification table" align="center" >
						
							<input class="form-control" type="hidden" id="row_no"  name="row_no" value="1" />
						  <tr  id="row1">
						  <thead>
							<th > Species / Strain
							</th>
							<th >Gender</th>
							<th >No of Animals </th>
							<th >Weight/age</th>
							<th >&nbsp;</th>
						</thead>
						  </tr>
						  <tbody>
						  <tr  id="row1">
							<td align="left" bgcolor="#EFEFEF"><label>
							  <select class="form-control" required name="strain1" id="strain1" onchange="checkGender(this.value,1)">
							  
								<option value="" >Select
										
												</select class="form-control">
							</label>              <label></label></td>
							<td align="left" bgcolor="#EFEFEF"><label>
							  <select class="form-control" required  name="sex1" id="sex1" onchange="DoEmpty(1)">
							   <option value="Male" >Male</option>
								<option value="Female">Female</option>
								<option value="Any">Any</option>
							  </select class="form-control">
							</label></td>
							<td width="39%" align="left" bgcolor="#EFEFEF"><label>
							  <input class="form-control" required name="no_of_an1" id="no_of_an1" type="number"  min="1" onchange="CheckAvail(this.value,1)"/><span id="avl1"></span>
							</label></td>
							<td width="23%" align="left" bgcolor="#EFEFEF"><label>
							<input class="form-control" style="text-transform:capitalize;"  pattern="[0-9A-Za-z ]*" title="Special characters are not allowed" name="age1" type="text" id="age1" />
							</label></td>
							<td width="6%" bgcolor="#EFEFEF">&nbsp;</td>
						  </tr>
						  <tr  id="row2" style=" display:none;">
							<td align="left" bgcolor="#EFEFEF"><label>
							 <select class="form-control" name="strain2" id="strain2"  onchange="checkGender(this.value,2)">
								<option value="">Select
												</select class="form-control">
							</label>              <label></label></td>
							<td align="left" bgcolor="#EFEFEF"><label>
							  <select class="form-control" name="sex2" id="sex2" onchange="DoEmpty(2)">
							   <option value="Male">Male</option>
								<option value="Female">Female</option>
								<option value="Any">Any</option>
							  </select class="form-control">
							</label></td>
							<td width="39%" align="left" bgcolor="#EFEFEF"><label>
							  <input class="form-control" name="no_of_an2" id="no_of_an2" type="number"  min="1"  onchange="CheckAvail(this.value,2)" /><span id="avl2"></span>
							</label></td>
							<td width="23%" align="left" bgcolor="#EFEFEF"><label>
							  <input class="form-control" style="text-transform:capitalize;"  pattern="[0-9A-Za-z ]*" title="Special characters are not allowed" name="age2" type="text" id="age2" />
							</label></td>
							<td width="6%" bgcolor="#EFEFEF"><img id="close2" style="cursor:pointer; display:none;" onclick="Close(2)" src="images/close.jpg" width="20" height="20" /></td>
						  </tr>
						  <tr  id="row3" style=" display:none;">
							<td align="left" bgcolor="#EFEFEF"><label>
							<select class="form-control" name="strain3" id="strain3"  onchange="checkGender(this.value,3)" >
								<option value="">Select
												</select class="form-control">
							</label>              <label></label></td>
							<td align="left" bgcolor="#EFEFEF"><label>
							  <select class="form-control" name="sex3" id="sex3" onchange="DoEmpty(3)">
								<option value="Male">Male</option>
								<option value="Female">Female</option>
								<option value="Any">Any</option>
							  </select class="form-control">
							</label></td>
							<td width="39%" align="left" bgcolor="#EFEFEF"><label>
							  <input class="form-control" name="no_of_an3" id="no_of_an3" type="number"  min="1"  onchange="CheckAvail(this.value,3)"/><span id="avl3"></span>
							</label></td>
							<td width="23%" align="left" bgcolor="#EFEFEF"><label>
							  <input class="form-control" style="text-transform:capitalize;"  pattern="[0-9A-Za-z ]*" title="Special characters are not allowed" name="age3" type="text" id="age3" />
							</label></td>
							<td width="6%" bgcolor="#EFEFEF"><img id="close3" style="cursor:pointer; display:none;" onclick="Close(3)" src="images/close.jpg" width="20" height="20" /></td>
						  </tr>
						  <tr  id="row4" style=" display:none;">
							<td align="left" bgcolor="#EFEFEF"><label>
							 <select class="form-control" name="strain4" id="strain4"  onchange="checkGender(this.value,4)">
								<option value="">Select
												</select class="form-control">
							</label>              <label></label></td>
							<td align="left" bgcolor="#EFEFEF"><label>
							  <select class="form-control" name="sex4" id="sex4" onchange="DoEmpty(4)">
								<option value="Male"  >Male</option>
								<option value="Female">Female</option>
								<option value="Any">Any</option>
							  </select class="form-control">
							</label></td>
							<td width="39%" align="left" bgcolor="#EFEFEF"><label>
							  <input class="form-control" name="no_of_an4" id="no_of_an4"  type="number"  min="1"  onchange="CheckAvail(this.value,4)"/><span id="avl4"></span>
							</label></td>
							<td width="23%" align="left" bgcolor="#EFEFEF"><label>
							  <input class="form-control" style="text-transform:capitalize;"  pattern="[0-9A-Za-z ]*" title="Special characters are not allowed" name="age4" type="text" id="age4" />
							</label></td>
							<td width="6%" bgcolor="#EFEFEF"><img id="close4" style="cursor:pointer; display:none;" onclick="Close(4)" src="images/close.jpg" width="20" height="20" /></td>
						  </tr>
						  <tr  id="row5" style=" display:none;">
							<td align="left" bgcolor="#EFEFEF"><label>
							 <select class="form-control" name="strain5" id="strain5"  onchange="checkGender(this.value,5)">
								<option value="">Select
												</select class="form-control">
							</label>              <label></label></td>
							<td align="left" bgcolor="#EFEFEF"><label>
							  <select class="form-control" name="sex5" id="sex5" onchange="DoEmpty(5)">
								<option value="Male"  >Male</option>
								<option value="Female">Female</option>
								<option value="Any">Any</option>
							  </select class="form-control">
							</label></td>
							<td width="39%" align="left" bgcolor="#EFEFEF"><label>
							  <input class="form-control" name="no_of_an5" id="no_of_an5" type="number"  min="1"  onchange="CheckAvail(this.value,5)"/><span id="avl5"></span>
							</label></td>
							<td width="23%" align="left" bgcolor="#EFEFEF"><label>
							  <input class="form-control" style="text-transform:capitalize;"  pattern="[0-9A-Za-z ]*" title="Special characters are not allowed" name="age5" type="text" id="age5" />
							</label></td>
							<td width="6%" bgcolor="#EFEFEF"><img id="close5" style="cursor:pointer; display:none;" onclick="Close(5)" src="images/close.jpg" width="20" height="20" /></td>
						  </tr>
							<tr  id="row6" style=" display:none;">
							<td align="left" bgcolor="#EFEFEF"><label>
							 <select class="form-control" name="strain6" id="strain6"  onchange="checkGender(this.value,6)">
								<option value="">Select
												</select class="form-control">
							</label>              <label></label></td>
							<td align="left" bgcolor="#EFEFEF"><label>
							  <select class="form-control" name="sex6" id="sex6" onchange="DoEmpty(6)">
								<option value="Male" >Male</option>
								<option value="Female">Female</option>
								<option value="Any">Any</option>
							  </select class="form-control">
							</label></td>
							<td width="39%" align="left" bgcolor="#EFEFEF"><label>
							  <input class="form-control" name="no_of_an6" id="no_of_an6" type="number"  min="1"  onchange="CheckAvail(this.value,6)"/><span id="avl6"></span>
							</label></td>
							<td width="23%" align="left" bgcolor="#EFEFEF"><label>
							  <input class="form-control" style="text-transform:capitalize;"  pattern="[0-9A-Za-z ]*" title="Special characters are not allowed" name="age6" type="text" id="age6" />
							</label></td>
							<td width="6%" bgcolor="#EFEFEF"><img id="close6" style="cursor:pointer; display:none;" onclick="Close(6)" src="images/close.jpg" width="20" height="20" /></td>
						  </tr>
						  <tr  id="row7" style=" display:none;">
							<td align="left" bgcolor="#EFEFEF"><label>
							 <select class="form-control" name="strain7" id="strain7" onchange="checkGender(this.value,7)">
								<option value="">Select
												</select class="form-control">
							</label>              <label></label></td>
							<td align="left" bgcolor="#EFEFEF"><label>
							  <select class="form-control" name="sex7" id="sex7" onchange="DoEmpty(7)">
								<option value="Male"  >Male</option>
								<option value="Female">Female</option>
								<option value="Any">Any</option>
							  </select class="form-control">
							</label></td>
							<td width="39%" align="left" bgcolor="#EFEFEF"><label>
							  <input class="form-control" name="no_of_an7" id="no_of_an7" type="number"  min="1"  onchange="CheckAvail(this.value,7)"/><span id="avl7"></span>
							</label></td>
							<td width="23%" align="left" bgcolor="#EFEFEF"><label>
							  <input class="form-control" style="text-transform:capitalize;"  pattern="[0-9A-Za-z ]*" title="Special characters are not allowed" name="age7" type="text" id="age7" />
							</label></td>
							<td width="6%" bgcolor="#EFEFEF"><img id="close7" style="cursor:pointer; display:none;" onclick="Close(7)" src="images/close.jpg" width="20" height="20" /></td>
						  </tr>
						  <tr><td colspan="6" ><div id="addRow" class="addrow"><strong>ADD</strong></div>
						  </td></tr><tbody>
						</table>							
						</div>
						<!--animal specification End -->