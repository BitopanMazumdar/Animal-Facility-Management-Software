<?php include "include/sesionlauth.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  
</head>
<body style="background-color:#F8F9FA">
<!-- Script start-->
<script type="text/javascript">
$(document).ready(function(){
		$("#displaydiv").slideDown("slow");
});
</script>
<script type="text/javascript">     
$(document).ready(function(){
	// get piname from session variable and fetch projects of the PI    
	$.get("sessionProjectByPi.php", function(data, status){
	$("#pcode").html(data);
	
	});	
});
</script>

<script type="text/javascript">
$(document).ready(function(){
	  $("#asst_no").click(function(){
		  $("#assist").hide();
	  });
	  $("#asst_yes").click(function(){
	  //alert("hello");
			$("#assist").show();
	 });
		  $("#other").click(function(){
		 $("#other_assist").toggle();
		  $("#other_assist").val("");
	 
	  });
	  
	   $("#addRow").click(function(){
	   
	   val=$("#row_no").val();
	   if(val!=7)
	   {
	   val++;
	   $("#row_no").val(val);
		$("#row"+val).slideDown();
		$("#close"+val).show();
		val--;
		$("#close"+val).hide();
		}
	  }); 
 
 
});

function CheckAvail(val,no)
{
		//alert("in check");
	check=1;
	z=$("#row_no").val();
	
	for(x=1;x<=z;x++)
	{
	//alert(x);
	if(x!=no)
	{
		if($("#strain"+x).val()==$("#strain"+no).val())
		{
			//alert("strain same");
			if($("#sex"+x).val()==$("#sex"+no).val())
			{
				$("#strain"+no).val("");
				$("#sex"+no).val("");
				$("#no_of_an"+no).val("");
				check=0;
				alert("Species/Strain allready selected");
			}
			else
			{
				//alert("gender different");
				if($("#no_of_an"+x).val()=="")
				nav=0;
				else
				nav=$("#no_of_an"+x).val();
				val=parseInt(val)+parseInt(nav);
				
			}
		}
	}
	//x++;
	}

	
	pid=$("#pcode").val();
	aid=$("#strain"+no).val();
	gen=$("#sex"+no).val();
	if(check==1 && val!="" && pid!=0 && aid!="")
	{
		//$("#avl"+no).html("<img src='images/loading.gif' height='20' width='20' />");
		$.get("AnimalAvailabilty.php",{
			aid:aid,
			pid:pid,
			gen:gen,
			val:val
		},
		  function(data,status){
			  
			if(data==-2){
				 $("#avl"+no).html("");
				  $("#no_of_an"+no).val("");
				alert("something went wrong!");
			}else if(data==-1)
			  {
				 $("#avl"+no).html("<img src='images/right.jpg' height='10' width='12' />"); //  
			  }
			  else
			  {
				$("#avl"+no).html("");
				  $("#no_of_an"+no).val("");
				  alert("Exeeds approved Species/Strain limit, Approved = "+data);
			  }
			  });

	}
	else
	 $("#avl"+no).html("");
}


function Close(val)
{
	 $("#no_of_an"+val).val("");
	 $("#avl"+val).html("");
	  $("#strain"+val).val("");
	 $("#sex"+val).val("");

	 $("#row"+val).slideUp();
	 val--;
	 $("#row_no").val(val);
	 $("#close"+val).show("slow");
 
 }
function checkGender(val,no)
	{
	 $("#no_of_an"+no).val("");
	 $("#avl"+no).html("");
	 pco=$("#pcode").val();
	 $.get("Genderquery.php",
	  {
		aid:val, pc:pco
	  },
	  function(data,status){
		 //alert(data);
		 $("#sex"+no+"").html(data);
	   /* if(data=="Any")
		{
	   // $("#sex"+no+"").val("");
		$("#sex"+no+"").val("Male");
		$("#sex"+no+"").show();
		
		}
		else
		{
		
			$("#sex"+no+"").hide();
			$("#sex"+no+"").val("");
		} */
	  }); 
}

function DoEmpty(no)
{
	$("#no_of_an"+no).val("");
	$("#avl"+no).html("");
}
function showTitle(val)
{
	window.location="Title_query.php?page=indent_form&proj="+val;
}

function CheckDate(ete)
{
    
	projid=$("#pcode").val();
	 
    if(projid!=0)
    {
		$.get("CheckDate.php",{projid:projid,seldate:ete},function(data,status){
			
			if(data!=1)
			{
				alert("Date not allowed! "+data+"");
				$("#reqdate").val("");
				return false;
			}
			else
			{ 
				return true;
			}
		});
    }
    else
    {
		alert("You have not select any Project! Please select Project! ");
	}
    
}
</script>
<script type="text/javascript">
function getTitle(val){
	$.get("TitleByProject.php", {prcode:val},function(data, status){
	//$("#title").html(data);
	$("#title").val(data);
	});
}
</script>
<script type="text/javascript">

function getSpstrain(val){
	//rowno=$("#row_no").val();
	$.get("SpStrainByProject.php", {prcode:val}, function(data, status){
		
		for(i=1; i<=7; i++){
			// "<select name=\"strain1\" id=\"strain"+i+"\" onchange=\"checkGender(this.value,1)\"><option value=\"\">Select</option>" + data+"</select>";
            //alert(data);    
			$("#strain"+i).html(data);
		}
    });
}	
</script>


<!-- Validation-->
<script type="text/javascript">
function valid(){
	frm = document.myform;
	no=frm.row_no.value;
	 if(frm.pcode.value ==0)
	  {
			alert("Please Select Project Code ! ");
			frm.pcode.focus();
			return false;
	  }
	  
	  if(frm.title.value =="")
	  {
			alert("Please Enter Title  !");
			frm.title.focus();
			return false;
	  }
	  
	  if(frm.recn.value =="")
	  {
			alert("Please Enter Receiver Name !");
			frm.recn.focus();
			return false;
	  }
	  
	 
	  for(j=1;j<=no;j++)
		{
					
		  if(document.getElementById("strain" + j).value =="")
		  {
				alert("Please enter species/starin !");
				document.getElementById("strain" + j).focus();
				return false;
		  }
		  		  
		/* if(document.getElementById("sex" + j).value =="")
		  {
				alert("Please enter Gender !");
				document.getElementById("sex" + j).focus();
				return false;
		  }
		  */
		  if(document.getElementById("no_of_an" + j).value ==0)
		  {
				alert("Please enter No. OF Animals !");
				document.getElementById("no_of_an" + j).focus();
				return false;
		  }
		   
		  if(document.getElementById("age" + j).value =="" )
		  {
				alert("Please enter Weight/Age !");
				document.getElementById("age" + j).focus();
				return false;
		  }
		}
		if(frm.reqdate.value =="")
	  {
			alert("Please Enter Requested Date!");
			frm.reqdate.focus();
			return false;
	  }
	  if(frm.reqtime.value =="")
	  {
			alert("Please Enter Time!");
			frm.reqtime.focus();
			return false;
	  }
	  if(frm.period.value =="")
	  {
			alert("Please Enter Period Of Experiment!");
			frm.period.focus();
			return false;
	  } 
	  var r = confirm("confirm submit!");
	  if (r == true) {
		  return true;
	  } else {
		frm.pcode.focus();
		return false;
	  }
	  
}
</script>		

<!-- End of validation -->

<!-- Script end-->
	<nav >
	  <div class="container-fluid">
		<?php 
		include"include/headerboot.php"; 
		?>
	  </div>
	  <div class="container-fluid">
		<?php 
		include"include/MenuPi.php"; 
		?>
	  </div>
	   <div class="container-fluid">
		&nbsp;
	  </div>
	</nav>
	

	<div class="container" id="displaydiv" style="display:none">
        <div class="col-sm-offset-1 col-sm-10">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    Animal Request Management
                </div>

                <div class="panel-body">
                    <!-- Display Validation Errors -->
                    <div  id="validerror" style="display:none;" class="alert alert-danger"> </div>
					<!-- submit message -->
						<?php 
							if(isset($_SESSION['message'])){
									echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
									unset($_SESSION['message']);
							}					
						?>
					<!-- submit message -->
                    <!-- New Task Form -->
                    <form name="myform" autocomplete="off" method="post" action="IndentForm_proccess.php" onsubmit="return valid();" class="form-horizontal">
                        
                        <!-- Task Name -->
                        <div class="form-group">
							<label for="pcode" class="col-sm-4 control-label"><span style="color: red">*</span>Protocol No.:</label>
							<div class="col-sm-6">
								<select class="form-control" required name="pcode" onchange="getTitle(this.value);getSpstrain(this.value);" id="pcode">
									<option value="0" selected="selected">Select</option>
								</select>
							</div>
						</div>
						<div class="form-group">
							<label for="manager" class="col-sm-4 control-label">Title of the Investigation:</label>
							<div class="col-sm-6">
								<textarea class="form-control" name="title" readonly="true" id="title" type="text"></textarea>
							</div>
						</div>
						<div class="form-group">
							<label for="manager" class="col-sm-4 control-label"><span style="color: red">*</span>Reciever Name:</label>
							<div class="col-sm-6">
								<input class="form-control" required style="text-transform:capitalize;"  pattern="[A-Za-z ]*" name="recn" type="text" id="recn" placeholder="Enter receiver name" />
							</div>
						</div>
						
						<div class="form-group">
							<label for="manager" class="col-sm-4 control-label"><span style="color: red">*</span>Animals Required Date:</label>
							<div class="col-sm-6">
								<input class="form-control" required id="reqdate" name="reqdate" type="date"  value="" onchange="CheckDate(this.value)" />
							</div>
						</div>
						<div class="form-group">
							<label for="manager" class="col-sm-4 control-label"><span style="color: red">*</span>Animals Required Time:</label>
							<div class="col-sm-6">
								<select class="form-control"required name="reqtime" id="reqtime">
									<option selected="selected" value="">Select</option>
									<option value="09:30">09:30</option>
									<option value="10:00">10:00</option>
									<option value="10:30">10:30</option>
									<option value="11:00">11:00</option>
									<option value="11:30">11:30</option>
									<option value="12:00">12:00</option>
									<option value="12:30">12:30</option>
									<option value="13:00">13:00</option>
									<option value="13:30">13:30</option>
									<option value="14:00">14:00</option>
									<option value="14:30">14:30</option>
									<option value="15:00">15:00</option>
									<option value="15:30">15:30</option>
									<option value="16:00">16:00</option>
									<option value="16:30">16:30</option>
									<option value="17:00">17:00</option>
									<option value="17:30">17:30</option>
									<option value="18:00">18:00</option>
								 </select>
							</div>
						</div>
						<div class="form-group">
							<label for="manager" class="col-sm-4 control-label"><span style="color: red">*</span>Period of Experimental Procedure:</label>
							<div class="col-sm-6">
								<input class="form-control" required style="text-transform:capitalize;"  pattern="[0-9A-Za-z ]*" title="Special characters are not allowed" name="period" type="text" id="period" placeholder="Enter experimental procedure duration (mention day/month/year)" /> 
							</div>
						</div>
						<!--animal specification -->
						<div class="col-sm-12 table-responsive">
							<?php include "anSpecification.php" ?>							
						</div>
						<!--animal specification End -->
						<div class="form-group">
							<label for="manager" class="col-sm-4 control-label"><span style="color: red">*</span>Technical Assistant Required:</label>
							<div class="col-sm-4">
								<div class="radio-inline">
								  <label><input  type="radio" name="assist" value="1" id="asst_yes">Yes</label>
								</div>
								<div class="radio-inline">
								  <label><input type="radio" name="assist" value="0" id="asst_no" checked>No</label>
								</div>
							</div>
						</div>
						<div class="form-group" style="display:none" id="assist">
							<div class="row col-sm-offset-4">
								<div class="checkbox-inline">
								  <label><input name="assistance[]" type="checkbox" id="assistance" value="Blood drawing">Blood drawing</label>
								</div>
								<div class="checkbox-inline">
								  <label><input name="assistance[]" type="checkbox" id="assistance" value="Organ removal">Organ removal</label>
								</div>
								<div class="checkbox-inline">
								  <label><input name="assistance[]" type="checkbox" id="assistance" value="Immunization" >Immunization</label>
								</div>
							</div>
							<div class="row col-sm-offset-4">
								<div class="checkbox">
								  <label><input type="checkbox"  id="other" name="assistance[]" value="other" >Any other</label>
								</div>
								<div class="col-sm-4">
								  <input class="form-control" style="display:none" name="other_assist" type="text" id="other_assist" />
								</div>
							</div>							
						</div>
						<div class="form-group">
							<label for="manager" class="col-sm-4 control-label">Special Request:</label>
							<div class="col-sm-6">
								<textarea class="form-control" style="text-transform:capitalize;"  pattern="[0-9A-Za-z ]*" title="Special characters are not allowed" name="spereq" id="spereq" cols="40" rows="2" placeholder="Enter special request if needed" ></textarea>
							</div>
						</div>
						<div>&nbsp;</div>
						<!-- Add Task Button -->
                        <div class="form-group">
							<div class="col-sm-offset-4 col-sm-6">
								<button type="submit" class="btn btn-primary">
									<i class="fa fa-btn fa-plus"></i> Add Request
								</button>
								<button type="reset" class="btn btn-primary">
									<i class="fa fa-btn fa-refresh"></i> Reset</button>
								<button type="button" class="btn btn-primary" onclick="window.history.back()">
								<i class="fa fa-btn fa-arrow-left"></i> Back</button>
							</div>
						</div>
                    </form>
                </div>
            </div>
			<div>&nbsp;</div><div>&nbsp;</div>
			<div id="managerlist" class="panel panel-default" style="display:none">
		
			</div>
		</div>
    </div>
	<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
	</div>
</body>
</html> 
	
	 
	