<?php include "include/sesionlauth.php"; ?>
<?php 

$pcode = filter_var($_POST['pcode'], FILTER_SANITIZE_STRING);
$title = filter_var($_POST['title'], FILTER_SANITIZE_STRING);
$recn = filter_var($_POST['recn'], FILTER_SANITIZE_STRING);
$oEuthanasia = filter_var($_POST['euthanasia'], FILTER_SANITIZE_STRING);
$oReason = filter_var($_POST['reason'], FILTER_SANITIZE_STRING);
$reqdate = filter_var($_POST['reqdate'], FILTER_SANITIZE_STRING);

//$idate= date("Y-m-d");

if($oReason=="other"){
	$oReason = filter_var($_POST['oReason'], FILTER_SANITIZE_STRING);
}
if($oEuthanasia=="other"){
	$oEuthanasia = filter_var($_POST['oEuthanasia'], FILTER_SANITIZE_STRING);
}

$rowno= filter_var($_POST['row_no'], FILTER_SANITIZE_STRING);
for($i=1; $i<=$rowno; $i++){
	$strain[$i]=filter_var($_POST['strain'.$i], FILTER_SANITIZE_STRING);
	$gender[$i]=filter_var($_POST['sex'.$i], FILTER_SANITIZE_STRING);
	$age[$i]=filter_var($_POST['age'.$i], FILTER_SANITIZE_STRING);
	
	$noa[$i]=filter_var($_POST['no_of_an'.$i], FILTER_SANITIZE_STRING);
}

$flag=1;
if($pcode!=""){
include "DBconnect.php";
			
		//disposeform (DisposeNumber, Projectcode, Title, DisposeBy, DisposeDate, Reason, Euthanasia)  
		$sql1="INSERT INTO disposeform(Projectcode, Title, DisposeBy, DisposeDate, Reason, Euthanasia) 
				values ('$pcode', '$title', '$recn', '$reqdate','$oReason', '$oEuthanasia' )";
		$result1 = mysqli_query($db, $sql1);
		
		if(!$result1){
			$flag=0;
			$_SESSION['message']="Error ! Contact admin  !";
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=DisposalAi.php">';
			die('Error: ' . mysqli_error($db));
		}else{
				$sql21="SELECT MAX(DisposeNumber) AS expNumber FROM disposeform ";
				$resultIN= mysqli_query($db,$sql21);
				if(!$resultIN){
					$flag=0;
					$_SESSION['message']="Error ! Contact admin  !";
					echo '<META HTTP-EQUIV="Refresh" Content="0; URL=DisposalAi.php">';
					die('Error: ' . mysqli_error($db));
					
				}else{
					while($pass=mysqli_fetch_array($resultIN,MYSQLI_ASSOC)){
						
						$inumber=$pass['expNumber'];
						
						for($i=1; $i<=$rowno; $i++){
							//disposeanimal(EntryNo, DisposeNumber, SpStrain, Gender, Weight_Age, NoAnimal)	
							$sql2="INSERT INTO disposeanimal(DisposeNumber, SpStrain, Gender, Weight_Age, NoAnimal) values ('$inumber','$strain[$i]','$gender[$i]', '$age[$i]', '$noa[$i]')";
							$result2 = mysqli_query($db, $sql2);
							if(!$result2){						
								$flag=0;
								die('Error: ' . mysqli_error($db));
							}	
								
						}
					
					}
				}
		  }
		
			if($flag==1){
					$_SESSION['message']="Succesfully submitted data";
					echo '<META HTTP-EQUIV="Refresh" Content="0; URL=DisposalAi.php">';
				  
			}
			else{
				$sql3="DELETE FROM disposeform WHERE DisposeNumber ='$inumber' ";

				$result3 = mysqli_query($db, $sql3);
				
				if(!$result3)
						  {
							$_SESSION['message']="Error ! contact admin  !";
							echo '<META HTTP-EQUIV="Refresh" Content="0; URL=DisposalAi.php">';
							die('Error: ' . mysqli_error($db));
						  }else{
							   $_SESSION['message']="Error ! Fail to submit animal information. Please enter details properly  !";
							   echo '<META HTTP-EQUIV="Refresh" Content="0; URL=DisposalAi.php">';
						  }
					}

		mysqli_close($db);
  }else{
	$_SESSION['message']="Invalid Input  ! Please enter data properly  !";
	echo '<META HTTP-EQUIV="Refresh" Content="0; URL=DisposalAi.php">';
  }

?>
