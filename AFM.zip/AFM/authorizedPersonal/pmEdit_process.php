<?php include "include/sesionlauth.php"; ?>
<?php 
	$emailold=filter_var($_POST['emailold'], FILTER_SANITIZE_STRING);
	$pcode=filter_var($_POST['pcode'], FILTER_SANITIZE_STRING);
	$name=filter_var($_POST['name'], FILTER_SANITIZE_STRING);
	$e=filter_var($_POST['email'], FILTER_SANITIZE_STRING);
	$phone=filter_var($_POST['phone'], FILTER_SANITIZE_STRING);
	$mobile=filter_var($_POST['mb'], FILTER_SANITIZE_STRING);
	$dg=filter_var($_POST['dg'], FILTER_SANITIZE_STRING);
	$dpt=filter_var($_POST['dpt'], FILTER_SANITIZE_STRING);
	$ex=filter_var($_POST['ex'], FILTER_SANITIZE_STRING);
	$add=filter_var($_POST['add'], FILTER_SANITIZE_STRING); 
	$pin=filter_var($_POST['pin'], FILTER_SANITIZE_STRING);
	

if($emailold!=""){
	include "DBconnect.php";
	//projectmember(ProjectCode, pmName, pmDesignation, pmDepartment, pmPhone, pmMobile, pmEmail, pmExperience, pmPasscode, pmAddress, pmPin, created_at, updated_at, author)
	$query="UPDATE projectmember SET ProjectCode='$pcode',  pmName='$name',  pmDesignation='$dg',  pmDepartment='$dpt',  pmPhone='$phone',  pmMobile='$mobile',  pmEmail='$e',  pmExperience='$ex', pmAddress='$add',  pmPin='$pin', author='$pie' WHERE pmEmail= '$emailold'" ;
	mysqli_query($db,$query);
		$result = mysqli_affected_rows($db);
		if($result >= 0){ 
			$_SESSION['message']="Successfully Edited !";
			echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=viewPM.php\">";
						
		}else{
			$_SESSION['message']="Could not update data: contact admin";
			echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=viewPM.php\">";
			die();
		}
						
		mysqli_close($db);
	
}else{
	$_SESSION['message']="Failed to Update User: You have not select any member !";
	echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=viewPM.php\">";
}
?>
