<?php include "include/sesionlauth.php"; ?>
 <?php 

$inum = filter_var($_POST['inum'], FILTER_SANITIZE_STRING);

$recn = filter_var($_POST['recn'], FILTER_SANITIZE_STRING);
$oEuthanasia = filter_var($_POST['euthanasia'], FILTER_SANITIZE_STRING);
$oReason = filter_var($_POST['reason'], FILTER_SANITIZE_STRING);
$reqdate = filter_var($_POST['reqdate'], FILTER_SANITIZE_STRING);

//$idate= date("Y-m-d");

if($oReason=="other"){
	$oReason = filter_var($_POST['oReason'], FILTER_SANITIZE_STRING);
}
if($oEuthanasia=="other"){
	$oEuthanasia = filter_var($_POST['oEuthanasia'], FILTER_SANITIZE_STRING);
}

$rowno= filter_var($_POST['rowno'], FILTER_SANITIZE_STRING);

for($i=1; $i<=$rowno; $i++){
	$EntryNo[$i]=filter_var($_POST['EntryNo'.$i], FILTER_SANITIZE_STRING);
	$strain[$i]=filter_var($_POST['strain'.$i], FILTER_SANITIZE_STRING);
	$gender[$i]=filter_var($_POST['sex'.$i], FILTER_SANITIZE_STRING);
	$age[$i]=filter_var($_POST['age'.$i], FILTER_SANITIZE_STRING);
	
	$noa[$i]=filter_var($_POST['no_of_an'.$i], FILTER_SANITIZE_STRING);
	
}

$flag=1;
$anflag=1;
if($inum !=""){
	include "DBconnect.php";
	//disposeform (DisposeNumber, Projectcode, Title, DisposeBy, DisposeDate, Reason, Euthanasia)
	//('$pcode', '$title', '$recn', '$reqdate','$group', '$oRoute', '$oSample', '$oInterval')
	$query="UPDATE disposeform SET DisposeBy='$recn', DisposeDate='$reqdate', Reason='$oReason', Euthanasia='$oEuthanasia' WHERE DisposeNumber= '$inum'" ;
	mysqli_query($db,$query);
		$result = mysqli_affected_rows($db);
		if($result>=0){
			$flag=1;			
			
		}else{
			$flag=0;
		}
		for($i=1; $i<=$rowno; $i++){
				//disposeanimal(EntryNo, DisposeNumber, SpStrain, Gender, Weight_Age, NoAnimal)		
				$sql2="UPDATE disposeanimal SET SpStrain='$strain[$i]', Gender='$gender[$i]', Weight_Age='$age[$i]', NoAnimal='$noa[$i]' WHERE EntryNo= '$EntryNo[$i]'";
				$result2 = mysqli_query($db, $sql2);
				if($result2 < 0)
				  {						
					$anflag=0;
				  }
				
		}
		if($flag==1 && $anflag==1){
				$_SESSION['message']="Successfully edited";
				echo '<META HTTP-EQUIV="Refresh" Content="0; URL=ViewDisposalAi.php">';
				
			}elseif($flag==1){
				$_SESSION['message']="Error, disposal data is edited but not able to edit animal information, Contact Admin.";
				echo '<META HTTP-EQUIV="Refresh" Content="0; URL=ViewDisposalAi.php">';
				
			}elseif($anflag==1){
				$_SESSION['message']="Error, animal information is edited but not able to edit disposal data, Contact Admin.";
				echo '<META HTTP-EQUIV="Refresh" Content="0; URL=ViewDisposalAi.php">';
			}else{
				$_SESSION['message']="Error, not able to edit data, Contact Admin.";
				echo '<META HTTP-EQUIV="Refresh" Content="0; URL=ViewDisposalAi.php">';
			}
		mysqli_close($db);
	
}else{
	$_SESSION['message']="Error, Invalid input  !";
	echo '<META HTTP-EQUIV="Refresh" Content="0; URL=ViewDisposalAi.php">';
}

?>
