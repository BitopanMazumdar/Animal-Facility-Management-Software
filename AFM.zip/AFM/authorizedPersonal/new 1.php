<?php include "include/sesionlauth.php"; ?>
 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Animal Facility Management Software</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script> 
<script src="Jquery/jquery-3.js"></script> 
<!-- <script type="text/javascript" src="Jquery/jquery-3.3.1.js"></script> -->
<link rel="stylesheet" href="CSS/styles.css">

<script> 
    $(function(){
		$("#header1").load("include/header1.php");		
		$("#menu").load("include/cuserNewMenu.php");
		$("#monRepMenu").load("include/montoringnav.php"); 
		$("#footer1").load("include/footer.php"); 
    });
    </script> 

</head>
<body >
<!-- Script start-->
<script type="text/javascript">
$(document).ready(function(){
		$("#search").show("slow");
});
</script>
<script type="text/javascript">

$(document).ready(function(){
		$.get("Project_queryAll.php", function(data, status){
		$("#uname").html(data);
		
		});
		
		var xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = function() {
		  if (this.readyState == 4 && this.status == 200) {
			document.getElementById("tdata").innerHTML = this.responseText;
			$("#viewdata").slideDown("slow");
		  }
		};
		
		xmlhttp.open("GET", "ExperimentationByAllAi.php", true);
		xmlhttp.send();
});

</script>

<script type="text/javascript">
function showList()
{
	$("#viewdata").hide();
	type=$('input:radio[name=type]:checked').val();
	name=$('#uname').val();
	utype=$('#utype').val();
	vdate=$('#vdate').val();
	vdate1=$('#vdate1').val();
	//alert(type);
	if(type==1){
		if(name==""){
			alert("PLease select Project code");
		}else{
			//window.location='UserByName.php?page=view_users&type='+type+'&uname='+name+'';
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() {
			  if (this.readyState == 4 && this.status == 200) {
				document.getElementById("tdata").innerHTML = this.responseText;
				$("#viewdata").slideDown("slow");
			  }
			};
			
			xmlhttp.open("GET", "ExperimentationByProject.php?proj="+name, true);
			xmlhttp.send();
		}
	}
	if(type==2){
		if(utype==""){
			alert("PLease Enter Group");
		}else{
			//window.location='UserByType.php?page=view_users&type='+type+'&utype='+utype+'';
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() {
			  if (this.readyState == 4 && this.status == 200) {
				document.getElementById("tdata").innerHTML = this.responseText;
				$("#viewdata").slideDown("slow");
			  }
			};
			
			xmlhttp.open("GET", "ExperimentationByGroup.php?gp="+utype, true);
			xmlhttp.send();
		}

	}
	if(type==3){
		
		if(vdate==""){
			alert("Select From date");
		}else if(vdate1==""){
			alert("Select To date");
		}else if (new Date(vdate) > new Date(vdate1)){ 
			alert("To Date must be greater than From date");
		}else{
			//window.location='SaleByDate.php?page=ahreports&pg=supprep&type='+type+'&sd='+vdate+'&sd1='+vdate1+'';
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() {
			  if (this.readyState == 4 && this.status == 200) {
				   //alert(this.responseText);
				document.getElementById("tdata").innerHTML = this.responseText;
				$("#viewdata").slideDown("slow");
			  }
			};
			
			xmlhttp.open("GET","ExperimentationByDateAi.php?sd="+vdate+"&sd1="+vdate1, true);
			xmlhttp.send();
		}
	}
}

function checkType(val)
{
//alert(val);

$('input:radio[name=type]')[val].checked = true;
}
function getGroup(proj){
	$.get("GroupExpByProject.php", {proj:proj}, function(data, status){
		$("#utype").html(data);
		
		});
}

</script>
<script type="text/javascript">
function editExperimentation(user){
	window.location="EditExperimentation.php?disnumber="+user;
		/*var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() {
			  if (this.readyState == 4 && this.status == 200) {
				document.getElementById("edit_user").innerHTML = this.responseText;
				//alert(this.responseText);
				//location.reload(true);
			  }
			};
			
			xmlhttp.open("GET", "EditExperimentation.php?disnumber="+user, true);
			xmlhttp.send(); */
}
/*
function New_Sp(){ 
	 newsp= $("#newspecies").val();
	 oldsp=$("#oldspecies").val();
	if(newsp == ""){
		alert("Please Enter New species to edit !");
		$("#newspecies").focus();
	}else{
		var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() {
			  if (this.readyState == 4 && this.status == 200) {
				//document.getElementById("tdata").innerHTML = this.responseText;
				alert(this.responseText);
				location.reload(true);
			  }
			};
			
			xmlhttp.open("GET", "EditAHUser.php?user="+user, true);
			xmlhttp.send();
	}
} */
function backtoAdd(){
	$("#addspecies").show();
		$("#editspecies").hide();
}
</script>
<!-- Script end-->
<table class="outertable"> <!-- table 1,outer table start -->
	<tr class="header" id="header1"> <!-- Row 1, start -->
	<!-- table 2, Header table start -->
	<!-- table 2, Header table End -->
	</tr> <!-- Row 1, end -->
	<tr> <!-- Row 2, start -->
		<td class="menutd" >
			<table class="menu" width="100%" border="0" cellspacing="0" cellpadding="3"> <!-- table 3,Table for menu start -->
				<tr> <!-- Row, Menu and welocome msg start-->
					<!-- left menu <td width="18%" rowspan="2" align="left" valign="top">

					<table id="menu" bgcolor="#822884"  width="100%" border="0" cellspacing="3" cellpadding="5">
				   
					</table></td> -->
					<td id="menu" height="25" align="right"></td> <!-- td, Menu and welocome msg -->
				</tr> <!-- Row, Menu and welocome msg end-->
			</table> <!-- table 3,Table for menu end -->
		</td>
	</tr>
	<tr>
		<td>
			<table align="right">
				<tr >
				
				</tr>
			</table> <!-- table reports 1 menu end -->
		</td>
	</tr>	
		
	<tr  > <!-- Row, form start 2 //////////////////// -->
		<td >
			<div class="search" style="display:none" id="search">
				<form id="form1" name="form1" method="post" action="">
          <table id="filter" width="80%" border="0" align="center" cellpadding="3" cellspacing="1">
		  <caption>
				<strong>Experimentations :</strong>
			</caption>
			<tr>
				<th colspan="6" align="left" class="exttxt">View By </th>
			</tr>
            <tr>
			<td>&nbsp;</td>
                <td colspan="2" width="26%"><label>
                <input name="type" type="radio" value="1" checked="checked"  />
                <strong>Project Code</strong></label></td>
              <td colspan="3" width="57%"><select style=" width:8em;" name="uname" id="uname"  onFocus="checkType('0')" onchange="getGroup(this.value);" >
              <option value="">Select</option>
			  </select></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td colspan="2"><label>
                <input name="type" type="radio" value="2" />
                <strong>Group</strong></label></td>
              <td colspan="3" ><select style=" width:8em;" name="utype" id="utype"  onFocus="checkType('1')">
              <option value="">Select</option>
              
              </select>
              </td>
            </tr>
			<tr>
			<td class="exttxt">&nbsp;</td>
			<td  width="15%" align="left">
			  <label><input name="type" type="radio" value="3" >
			 <strong>Date</strong></label></td>
			<td width="7%" align="right">From</td>
			<td width="28%" align="left"><input style=" width:10em;" type="date" name="vdate" id="vdate"  onFocus="checkType('2')"></td>
			<td width="5%" align="right">To</td>
			<td width="33%" align="left"><input style=" width:10em;" type="date" name="vdate1" id="vdate1"  onfocus="checkType('2')" /></td>
		  </tr>
            <tr >
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td colspan="6"><input style=" width:6em;" type="button" name="Button" value="Search"  onClick="showList()" /> 
			  <input style=" width:5em;" type="button" name="BackButton" value="Back"  onClick="window.history.back();" />
			  </td>
            </tr> 
          </table>
                </form>
			</div>
			
		</td>
	</tr> <!-- Row, form end 2 ////////////////////-->
		
	
	<tr > <!-- Row, space start-->
		<td > <!-- Td, form start-->
			<table class="space"> <!-- Table, space start-->		
				<tr >
					<td >
						&nbsp; 
					</td>
				</tr>
			</table> <!-- Table, space end-->
		</td>
	</tr> <!-- Row, space end-->
	
	<tr  > <!-- Row, viewdata start  //////////////////// -->
		<td >
			<div class="viewdata" style="display:none"  id="viewdata">
				<table id="tdata" name="tdata" width="90%" border="0" align="center" >
			  
				</table>
			</div>			
		</td>
	</tr> <!-- Row, viewdata end ////////////////////-->
	
	<tr > <!-- Row, space start-->
		<td > <!-- Td, form start-->
			<table class="space"> <!-- Table, space start-->		
				<tr >
					<td >
						&nbsp; 
					</td>
				</tr>
			</table> <!-- Table, space end-->
		</td>
	</tr> <!-- Row, space end-->
	<tr class="footer" id="footer1"> <!-- Row, footer start-->
			
	</tr> <!-- Row, footer end-->
</table> <!-- Outer table end-->

</body>
</html>