<?php include "include/sesionlauth.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  
  
  
</head>
<body style="background-color:#F8F9FA">

<script type="text/javascript">

$(document).ready(function(){
		
		$("#displaydiv").slideDown("slow");
		$.get("sessionProjectByPi.php", function(data, status){
		$("#pcode").html(data);
		
		});	
		var xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = function() {
		  if (this.readyState == 4 && this.status == 200) {
			document.getElementById("viewdata").innerHTML = this.responseText;
			$("#viewdata").show("slow");
		  }
		};
		
		xmlhttp.open("GET", "indentResponseByAll.php", true);
		xmlhttp.send();
});

</script>
<script type="text/javascript">
function responseByProject(val){
		$("#viewdata").hide(); 
		var pcode=$("#pcode").val();
		
		var xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = function() {
		  if (this.readyState == 4 && this.status == 200) {
			document.getElementById("viewdata").innerHTML = this.responseText;
			$("#viewdata").show("slow");
		  }
		};
		
		xmlhttp.open("GET", "indentResponseByProject.php?pcode="+pcode+"", true);
		xmlhttp.send();
}

</script>
<nav >
	<div class="container-fluid">
		<?php 
		include"include/headerboot.php"; 
		?>
	</div>
	<div class="container-fluid">
		<?php 
		include"include/MenuPi.php"; 
		?>
	</div>
	<div class="container-fluid">
	&nbsp;
	</div>
</nav>

	<div class="container" id="displaydiv" style="display:none">
        <div class="col-sm-offset-2 col-sm-8">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    Response of Animal Request (From Animal House)
                </div>

                <div class="panel-body">
                    <!-- Display Validation Errors -->
                    <!--@include('common.errors')-->

                    <!-- New Task Form -->
                    <form action="" name="indentresponseform" method="" class="form-horizontal">
                        
                        <!-- Task Name -->
                        <div class="form-group">
							<label for="pcode" class="col-sm-3 control-label"><span style="color: red">*</span>Protocol:</label>
							<div class="col-sm-6">
								<select class="form-control" required name="pcode"  id="pcode">
									<option value="0" selected="selected">Select</option>
								</select>
							</div>
						</div>
						
						<!-- Add Task Button -->
                        <div class="form-group">
                            <div class="col-sm-offset-3 col-sm-6">
                                <button type="button" class="btn btn-primary" onClick="responseByProject();">
                                    <i class="fa fa-btn fa-search"></i>Search
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
		</div>
		<div class="col-sm-12">
			<div id="viewdata" class="panel panel-success" style="display:none">
			</div>
		</div>
		
    </div>
	<div>&nbsp;</div><div>&nbsp;</div>
	<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
	</div>
</body>
</html> 
	
	
	
	
	 
	