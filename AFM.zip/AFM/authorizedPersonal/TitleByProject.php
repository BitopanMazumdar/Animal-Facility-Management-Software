<?php include "include/sesionlauth.php"; ?>
 
<?php 
	$prcode= filter_var($_GET['prcode'], FILTER_SANITIZE_STRING);		
	//$prcode="project3";
	if($prcode!=""){
		include "DBconnect.php" ;
		
		$result = mysqli_query($db,"SELECT DISTINCT ProjectName FROM projects WHERE ProjectCode='$prcode' ORDER BY ProjectCode DESC");
		$str="";
		
		while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
			
			$str=$str.$pass['ProjectName'];
			
		}
		echo $str;
		mysqli_free_result($result);
		mysqli_close($db);
	}else{
		echo "<script>alert('Invalid protocol !'); window.history.go(-1);</script>";
	}
		
?>	