<?php include "include/sesionlauth.php"; ?>
 <?php 
	
		include "DBconnect.php";
			
			$i=0;
			$j=1;
			$resultPI = mysqli_query($db,"SELECT Projectcode FROM projects WHERE PrincipalInvestigator = '$piname' ORDER BY ProjectCode,FromDate DESC");
			$str="<div class=\"panel-heading\" >
                        Response from animal house
                  </div>

                    <div class=\"panel-body  table-responsive\" >
                        <table class=\"table table-striped \">
                            <thead>
                                <th>S.No.</th>
								<th>Protocol</th>
								<th>Request Date</th>
								<th>Indenter</th>
								<th>Requested Date</th>
								<th>Assistant</th>
								<th>Sp. Request</th>
								<th>&nbsp;</th>
								<th>&nbsp;</th>
                                
                            </thead>
                            <tbody>";
							
							while($passPI=mysqli_fetch_array($resultPI,MYSQLI_BOTH)){
		
							$Pipcode= $passPI['Projectcode'];
							$result = mysqli_query($db,"SELECT IndentNumber, Projectcode, Title,  RName, ARDate,IndentTime, Duration, TAssistance, SRequest,IndentDate FROM indentform WHERE Projectcode='$Pipcode' ORDER BY IndentNumber DESC ");
							static $i=1;
								while($pass=mysqli_fetch_array($result,MYSQLI_BOTH)){
									$str=$str."
									<tr>
										<td class=\"table-text\"><div>".$i."</div></td>
										<td class=\"table-text\"><div>".$pass['Projectcode']."</div></td>
										<td class=\"table-text\"><div>".$pass['IndentDate']."</div></td>
										<td class=\"table-text\"><div>".$pass['RName']."</div></td>
										<td class=\"table-text\"><div>".$pass['ARDate']."</div></td>
										<td class=\"table-text\"><div>".$pass['TAssistance']."</div></td>
										<td class=\"table-text\"><div>".$pass['SRequest']."</div></td>
										<td class=\"remOnPrint\">
											<input type=\"hidden\" readonly name=\"anDetail$j\" id=\"anDetail$j\" value=\"".$pass['IndentNumber']."\" />
											<button type=\"button\" class=\"btn btn-info\" id=\"anbutton$j\" onClick=\"anDetail($j);\">
												<i class=\"fa fa-btn fa-info\"></i> Animal
											</button>	
										</td>
										<td class=\"remOnPrint\">
											<input type=\"hidden\" readonly name=\"response$j\" id=\"response$j\" value=\"".$pass['IndentNumber']."\" />
											<button type=\"button\" class=\"btn btn-warning\" id=\"responsebutton$j\" onClick=\"anresponse($j);\">
												<i class=\"fa fa-btn fa-bell\"></i> Response
											</button>	
										</td>
										
									</tr>
									<tr id=\"showanDetail$j\" style=\"display:none;\" >
										<td colspan=\"8\"><div class=\"table-responsive\" id=\"divanDetail$j\"></div></td>
									</tr>
									<tr id=\"showresponse$j\" style=\"display:none;\" >
										<td colspan=\"8\"><div class=\"table-responsive\" id=\"divresponse$j\"></div></td>
									</tr>";
									
									$j++;
									$i++;									
								}
							}
							if($i==1){
								$str=$str. "<tr><td colspan=\"2\" class=\"table-text text-danger\"><div>*No Records found</div></td></tr>";
								
							}else if($i==0){
								$str=$str. "<tr><td colspan=\"2\" class=\"table-text text-danger\"><div>*No Ongoing Project </div></td></tr>";
								
							}
							
							$str=$str."</tbody>
                        </table>
                    </div>
                </div>";
				
			echo $str;
	
	mysqli_close($db);
?>