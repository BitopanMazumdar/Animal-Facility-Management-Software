<?php include "include/sesionlauth.php"; ?>
 <?php 
$dtype = filter_var($_GET['dtype'], FILTER_SANITIZE_STRING);	
$str="<div class=\"panel-heading\">
				<button type=\"button\" class=\"btn btn-danger\" onclick=\"javascript:printDiv()\" ><i class=\"fa fa-btn fa-print\"></i> Print</button>
				<span class=\"text-primary\" >&nbsp;&nbsp;&nbsp;&nbsp;	Meeting record</span>
			</div>

			<div class=\"panel-body  table-responsive\" id=\"printdiv\">
				<table class=\"table table-bordered table-hover\">
				<thead>
					<th  >Line</th>
						<th >Meeting Title</th>
						<th >Minutes</th>
						<th >Reference Date</th>
						<th class=\"remOnPrint\" >&nbsp;</th>
				</thead>
				<tbody>"; 
	
	if($dtype != ""){
	   include "DBconnect.php";
	     
					 				  
					//meeting(MeetingID, Minutes, MDocumentTitle, MReferenceDate, DocumentName)		
					$result1 = mysqli_query($db,"SELECT * FROM meeting WHERE MDocumentTitle='$dtype' ORDER BY MReferenceDate DESC");
					if($result1){
					$j=1;
					
					while($pass=mysqli_fetch_array($result1,MYSQLI_BOTH)){

					$str= $str. "<tr>
						<td >".$j."</td>
						<td>".$pass['MDocumentTitle']." </td>
						<td >".$pass['Minutes']."</td>
						<td >".$pass['MReferenceDate']." </td>
						<td class=\"linkview\"><a href=\"../uploads/".$pass['DocumentName']."\"><i class=\"fa fa fa-download\"></i> Download</a> </td>
						
						</tr>";
							$j++;
					}
					if($j== 1){
						$str=$str. "<tr><td colspan=\"5\" class=\"table-text text-danger\"><div>*No Records found</div></td></tr>";
					}	
					
					mysqli_free_result($result1);
				}else{
					$str=$str. "<tr><td colspan=\"5\" class=\"table-text text-danger\"><div>*Error, Contact Admin.</div></td></tr>";
				}
				
		mysqli_close($db);
	}else{
		$str=$str. "<tr><td colspan=\"5\" class=\"table-text text-danger\"><div>*Error, Invalid input.</div></td></tr>";
	}
	$str=$str."</tbody>
				</table>
			</div>
		</div>";
		echo $str;
?>