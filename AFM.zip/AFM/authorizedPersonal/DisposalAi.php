<?php include "include/sesionlauth.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  <link rel="stylesheet" href="css/custom.css">
  
</head>
<body style="background-color:#F8F9FA">
<nav >
 <div class="container-fluid">
	<?php 
	include"include/headerboot.php"; 
	?>
  </div>
  <div class="container-fluid">
	<?php 
	include"include/MenuPi.php"; 
	?>		
  </div>  
</nav>
<!-- Script start-->
<script type="text/javascript">     
    
$(document).ready(function(){
	$("#main").show("slow");
	// get piname from session variable and fetch projects of the PI    
	$.get("sessionProjectByPi.php", function(data, status){
	$("#pcode").html(data);
	
	});	
});
</script>

<script type="text/javascript">
$(document).ready(function(){
	  $("#asst_no").click(function(){
		  $("#assist").hide();
	  });
	  $("#asst_yes").click(function(){
	  //alert("hello");
			$("#assist").show();
	 });
		  $("#other").click(function(){
		 $("#other_assist").toggle();
		  $("#other_assist").val("");
	 
	  });
	  
	   $("#addRow").click(function(){
	   
	   val=$("#row_no").val();
	   if(val!=7)
	   {
	   val++;
	   $("#row_no").val(val);
		$("#row"+val).slideDown();
		$("#close"+val).show();
		val--;
		$("#close"+val).hide();
		}
	  }); 
 
 
});

function CheckAvail(val,no)
{
		//alert("in check");
	check=1;
	z=$("#row_no").val();
	
	for(x=1;x<=z;x++)
	{
	//alert(x);
	if(x!=no)
	{
		if($("#strain"+x).val()==$("#strain"+no).val())
		{
			//alert("strain same");
			if($("#sex"+x).val()==$("#sex"+no).val())
			{
				$("#strain"+no).val("");
				$("#sex"+no).val("");
				$("#no_of_an"+no).val("");
				check=0;
				alert("Species/Strain allready selected");
			}
			else
			{
				//alert("gender different");
				if($("#no_of_an"+x).val()=="")
				nav=0;
				else
				nav=$("#no_of_an"+x).val();
				val=parseInt(val)+parseInt(nav);
				
			}
		}
	}
	//x++;
	}

	
	pid=$("#pcode").val();
	aid=$("#strain"+no).val();
	gen=$("#sex"+no).val();
	if(check==1 && val!="" && pid!=0 && aid!="")
	{
		//$("#avl"+no).html("<img src='images/loading.gif' height='20' width='20' />");
		$.get("AnimalAvailabilty.php",{
			aid:aid,
			pid:pid,
			gen:gen,
			val:val
		},
		  function(data,status){
			  
			if(data==-2){
				 $("#avl"+no).html("");
				  $("#no_of_an"+no).val("");
				alert("something went wrong!");
			}else if(data==-1)
			  {
				 $("#avl"+no).html("<img src='images/right.jpg' height='10' width='12' />"); //  
			  }
			  else
			  {
				$("#avl"+no).html("");
				  $("#no_of_an"+no).val("");
				  alert("Exeeds approved Species/Strain limit, Approved = "+data);
			  }
			  });

	}
	else
	 $("#avl"+no).html("");
}

function Close(val)
{
	 $("#no_of_an"+val).val("");
	 $("#avl"+val).html("");
	  $("#strain"+val).val("");
	 $("#sex"+val).val("");

	 $("#row"+val).slideUp();
	 val--;
	 $("#row_no").val(val);
	 $("#close"+val).show("slow");
 
 }
function checkGender(val,no)
{
	 $("#no_of_an"+no).val("");
	 $("#avl"+no).html("");
	 pco=$("#pcode").val();
	 $.get("Genderquery.php",
	  {
		aid:val, pc:pco
	  },
	  function(data,status){
		 //alert(data);
		 $("#sex"+no+"").html(data);
	   /* if(data=="Any")
		{
	   // $("#sex"+no+"").val("");
		$("#sex"+no+"").val("Male");
		$("#sex"+no+"").show();
		
		}
		else
		{
		
			$("#sex"+no+"").hide();
			$("#sex"+no+"").val("");
		} */
	  }); 
}

function DoEmpty(no)
{
	$("#no_of_an"+no).val("");
	$("#avl"+no).html("");
}
function showTitle(val)
{
	window.location="Title_query.php?page=indent_form&proj="+val;
}

function CheckDate(ete)
{
    
	return true;
    
}
</script>
<script type="text/javascript">
function showOtherReason(eve){
	
	//alert(eve);
	if(eve=="other"){
		//document.getElementById('otherRoute').style.display = "block";
		$('#otherReason').show();
   } else{
		$('#otherReason').hide();
   }
	//$("#route").show();
}
function showOtherEuthanasia(eve){ 
	if(eve=="other"){
		//document.getElementById('otherRoute').style.display = "block";
		$('#otherEuthanasia').show();
   } else{
		$('#otherEuthanasia').hide();
   }
}

function getTitle(val){
	$.get("TitleByProject.php", {prcode:val},function(data, status){
	//$("#title").html(data);
	$("#title").val(data);
	});
}
</script>
<script type="text/javascript">

function getSpstrain(val){
	//rowno=$("#row_no").val();
	$.get("SpStrainByProject.php", {prcode:val}, function(data, status){
		
		for(i=1; i<=7; i++){
			// "<select name=\"strain1\" id=\"strain"+i+"\" onchange=\"checkGender(this.value,1)\"><option value=\"\">Select</option>" + data+"</select>";
            //alert(data);    
			$("#strain"+i).html(data);
		}
    });
}	
</script>

<!-- Validation-->
<script type="text/javascript">
function valid(){
	frm = document.myform;
	no=frm.row_no.value;
	
	  if(frm.recn.value =="")
	  {
			alert("Please Enter Disposed By !");
			frm.recn.focus();
			return false;
	  }
	  	 
	  for(j=1;j<=no;j++)
		{
					
		  if(document.getElementById("strain" + j).value =="")
		  {
				alert("Please enter species/starin !");
				document.getElementById("strain" + j).focus();
				return false;
		  }
		  		  
		/* if(document.getElementById("sex" + j).value =="")
		  {
				alert("Please enter Gender !");
				document.getElementById("sex" + j).focus();
				return false;
		  }
		  */
		  if(document.getElementById("no_of_an" + j).value ==0)
		  {
				alert("Please enter No. OF Animals !");
				document.getElementById("no_of_an" + j).focus();
				return false;
		  }
		   
		  if(document.getElementById("age" + j).value =="" )
		  {
				alert("Please enter Weight/Age !");
				document.getElementById("age" + j).focus();
				return false;
		  }
		}
	
		if(frm.reason.value =="other")
	  {
		  if(frm.oReason.value==""){
			alert("Please Enter Reason for Disposal !");
			frm.oReason.focus();
			return false;
		  }
	  }
	  if(frm.euthanasia.value =="other")
	  {
		  if(frm.oEuthanasia.value==""){
			alert("Please Enter Method of Euthanasia !");
			frm.oEuthanasia.focus();
			return false;
		  }
	  }
	  if(frm.reqdate.value =="")
	  {
			alert("Please Enter Requested Date!");
			frm.reqdate.focus();
			return false;
	  }
	 
	  var r = confirm("confirm submit!");
	  if (r == true) {
		return true;
	  } else {
		frm.pcode.focus();
		return false;
	  }
	  
}
</script>		

<!-- End of validation -->

<!-- Script end-->
<div class="container" id="main" style="display:none">
<br>
<!-- submit message -->
	<?php 
		
		if(isset($_SESSION['message'])){
			echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
			unset($_SESSION['message']);
		}
								
	?>
<!-- submit message -->
<form class="form-horizontal" name="myform" autocomplete="off" method="post" action="Disposal_proccessAi.php" onsubmit="return valid();"> 
<button type="button" class="btn btn-danger col-sm-offset-5" onClick="document.location.href='ViewDisposalAi.php'"><i class="fa fa-btn fa-plus"></i> View Disposal 
					</button>	
	<div class="form-group">
	<fieldset>
	<legend>Disposal management </legend>
		<table class="table" width="70%" align="center" >
				
					 <tr>
						<th width="30%" >Protocol</th>
						
						<td width="70%"   ><select required class="form-control" name="pcode" onchange="getTitle(this.value);getSpstrain(this.value);" id="pcode">
						 <option value="0" selected="selected">Select</option>
						 </select></td>
					  </tr>
					  <tr id="toi">
						<th>Title of the Investigation </th>
						
						<td   >
						<textarea class="form-control" name="title" rows="3" readonly="true" id="title" type="text"></textarea> 
						<!--<input class="form-control" name="title" type="text" id="title" readonly="true" value="" />-->
						</td>
					  </tr>
					  <tr>
						<th>Disposed by</th>
						
						<td   ><input style="text-transform: capitalize;" pattern="[a-zA-Z ]*" required class="form-control" name="recn" type="text" id="recn" /></td>
					  </tr>
					</table>
					</fieldset>
				</div>
				<div class="form-group">
				<fieldset>
				<legend>Animal specification </legend>
					<?php include"anSpecificationStr.php";?>
				</fieldset>
				</div>
				<div class="form-group">
				<fieldset>
				<legend>Disposal details </legend>
					<table class="table">	  
					  <tr>
						<th>Reason for Disposal</th>
						
						<td> <select required class="form-control" name="reason" id="reason" onchange="showOtherReason(this.value);">
						<option selected="selected" value="">Select</option> 
						<option value="Experimental End Point"> Experimental End Point </option>  
						<option value="Deviation in Parameter"> Deviation in Parameter </option>
						<option value="Disease Condition"> Disease Condition </option>                                        
						<option  value="other" > Other </option>
						</select> 
						</td> 
					</tr >
						<tr style="display:none" id="otherReason">
						<th>Other Reason </th>
						<td   ><input class="form-control" style="text-transform: capitalize;" pattern="[a-zA-Z ]*" id="oReason" name="oReason"  type="text" placeholder="Enter other"/> </td>
						</tr>
						<tr>
						<th>Method of Euthanasia </th>
						
						<td   > <select required class="form-control" name="euthanasia" id="euthanasia" onchange="showOtherEuthanasia(this.value);">
							<option selected="selected" value="">Select</option> 
							<option value="C02  Euthanasia"> C02  Euthanasia </option>  
							<option value="Overdose of Isoflurane"> Overdose of Isoflurane </option>
							<option value="Overdose of injectable Anesthesia"> Overdose of injectable Anesthesia </option>    
							<option  value="Cervical Dislocation" > Cervical Dislocation </option>                                    
							<option  value="other" > Other </option>
							</select> </td>
					  </tr>
					  <tr style="display:none" id="otherEuthanasia">
						<th>Other Euthanasia Method </th>	
						
						<td   ><input style="text-transform: capitalize;" pattern="[a-zA-Z ]*" id="oEuthanasia" class="form-control" name="oEuthanasia" type="text" placeholder="Enter other"/> </td>
						</tr>
						<tr>
						<th width="30%">Disposal Date </th>
						
						<td width="70%"  > <input required id="reqdate" class="form-control" name="reqdate" type="date" value="" /> </td>
				   
					</table>
					</fieldset>
				</div>
	<!-- Add Task Button -->
	<div class="form-group">
	
		<div class="col-sm-offset-4 col-sm-6">
			<button type="submit" class="btn btn-danger">
				<i class="fa fa-btn fa-save"></i> Save
			</button>
			<button type="button" class="btn btn-warning" onclick="window.history.back()">
				<i class="fa fa-btn fa-arrow-left"></i> Back
			</button>
		</div>
	
	</div>
</form>
</div>
		
	<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
	</div>
	
</body>
</html>