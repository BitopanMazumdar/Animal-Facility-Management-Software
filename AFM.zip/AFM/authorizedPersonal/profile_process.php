<?php include "include/sesionlauth.php"; ?>
 
<?php 
	
	$cpass=filter_var($_POST['cpass'], FILTER_SANITIZE_STRING);
	$pass=filter_var($_POST['pass'], FILTER_SANITIZE_STRING);
	$p=sha1($pass);
	$cp=sha1($cpass);
	

	if($cpass!="" && $pass !==""){
		include "DBconnect.php";
		
		$resultck = mysqli_query($db,"SELECT DISTINCT PiEmail FROM projectincharge WHERE PiPasscode='$cp'");
					
		if($pass=mysqli_fetch_array($resultck,MYSQLI_ASSOC)){
			mysqli_free_result($resultck);
			mysqli_query($db,"UPDATE projectincharge SET PiPasscode='$p' WHERE (PiPasscode='$cp' AND PiEmail='$pie')" );
			$result = mysqli_affected_rows($db);
			if($result >0){
				
				$_SESSION['message']="Successfully changed password  !";
				echo '<META HTTP-EQUIV="Refresh" Content="0; URL=profile.php">';
			}elseif($result ==0){
				$_SESSION['message']="Old and new password are same  !";
				echo '<META HTTP-EQUIV="Refresh" Content="0; URL=profile.php">';
			}
			else{
				$_SESSION['message']="Error, contact admin  !";
				echo '<META HTTP-EQUIV="Refresh" Content="0; URL=profile.php">';
			}
			
			
			mysqli_close($db);
		}else{
			$_SESSION['message']="Current password does not exist !";
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=profile.php">';
		}
	}else{
		
		$_SESSION['message']="Error, Invalid input  !";
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=profile.php">';
	}
	
?>
