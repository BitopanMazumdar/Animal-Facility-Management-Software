<?php include "include/sesionlauth.php"; ?>
 <?php 
	$pcode=filter_var($_GET['pcode'], FILTER_SANITIZE_STRING);
	if($pcode!=""){
		include "DBconnect.php";
			$i=1;			
			$str="<div class=\"panel-heading\" >
                        Response from animal house
                  </div>

                    <div class=\"panel-body  table-responsive\" >
                        <table class=\"table table-striped \">
                            <thead>
                                <th>S.No.</th>
								<th>Protocol</th>
								<th>Indent Date</th>
								<th>Indenter</th>
								<th>Needed on</th>
								<th>Assistant</th>
								<th>Sp. Request</th>
								<th>&nbsp;</th>
								<th>&nbsp;</th>
                                
                            </thead>
                            <tbody>";
							
							$result = mysqli_query($db,"SELECT IndentNumber, Projectcode, Title,  RName, ARDate,IndentTime, Duration, TAssistance, SRequest,IndentDate FROM indentform WHERE Projectcode='$pcode' ORDER BY IndentNumber DESC");
							
							while($pass=mysqli_fetch_array($result,MYSQLI_BOTH)){
								$str=$str."
								<tr>
									<td class=\"table-text\"><div>".$i."</div></td>
									<td class=\"table-text\"><div>".$pass['Projectcode']."</div></td>
									<td class=\"table-text\"><div>".$pass['IndentDate']."</div></td>
									<td class=\"table-text\"><div>".$pass['RName']."</div></td>
									<td class=\"table-text\"><div>".$pass['ARDate']."</div></td>
									<td class=\"table-text\"><div>".$pass['TAssistance']."</div></td>
									<td class=\"table-text\"><div>".$pass['SRequest']."</div></td>
									<td class=\"remOnPrint\">
											<input type=\"hidden\" readonly name=\"anDetail$i\" id=\"anDetail$i\" value=\"".$pass['IndentNumber']."\" />
											<button type=\"button\" class=\"btn btn-info\" id=\"anbutton$i\" onClick=\"anDetail($i);\">
												<i class=\"fa fa-btn fa-info\"></i> Animal
											</button>	
									</td>
									<td class=\"remOnPrint\">
										<input type=\"hidden\" readonly name=\"response$i\" id=\"response$i\" value=\"".$pass['IndentNumber']."\" />
										<button type=\"button\" class=\"btn btn-warning\" id=\"responsebutton$i\" onClick=\"anresponse($i);\">
											<i class=\"fa fa-btn fa-bell\"></i> Response
										</button>	
									</td>
								</tr>
								<tr id=\"showanDetail$i\" style=\"display:none;\" >
									<td colspan=\"8\"><div class=\"table-responsive\" id=\"divanDetail$i\"></div></td>
								</tr>
								<tr id=\"showresponse$i\" style=\"display:none;\" >
									<td colspan=\"8\"><div class=\"table-responsive\" id=\"divresponse$i\"></div></td>
								</tr>";
								
								$i++;									
							}
							
							if($i==1){
								$str=$str. "<tr><td colspan=\"2\" class=\"table-text text-danger\"><div>*No Records found</div></td></tr>";
								
							}							
							$str=$str."</tbody>
                        </table>
                    </div>
                </div>";
				
			echo $str;
	
		mysqli_close($db);
	}else{
		echo '<script type="text/javascript">alert("Please enter Protocol !");window.history.go(-1);</script>';
	}
?>