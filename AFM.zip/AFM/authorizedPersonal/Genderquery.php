<?php include "include/sesionlauth.php"; ?>
 <?php 
	$spsr= $_GET['aid'];
	$pcode= $_GET['pc'];
	//$spsr="str3";	
	
	include "DBconnect.php" ;
	
	$result = mysqli_query($db,"SELECT DISTINCT Gender FROM projectanimal WHERE SpStrain='$spsr' AND ProjectCode='$pcode'");
	//$result = mysqli_query($db,"SELECT DISTINCT Gender FROM projectanimal WHERE SpStrain='$spsr'");
	//$str =" <option value=\"\" >Select</option>";
	 $str ="";                               
	while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
		
		$str = $str."<option value=\"".$pass['Gender']."\">".$pass['Gender']."</option>";
		
	}
	
	echo $str;
	
	mysqli_free_result($result);
	mysqli_close($db);
		
?>	