<?php include "include/sesionlauth.php"; ?>
 <?php 
	$inumber=filter_var($_GET['inumber'], FILTER_SANITIZE_STRING);
	if($inumber!=""){
		include "DBconnect.php";
			$i=1;			
			$str="<table class=\"table table-bordered table-info\">
                            <thead>
								<th>Sl. No.</th>
								<th>Animal</th>
								<th>Gender</th>
								<th>Quantity</th>
								<th>Wieght/Age</th>  
                            </thead>
                            <tbody>";
							
							$result = mysqli_query($db,"SELECT SpStrain, Gender, Weight_Age,NoAnimal FROM indentanimal WHERE IndentNumber='$inumber' ORDER BY EntryNo DESC");
							
							while($pass=mysqli_fetch_array($result,MYSQLI_BOTH)){
								$str=$str."
								<tr>
									<td class=\"table-text\"><div>".$i."</div></td>
									<td class=\"table-text\"><div>".$pass['SpStrain']."</div></td>
									<td class=\"table-text\"><div>".$pass['Gender']."</div></td>
									<td class=\"table-text\"><div>".$pass['NoAnimal']."</div></td>
									<td class=\"table-text\"><div>".$pass['Weight_Age']."</div></td>
																		
								</tr>";
								
								$i++;
							}
							
							if($i==1){
								$str=$str. "<tr><td colspan=\"2\" class=\"table-text text-danger\"><div>*No Records found</div></td></tr>";
								
							}							
							$str=$str."</tbody>
                        </table>
                    ";
				
			echo $str;
	
		mysqli_close($db);
	}else{
		echo '<script type="text/javascript">alert("Please enter Protocol !");window.history.go(-1);</script>';
	}
?>