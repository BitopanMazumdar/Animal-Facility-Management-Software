<?php include "include/sesionlauth.php"; ?>
 <?php 
	//session_start();
	$projcode= filter_var($_GET['proj'], FILTER_SANITIZE_STRING);
	
	if($projcode!=""){	
					
		include "DBconnect.php";
						
		$result = mysqli_query($db,"SELECT ProjectCode, pmName, pmDesignation, pmDepartment, pmPhone, pmMobile, pmEmail, pmExperience, pmPasscode, pmAddress, pmPin FROM projectmember WHERE ProjectCode='$projcode'");
		
		$i=1;
		
		$str="<div class=\"panel-heading\" id=\"rempbdiv\">
							Member Details
						</div>

						<div class=\"panel-body table-responsive\">
							<table class=\"table table-striped task-table\">
								<thead>
									<th>Protocol</th>
									<th>Name</th>
									<th>Email</th>
									<th>Phone</th>
									<th>Mobile</th>
									<th>Designation</th>
									<th>Department</th>
									<th>Experience</th>
									<th>Address</th>
									<th class=\"remOnPrint\">&nbsp;</th>								
								</thead>
								<tbody>";
							//projectmember(ProjectCode, pmName, pmDesignation, pmDepartment, pmPhone, pmMobile, pmEmail, pmExperience, pmPasscode, pmAddress, pmPin, created_at, updated_at, author) 
							while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){				
								$str=$str."
								<tr>
									<td class=\"table-text\"><div>".$pass['ProjectCode']."</div></td>
									<td class=\"table-text\"><div>".$pass['pmName']."</div></td>
									
									<td class=\"table-text\"><div>".$pass['pmEmail']."</div></td>
									<td class=\"table-text\"><div>".$pass['pmPhone']."</div></td>
									<td class=\"table-text\"><div>".$pass['pmMobile']."</div></td>
									
									<td class=\"table-text\"><div>".$pass['pmDesignation']."</div></td>
									<td class=\"table-text\"><div>".$pass['pmDepartment']."</div></td>
									<td class=\"table-text\"><div>".$pass['pmExperience']."</div></td>
									
									<td class=\"table-text\"><div>".$pass['pmAddress']."</div></td>
									
									<!-- Task Delete Button -->
									<td class=\"remOnPrint\">
										<form action=\"pmEdit.php\" method=\"POST\">
											<input class=\"form-control\" type=\"hidden\" readonly name=\"pmEmail\" id=\"pmEmail\" value=\"".$pass['pmEmail']."\">
											<button id=\"btncmr\" type=\"submit\" class=\"btn btn-danger\">
												<i class=\"fa fa-btn fa-edit\"></i>Edit
											</button>
										</form>
									</td>
								</tr>";	
								$i++;		 
							}
							if ($i==1){
								$str=$str."<tr><td colspan=\"10\" class=\"table-text text-danger \"><div>No Records found.</div></td></tr>";								
							}
							$str=$str."</tbody>
                        </table>
                    
                </div>";
				
			echo $str;
					
		
		mysqli_close($db);
	}else{
		echo "<script>alert('Invalid protocol !'); window.history.go(-1);</script>";
	}
	
	?>