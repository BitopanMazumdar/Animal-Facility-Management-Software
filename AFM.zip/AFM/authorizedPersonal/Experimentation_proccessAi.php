<?php include "include/sesionlauth.php"; ?>
<?php 

$pcode = filter_var($_POST['pcode'], FILTER_SANITIZE_STRING);
$title = filter_var($_POST['title'], FILTER_SANITIZE_STRING);
$recn = filter_var($_POST['recn'], FILTER_SANITIZE_STRING); 
$group = filter_var($_POST['group'], FILTER_SANITIZE_STRING); 
$oRoute = filter_var($_POST['route'], FILTER_SANITIZE_STRING);
$oSample = filter_var($_POST['SampleCollection'], FILTER_SANITIZE_STRING);
$oInterval = filter_var($_POST['SampleInterval'], FILTER_SANITIZE_STRING);
$reqdate = filter_var($_POST['reqdate'], FILTER_SANITIZE_STRING);
$scval = filter_var($_POST['scval'], FILTER_SANITIZE_STRING);
$sival = filter_var($_POST['sival'], FILTER_SANITIZE_STRING);

//$idate= date("Y-m-d");

if($oRoute=="other"){
	$oRoute = filter_var($_POST['oRoute'], FILTER_SANITIZE_STRING);
}
if($oSample=="other"){
	$oSample = filter_var($_POST['osample'], FILTER_SANITIZE_STRING);
}
if($oInterval=="other"){
	$oInterval = filter_var($_POST['ointerval'], FILTER_SANITIZE_STRING);
}

$rowno= filter_var($_POST['row_no'], FILTER_SANITIZE_STRING);

for($i=1; $i<=$rowno; $i++){
	$strain[$i]=filter_var($_POST['strain'.$i], FILTER_SANITIZE_STRING);
	$gender[$i]=filter_var($_POST['sex'.$i], FILTER_SANITIZE_STRING);
	$age[$i]=filter_var($_POST['age'.$i], FILTER_SANITIZE_STRING);	
	$noa[$i]=filter_var($_POST['no_of_an'.$i], FILTER_SANITIZE_STRING);
}

$flag=1;
if($pcode!=""){
	include "DBconnect.php";
			
		//experimentationform(ExperimentationNumber, Projectcode, Title, ExperimentBy, ExperimentDate, ExpGroup, Route, SampleCollection, SCInterval) 
		$sql1="INSERT INTO experimentationform(Projectcode, Title, ExperimentBy, ExperimentDate, ExpGroup, Route, SampleCollection, SCInterval,SCvalue,SIvalue) 
				values ('$pcode', '$title', '$recn', '$reqdate','$group', '$oRoute', '$oSample', '$oInterval','$scval','$sival')";
		$result1 = mysqli_query($db, $sql1);
		
		if(!$result1)
		  {
			$flag=0;
			$_SESSION['message']="Error ! Contact admin  !";
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=ExperimentationAi.php">';
			die('Error: ' . mysqli_error($db));
		  }
		  else{
				$sql21="SELECT MAX(ExperimentationNumber) AS expNumber FROM experimentationform ";
				$resultIN= mysqli_query($db,$sql21);
				if(!$resultIN){
					$flag=0;
					$_SESSION['message']="Error ! Contact admin  !";
					echo '<META HTTP-EQUIV="Refresh" Content="0; URL=ExperimentationAi.php">';
					die('Error: ' . mysqli_error($db));
					
				}else{
					//if($pass=mysqli_fetch_array($resultIN,MYSQLI_ASSOC)){
					while($pass=mysqli_fetch_array($resultIN,MYSQLI_ASSOC)){
						
						$inumber=$pass['expNumber'];
						
						for($i=1; $i<=$rowno; $i++){
							//experimentationanimal(EntryNo, ExperimentationNumber, SpStrain, Gender, Weight_Age, NoAnimal)		
							$sql2="INSERT INTO experimentationanimal(ExperimentationNumber, SpStrain, Gender, Weight_Age, NoAnimal) values ('$inumber','$strain[$i]','$gender[$i]', '$age[$i]', '$noa[$i]')";
							$result2 = mysqli_query($db, $sql2);
							if(!$result2)
							  {						
								$flag=0;
								die('Error: ' . mysqli_error($db));
							  }							
						}
				
					}
				}
			}
		
			if($flag==1){
				$_SESSION['message']="Succesfully submitted data";
				echo '<META HTTP-EQUIV="Refresh" Content="0; URL=ExperimentationAi.php">';
								  
			}else{
				$sql3="DELETE FROM experimentationform WHERE ExperimentationNumber ='$inumber' ";

				$result3 = mysqli_query($db, $sql3);
				
				if(!$result3)
				  {
					$_SESSION['message']="Error ! contact admin  !";
					echo '<META HTTP-EQUIV="Refresh" Content="0; URL=ExperimentationAi.php">';
					die('Error: ' . mysqli_error($db));
				  }else{
					   $_SESSION['message']="Error ! Fail to submit animal information. Please enter details properly  !";
					   echo '<META HTTP-EQUIV="Refresh" Content="0; URL=ExperimentationAi.php">';
				  }
			}

			mysqli_close($db);
		  }else{
			$_SESSION['message']="Invalid Input  ! Please enter data properly  !";
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=ExperimentationAi.php">';
		  }
?>
