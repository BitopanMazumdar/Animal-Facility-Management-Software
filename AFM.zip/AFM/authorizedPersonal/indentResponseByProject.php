<?php include "include/sesionlauth.php"; ?>
 <?php 
	$pcode=filter_var($_GET['pcode'], FILTER_SANITIZE_STRING);
	if($pcode!=""){
		include "DBconnect.php";
			
			$query1="SELECT * FROM responsenew WHERE IndentNumber IN (SELECT IndentNumber FROM indentform WHERE ProjectCode='$pcode' ) ORDER BY ResponseNumber DESC";
			$i=0;
			$result1 = mysqli_query($db,$query1);
			$str="<div class=\"panel-heading\">
                        Response from animal house
                    </div>

                    <div class=\"panel-body  table-responsive\" >
                        <table class=\"table table-striped \">
                            <thead>
                                <th>Protocol</th>
								<th>Message</th>
								<th>Date</th>
								<th>Time</th>
								<th>Delivery Point</th>
								<th>Assistant</th>
                                
                            </thead>
                            <tbody>";
							while($pass=mysqli_fetch_array($result1,MYSQLI_BOTH)){
								$str=$str."
								<tr>
									<td class=\"table-text\"><div>".$pcode."</div></td>
									<td class=\"table-text\"><div>".$pass['MSG']."</div></td>
									<td class=\"table-text\"><div>".$pass['DateSupply']."</div></td>
									<td class=\"table-text\"><div>".$pass['TimeSupply']."</div></td>
									<td class=\"table-text\"><div>".$pass['DeliveryPoint']."</div></td>
									<td class=\"table-text\"><div>".$pass['TAName']."</div></td>
									<!-- Task Delete Button -->	
								</tr>";
								$i++;
							}
							
							$query2="SELECT * FROM rejection WHERE IndentNumber IN (SELECT IndentNumber FROM indentform WHERE ProjectCode='$pcode') ORDER BY RejectNumber DESC";
							$result2 = mysqli_query($db,$query2);
							$j=0;
							while($pass=mysqli_fetch_array($result1,MYSQLI_BOTH)){
								$str=$str."
								<tr>
									<td class=\"table-text\"><div>".$pass2['IndentNumber']."</div></td>
									<td class=\"table-text\"><div>".$pass2['MSG']."</div></td>									
									<!-- Task Delete Button -->
									
								</tr>";
								$j++;
							}
							
							if ($i== 0 && $j== 0){
								$str=$str. "<tr><td colspan=\"6\" class=\"table-text text-danger\"><div>*No Records found</div></td></tr>";
							}
							$str=$str."</tbody>
                        </table>
                    </div>
                </div>";
				
			echo $str;
			
		mysqli_free_result($result1);
		mysqli_free_result($result2);
		mysqli_close($db);
	}else{
		echo '<script type="text/javascript">alert("Please enter Protocol !");window.history.go(-1);</script>';
	}
?>