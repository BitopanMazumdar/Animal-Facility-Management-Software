<?php include "include/sesionlauth.php"; ?>

<?php 

$pcode = filter_var($_POST['pcode'], FILTER_SANITIZE_STRING);
$title = filter_var($_POST['title'], FILTER_SANITIZE_STRING);
$recn = filter_var($_POST['recn'], FILTER_SANITIZE_STRING);

$message="";

$reqdate = filter_var($_POST['reqdate'], FILTER_SANITIZE_STRING);
$reqtime = filter_var($_POST['reqtime'], FILTER_SANITIZE_STRING);
$period = filter_var($_POST['period'], FILTER_SANITIZE_STRING);
$assist = filter_var($_POST['assist'], FILTER_SANITIZE_STRING);

$spereq = filter_var($_POST['spereq'], FILTER_SANITIZE_STRING);
$idate= date("Y-m-d");

$rowno= filter_var($_POST['row_no'], FILTER_SANITIZE_STRING);

//echo "I m here........";

for($i=1; $i<=$rowno; $i++){
	$strain[$i]=filter_var($_POST['strain'.$i], FILTER_SANITIZE_STRING);
	$gender[$i]=filter_var($_POST['sex'.$i], FILTER_SANITIZE_STRING);
	$age[$i]=filter_var($_POST['age'.$i], FILTER_SANITIZE_STRING);
	
	$noa[$i]=filter_var($_POST['no_of_an'.$i], FILTER_SANITIZE_STRING);
}

$flag=0;
if($pcode!=""){
	include "DBconnect.php";
			
		
		$sql1="INSERT INTO indentform(Projectcode, Title, RName, ARDate, IndentTime, Duration, TAssistance, SRequest,IndentDate) values ('$pcode', '$title', '$recn', '$reqdate', '$reqtime', '$period', '$assist', '$spereq', '$idate')";
		$result1 = mysqli_query($db, $sql1);
		
		if(!$result1)
		  {
			$flag=0;
			$_SESSION['message']="Error ! contact Admin";
			die('Error: ' . mysqli_error($db));
		  }
		  else{
							
				//mail start
				$str="<html>
				<head>
				<title>Soflam, System generated email</title>
				</head>
				<body>
					<table border=\"1\" style=\"border-color: #666;border-collapse:collapse;\" cellpadding=\"10\">
						<tr style=\"background: #eee;\">
							<th>Protocol</th>
							<th>Title</th>
							<th>Requested BY</th>
							<th>Needed on</th>
							<th>Time</th>
							<th>Duration</th>
							<th>Assistant</th>
							<th>Sp. Request</th>
							
						</tr>";
								
					$str=$str."<tr>
							<td style=\"width:10%\" >".$pcode."</td>
							<td style=\"width:15%\">".$title."</td>
							<td style=\"width:10%\">".$recn."</td>
							<td style=\"width:10%\">".$reqdate."</td>
							<td style=\"width:10%\">".$reqtime."</td>
							<td style=\"width:10%\">".$period."</td>
							<td style=\"width:10%\">".$assist."</td>
							<td style=\"width:10%\">".$spereq."</td>
						</tr>
					";
					$str=$str."<tr>
					<td colspan=\"8\"><div>
						<table border=\"1\" style=\"border-color: #666;border-collapse:collapse;width:90%;\" cellpadding=\"10\">
							<tr>
								<th>Sl. No.</th>
								<th>Animal</th>
								<th>Gender</th>
								<th>Quantity</th>
								<th>Wieght/Age</th>  
							</tr>";								
					
				
				$sql21="SELECT MAX(IndentNumber) AS InNumber FROM indentform ";
				$resultIN= mysqli_query($db,$sql21);
				
				//if($pass=mysqli_fetch_array($resultIN,MYSQLI_ASSOC)){
				if($pass=mysqli_fetch_array($resultIN,MYSQLI_ASSOC)){
					
					$inumber=$pass['InNumber'];
					
					for($i=1; $i<=$rowno; $i++){
									
							$sql2="INSERT INTO indentanimal (IndentNumber,ProjectCode,SpStrain, Gender,Weight_Age,NoAnimal) values ('$inumber','$pcode','$strain[$i]','$gender[$i]', '$age[$i]', '$noa[$i]')";
							$result2 = mysqli_query($db, $sql2);
							if(!$result2)
							  {	
								$flag=0;
								$_SESSION['message']="Error ! contact Admin";
								die('Error: '.mysqli_error($db));
							  }
							else
							{															
								$str=$str."<tr>
									<td style=\"width:15%\" >".$i."</td>
									<td style=\"width:15%\" >".$strain[$i]."</td>
									<td style=\"width:15%\">".$gender[$i]."</td>
									<td style=\"width:15%\">".$age[$i]."</td>
									<td style=\"width:15%\">".$noa[$i]."</td>
									</tr>";
								$flag=1;
							}
							
						}
										
					}
					$str=$str."</table>
							</div>
						</td>
					</tr>
				</table>
			</body>
		</html>";
		  }
		
	if($flag==1){
		
		   $mailfrom="ithylasco123@gmail.com";
		   $piemail=$_SESSION['pie'];
		   //$message = $message."\n\n\n".$piname."";
		   $querymail="SELECT PiEmail FROM projectincharge WHERE Role='Animal House Incharge'";						
			$resultmail = mysqli_query($db,$querymail);
			$i=1;
			$to_email="";
			if($resultmail){
				while($passmail=mysqli_fetch_array($resultmail,MYSQLI_BOTH)){
					$to_email= $passmail['PiEmail'];
					$subject = 'Please issue animal';
					
					$headers = "MIME-Version: 1.0" . "\r\n";
					$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
					// More headers
					$headers .= "From: ".$mailfrom."\r\n";
					$headers .= "Cc: ".$piemail."\r\n";
					
					if(mail($to_email,$subject,$str,$headers)){
						$_SESSION['message']="Succesfully submitted ! Request is sent to animal house incharge via mail";
						echo '<META HTTP-EQUIV="Refresh" Content="0; URL=IndentForm.php">';
					}else{
						$_SESSION['message']="Succesfully submitted ! but fail to send mail, Inform personally  !";
						echo '<META HTTP-EQUIV="Refresh" Content="0; URL=IndentForm.php">';	
						
					} 
				}
			}else{
				$_SESSION['message']="Succesfully submitted ! but fail to send mail as no mail ID is found to send email. Inform personally  !";
				echo '<META HTTP-EQUIV="Refresh" Content="0; URL=IndentForm.php">';
			}
				  
	}
	else{
		$_SESSION['message']="Error ! contact Admin";
		$sql3="DELETE FROM indentform WHERE IndentNumber ='$inumber' ";

		$result3 = mysqli_query($db, $sql3);
		
		if(!$result3)
		  {
			//$flag=0;
			$_SESSION['message']="Error ! contact Admin";
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=IndentForm.php">';
			die('Error: '.mysqli_error($db));
		  }
		$_SESSION['message']="Fail to submit animal request. Please enter data properly  !";
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=IndentForm.php">';
	}

	mysqli_close($db);
	
}else{
	$_SESSION['message']="Invalid input data  ! Failed to submit  !";
	echo '<META HTTP-EQUIV="Refresh" Content="0; URL=IndentForm.php">';
}

?>
*/