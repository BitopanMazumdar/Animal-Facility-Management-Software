<?php //include "include/sesionlauth.php"; ?>
 
<?php 
	if(session_id() == '' || !isset($_SESSION)) {
		// session isn't started
		session_start();
	}

	$pcode=filter_var($_POST['pcode'], FILTER_SANITIZE_STRING);
	$name=filter_var($_POST['name'], FILTER_SANITIZE_STRING);
	$e=filter_var($_POST['email'], FILTER_SANITIZE_STRING);
	$phone=filter_var($_POST['phone'], FILTER_SANITIZE_STRING);
	$mobile=filter_var($_POST['mb'], FILTER_SANITIZE_STRING);
	$dg=filter_var($_POST['dg'], FILTER_SANITIZE_STRING);
	$dpt=filter_var($_POST['dpt'], FILTER_SANITIZE_STRING);
	$ex=filter_var($_POST['ex'], FILTER_SANITIZE_STRING);
	$add=filter_var($_POST['add'], FILTER_SANITIZE_STRING); 
	$pin=filter_var($_POST['pin'], FILTER_SANITIZE_STRING);
	$passNofilter=$_POST['pass'];
	$pass=filter_var($_POST['pass'], FILTER_SANITIZE_STRING);
	if($pass!=$passNofilter){
		$_SESSION['message']="Password not acceptable  ! Please enter acceptable password !";
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=registration.php">';
		exit();
	}
	
	$p=sha1($pass);
		

	if($e!="" && $p !==""){
		include "DBconnect.php";
		//INSERT INTO projectmember(ProjectCode, pmName, pmDesignation, pmDepartment, pmPhone, pmMobile, pmEmail, pmExperience, pmPasscode, pmAddress, pmPin, created_at, updated_at, author) VALUES 
		
		$sql= "INSERT INTO projectmember(ProjectCode, pmName, pmDesignation, pmDepartment, pmPhone, pmMobile, pmEmail, pmExperience, pmPasscode, pmAddress, pmPin, created_at, updated_at, author) VALUES ('$pcode','$name','$dg','$dpt','$phone','$mobile','$e','$ex','$p','$add','$pin',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,'$e')";
		
		
		$result = mysqli_query($db,$sql);

		if(!$result)
		  {
			//echo "<script>alert('Database error, contact admin  !'); window.history.go(-1);</script>";
			$_SESSION['message']="Database error, contact admin  !";
			//echo '<META HTTP-EQUIV="Refresh" Content="0; URL=AddProjectMember.php">';
			die('Error: ' . mysqli_error($db));
		  }
		else
		{
			$_SESSION['message']="Registration successful !";
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=AddProjectMember.php">';
		}
		mysqli_close($db);
	}else{
		//echo "<script>alert('Invalid Email !'); window.history.go(-1);</script>";
		
		$_SESSION['message']="Invalid Email !";
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=AddProjectMember.php">';
	}
	
?>

</body>
</html>