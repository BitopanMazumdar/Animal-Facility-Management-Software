<?php include "include/sesionlauth.php"; ?>
 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Animal Facility Management Software</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script> 
<script src="Jquery/jquery-3.js"></script> 
<!-- <script type="text/javascript" src="Jquery/jquery-3.3.1.js"></script> -->
<link rel="stylesheet" href="CSS/styles.css">

<script> 
    $(function(){
		$("#header1").load("include/header1.php");		
		$("#menu").load("include/pimenu.php");
			
		$("#footer1").load("include/footer.php"); 
    });
    </script> 

</head>
<body >
<!-- Script start-->

<script type="text/javascript">

$(document).ready(function(){
		inumber=$("#inum").val();
		var xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = function() {
		  if (this.readyState == 4 && this.status == 200) {
			document.getElementById("response").innerHTML = this.responseText;
			$("#slideform").show("slow");
		  }
		};
		
		xmlhttp.open("GET", "IndentResponseByAll.php?inumber="+inumber, true);
		xmlhttp.send();
});

</script>
<!-- Script end-->
<table class="outertable"> <!-- table 1,outer table start -->
	<tr class="header" id="header1"> <!-- Row 1, start -->
	<!-- table 2, Header table start -->
	<!-- table 2, Header table End -->
	</tr> <!-- Row 1, end -->
	<tr> <!-- Row 2, start -->
		<td class="menutd" >
			<table class="menu" width="100%" border="0" cellspacing="0" cellpadding="3"> <!-- table 3,Table for menu start -->
				<tr> <!-- Row, Menu and welocome msg start-->
					<!-- left menu <td width="18%" rowspan="2" align="left" valign="top">

					<table id="menu" bgcolor="#822884"  width="100%" border="0" cellspacing="3" cellpadding="5">
				   
					</table></td> -->
					<td id="menu" height="25" align="right"></td> <!-- td, Menu and welocome msg -->
				</tr> <!-- Row, Menu and welocome msg end-->
			</table> <!-- table 3,Table for menu end -->
		</td>
	</tr>
	
		
	<tr  > <!-- Row, form start 2 //////////////////// -->
		<td ><input type="hidden" name="inum" id="inum" value="<?php echo $_GET['inumber'];?>">
			<div class="slideform" style="display:none" id="slideform">
				<table class="formtemp"  id="response" width="80%" border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#666666">
				</table>		
				
			</div>
			
		</td>
	</tr> <!-- Row, form end 2 ////////////////////-->
	
	
	<tr > <!-- Row, space start-->
		<td > <!-- Td, form start-->
			<table class="space"> <!-- Table, space start-->		
				<tr >
					<td >
						&nbsp; 
					</td>
				</tr>
			</table> <!-- Table, space end-->
		</td>
	</tr> <!-- Row, space end-->
	
	<tr > <!-- Row, space start-->
		<td > <!-- Td, form start-->
			<table class="space"> <!-- Table, space start-->		
				<tr >
					<td >
						&nbsp; 
					</td>
				</tr>
			</table> <!-- Table, space end-->
		</td>
	</tr> <!-- Row, space end-->
	<tr class="footer" id="footer1"> <!-- Row, footer start-->
			
	</tr> <!-- Row, footer end-->
</table> <!-- Outer table end-->

</body>
</html>