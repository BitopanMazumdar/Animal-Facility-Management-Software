<?php include "include/sesionlauth.php"; ?>
<?php
 
	$spstrain= filter_var($_GET['aid'], FILTER_SANITIZE_STRING);
	$prcode= filter_var($_GET['pid'], FILTER_SANITIZE_STRING);
	$gender= filter_var($_GET['gen'], FILTER_SANITIZE_STRING);
	$val= filter_var($_GET['val'], FILTER_SANITIZE_STRING);
		
	$value=-2;	
	include "DBconnect.php" ;
	/*if($gender!="Any"){
		$result = mysqli_query($db,"SELECT NoAnimal AS noa FROM projectanimal WHERE ProjectCode='$prcode' AND SpStrain='$spstrain' AND Gender='$gender'");
	}else{
		$result = mysqli_query($db,"SELECT SUM(NoAnimal) AS noa FROM projectanimal WHERE ProjectCode='$prcode' AND SpStrain='$spstrain'");
	}*/
	$resultYear = mysqli_query($db,"SELECT FromDate FROM projects WHERE ProjectCode='$prcode'");
	if(!$resultYear){
		$value=-2; 
		die();
	}else{
		if($passYear=mysqli_fetch_array($resultYear,MYSQLI_ASSOC)){
			$runningYear=0;	
			$fromdate = strtotime($passYear['FromDate']);
					
			$today = strtotime(date("Y-m-d"));
			
			//$now=date_diff($fromdate,$fromdate);
			
			$now=$today - $fromdate;
			
			$runningYear=intval(($now/(60 * 60 * 24))/365);
			
			//$runningYear= intval($runningYear/365);
			
			if($now%365 !=0){
				$runningYear=$runningYear+1;
				//echo $runningYear;
			}
		}
	}
	$sql="SELECT SUM(NoAnimal) AS noa FROM projectanimal WHERE ProjectCode='$prcode' AND SpStrain='$spstrain' AND Gender='$gender' AND IssueYear='$runningYear' ORDER BY EntryNumber DESC";
	//echo $sql;
	$result = mysqli_query($db,$sql);
	
	/*
	$result = mysqli_query($db,"SELECT SUM(NoAnimal) AS noa FROM projectanimal WHERE ProjectCode='$prcode' AND SpStrain='$spstrain' AND Gender='$gender' ORDER BY EntryNumber DESC"); */
	
	if(!$result){
		$value=-2; 
		die();
	}else{
		if($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
				
			if($val <= $pass['noa']){
				 $value=-1; 
			}else{
				$value=$pass['noa']; 
			}		
		}
	}
		
	echo $value;
	
	mysqli_close($db);
		
?>