<?php include "include/sesionlauth.php"; ?>
 
<?php 

$disnumber= htmlspecialchars($_POST['disnumber']);

if($disnumber!=""){
include"DBconnect.php";
	//experimentationform(ExperimentationNumber, Projectcode, Title, ExperimentBy, ExperimentDate, ExpGroup, Route, SampleCollection, SCInterval) 
	$result = mysqli_query($db,"SELECT DISTINCT ExperimentationNumber, Projectcode, Title, ExperimentBy, ExperimentDate, ExpGroup, Route, SampleCollection, SCInterval,SCvalue,SIvalue
	FROM experimentationform WHERE ExperimentationNumber ='$disnumber'");
	while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
				
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta class="form-control" name="viewport" content="width=device-width, initial-scale=1">
 
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  <link rel="stylesheet" href="css/custom.css">
  
</head>
<body style="background-color:#F8F9FA">
<nav >
 <div class="container-fluid">
	<?php 
	include"include/headerboot.php"; 
	?>
  </div>
  <div class="container-fluid">
	<?php 
	include"include/MenuPi.php"; 
	?>		
  </div>  
</nav>
<!-- Script start-->
<script type="text/javascript">     
    
$(document).ready(function(){
	   
	$.get("sessionProjectByPi.php", function(data, status){
	$("#pcode").html(data);
	
	});	
});

</script>

<script type="text/javascript">
$(document).ready(function(){
	$("#main").show("slow");	  
 
});

function CheckAvail(val,no)
{
		
	check=1;
	z=$("#row_no").val();
	
	for(x=1;x<=z;x++)
	{
	//alert(x);
	if(x!=no)
	{
		if($("#strain"+x).val()==$("#strain"+no).val())
		{
			//alert("strain same");
			if($("#sex"+x).val()==$("#sex"+no).val())
			{
				$("#strain"+no).val("");
				$("#sex"+no).val("");
				$("#no_of_an"+no).val("");
				check=0;
				alert("Species/Strain allready selected");
			}
			else
			{
				//alert("gender different");
				if($("#no_of_an"+x).val()=="")
				nav=0;
				else
				nav=$("#no_of_an"+x).val();
				val=parseInt(val)+parseInt(nav);
				
			}
		}
	}
	//x++;
	}

	
	pid=$("#pcode").val();
	aid=$("#strain"+no).val();
	gen=$("#sex"+no).val();
	if(check==1 && val!="" && pid!=0 && aid!="")
	{
		//$("#avl"+no).html("<img src='images/loading.gif' height='20' width='20' />");
		$.get("AnimalAvailabilty.php",{
			aid:aid,
			pid:pid,
			gen:gen,
			val:val
		},
		  function(data,status){
			 
			if(data==-2){
				 $("#avl"+no).html("");
				  $("#no_of_an"+no).val("");
				alert("Error, contact admin!");
			}else if(data==-1)
			  {
				 $("#avl"+no).html("<img src='images/right.jpg' height='10' width='12' />"); //  
			  }
			  else
			  {
				$("#avl"+no).html("");
				  $("#no_of_an"+no).val("");
				  alert("Exeeds approved Species/Strain limit, Approved = "+data);
			  }
			  });

	}
	else
	 $("#avl"+no).html("");
}



function checkGender(val,no)
	{
	 $("#no_of_an"+no).val("");
	 $("#avl"+no).html("");
	 pco=$("#pcode").val();
	 $.get("Genderquery.php",
	  {
		aid:val, pc:pco
	  },
	  function(data,status){
		 //alert(data);
		 $("#sex"+no+"").html(data);
	  
	  }); 
}

function showTitle(val)
{
	window.location="Title_query.php?page=indent_form&proj="+val;
}

function CheckDate(ete)
{
   	projid=$("#pcode").val();
	 
    if(projid!=0)
    {
		$.get("CheckDate.php",{projid:projid,seldate:ete},function(data,status){
		
    if(data!=1)
    {
		alert(data);
		$("#reqdate").val("");
    }
    else
     return true;
    });
    }
    else
    alert("You have not select any Protocol ! Please select Protocol ! ");
    
}
</script>
<script type="text/javascript">
function showOtherRoute(eve){
	
	//alert(eve);
	if(eve=="other"){
		//document.getElementById('otherRoute').style.display = "block";
		$('#otherRoute').show();
   } else{
		$('#otherRoute').hide();
   }
	//$("#route").show();
}
function showOtherSample(eve){ 
	if(eve=="other"){
		//document.getElementById('otherRoute').style.display = "block";
		$('#otherSample').show();
   } else{
		$('#otherSample').hide();
   }
}
function showOtherInterval(eve){ 
	if(eve=="other"){
		//document.getElementById('otherRoute').style.display = "block";
		$('#otherInterval').show();
   } else{
		$('#otherInterval').hide();
   }
}
function getTitle(val){
	$.get("TitleByProject.php", {prcode:val},function(data, status){
	//$("#title").html(data);
	$("#title").val(data);
	});
}
</script>
<script type="text/javascript">

function getSpstrain(val){
	rowno=$("#rowno").val();
	$.get("SpStrainByProject.php", {prcode:val}, function(data, status){
		
		for(i=1; i<=rowno; i++){
			// "<select name=\"strain1\" id=\"strain"+i+"\" onchange=\"checkGender(this.value,1)\"><option value=\"\">Select</option>" + data+"</select>";
            //alert(data);    
			$("#strain"+i).html(data);
		}
    });
}	
</script>

<!-- Validation-->
<script type="text/javascript">
function valid(){
	frm = document.myform;
	no=frm.row_no.value;
	//alert(no);
	 if(frm.pcode.value ==0)
	  {
			alert("Please Select Protocol Code ! ");
			frm.pcode.focus();
			return false;
	  }
	  	   
	  if(frm.recn.value =="")
	  {
			alert("Please Enter Experimentat Done By !");
			frm.recn.focus();
			return false;
	  }
	  
	 
	  for(j=1;j<=no;j++)
		{
					
		  if(document.getElementById("strain"+j).value =="")
		  {
				alert("Please enter species/starin, row no. = "+j);
				document.getElementById("strain"+j).focus();
				return false;
		  }
		  		  
		/* if(document.getElementById("sex" + j).value =="")
		  {
				alert("Please enter Gender of row=!");
				document.getElementById("sex" + j).focus();
				return false;
		  }
		  */
		  if(document.getElementById("no_of_an"+j).value ==0)
		  {
				alert("Please enter No. OF Animals, row no. = "+j);
				document.getElementById("no_of_an"+j).focus();
				return false;
		  }
		   
		 /* if(document.getElementById("age"+j).value =="" )
		  {
				alert("Please enter Weight/Age !");
				document.getElementById("age"+j).focus();
				return false;
		  } */
		}
		
	  if(frm.route.value =="other")
	  {
			if(frm.oRoute.value==""){
				alert("Please Enter Route of Administration !");
				frm.oRoute.focus();
				return false;
			}
	  }
	  if(frm.SampleCollection.value =="other")
	  {
		  if(frm.osample.value==""){
			alert("Please Select Sample Collection !");
			frm.osample.focus();
			return false;
		  }
	  }
	  if(frm.scval.value==""){
			alert("Please Enter Sample Collection Value !");
			frm.scval.focus();
			return false;
	  }
		if(frm.SampleInterval.value =="other")
	  {
		  if(frm.osample.value==""){
			alert("Please Select Interval of Sample Collection!");
			frm.ointerval.focus();
			return false;
		  }
	  }	
	  if(frm.sival.value==""){
			alert("Please Enter Collection Interval Value !");
			frm.sival.focus();
			return false;
	  }	  
	  if(frm.reqdate.value =="")
	  {
			alert("Please Enter Date!");
			frm.reqdate.focus();
			return false;
	  }
	  var r = confirm("confirm submit!");
	  if (r == true) {
		return true;
	  } else {
		frm.recn.focus();
		return false;
	  }
	  
}
</script>		
<!-- End of validation -->
<!-- Script end-->
		
<div class="container" id="main" style="display:none">
<br>
<!-- submit message -->
	<?php 
		
		if(isset($_SESSION['message'])){
			echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
			unset($_SESSION['message']);
		}
								
	?>
<!-- submit message -->
	
	<form  name="editmyform" autocomplete="off" method="post" action="EditExp_proccess.php" onsubmit="return validate();">
		<div class="form-group">
			<fieldset>
			<legend>Edit experimentation information </legend>
				<table class="table"  border="0"  align="center">
				  <tr>
					<td>Protocol</td>
					<td   colspan="2" ><input class="form-control" name="pcode" id="pcode" readonly type="text" value="<?php echo htmlspecialchars($pass['Projectcode']); ?>" /></td>
				  </tr>
				   <tr>
					<td>Experiment done by</td>
					
					<td  colspan="2" ><input required class="form-control" name="recn" type="text" id="recn" value="<?php echo htmlspecialchars($pass['ExperimentBy']); ?>" /></td>
				  </tr>
				 </table>
			</fieldset>
		</div>
		<div class="form-group">
			<fieldset>
			<legend>Edit animal specification </legend>
				<div class="table-responsive">
					<table class="table anspecification"  border="0" align="center" cellpadding="5" cellspacing="1">
						
								<input type="hidden" id="row_no"  class="form-control" name="row_no" value="1" />
						  <tr  id="row1">
							<th  align="left" > Species / Strain </th>
							<th  align="left" >Gender</th>
							<th align="left" >No of Animals </th>
							<th align="left" >Weight/age</th>
							
						  </tr>
						  
						  
						<?php //query for spstrain  
									 echo "<input type=\"hidden\" id=\"inum\" class=\"form-control\" name=\"inum\" value=\"".$disnumber."\"  />";
									 $prcode=htmlspecialchars($pass['Projectcode']); 
									//experimentationanimal(EntryNo, ExperimentationNumber, SpStrain, Gender, Weight_Age, NoAnimal)	
									$result1 = mysqli_query($db,"SELECT EntryNo, ExperimentationNumber, SpStrain, Gender, Weight_Age, NoAnimal FROM experimentationanimal WHERE ExperimentationNumber='$disnumber' ");
									$j=1;
									
									while($pass1=mysqli_fetch_array($result1,MYSQLI_BOTH)){

									echo"<tr>
											  <td><select required id=\"strain".$j."\" class=\"form-control\" name=\"strain".$j."\" onchange=\"checkGender(this.value,".$j.")\"> 
											  <option value=\"".htmlspecialchars($pass1['SpStrain'])."\" selected=\"selected\">".htmlspecialchars($pass1['SpStrain'])."</option>";
												   $resultsp = mysqli_query($db,"SELECT DISTINCT SpStrain FROM projectanimal WHERE ProjectCode='$prcode'");
															while($passsp=mysqli_fetch_array($resultsp,MYSQLI_ASSOC)){
															
															echo "<option value=\"".htmlspecialchars($passsp['SpStrain'])."\">".$passsp['SpStrain']."</option>";
														}
														mysqli_free_result($resultsp);            
												echo "</select>
												 </td>";
											  
											  echo "<td><select required type=\"text\" id=\"sex".$j."\" class=\"form-control\" name=\"sex".$j."\">
											  <option value=\"".htmlspecialchars($pass1['Gender'])."\" selected=\"selected\">".htmlspecialchars($pass1['Gender'])."</option>
											  </select></td>";
											  
											  echo "<input type=\"hidden\" id=\"rowno\" class=\"form-control\" name=\"rowno\" value=\"".$j."\"  />";		  
											  echo "<input type=\"hidden\" id=\"EntryNo".$j."\" class=\"form-control\" name=\"EntryNo".$j."\" value=\"".htmlspecialchars($pass1['EntryNo'])."\"  />";
											  
											  echo  "<td><input required size=\"10%\" type=\"text\" class=\"form-control\" name=\"no_of_an".$j."\" id=\"no_of_an".$j."\" value=\"".htmlspecialchars($pass1['NoAnimal'])."\" onchange=\"CheckAvail(this.value,".$j.")\" /><span id=\"avl$j\"></span></td>
											  <td><input required type=\"text\" id=\"age".$j."\" class=\"form-control\" name=\"age".$j."\" value=\"".htmlspecialchars($pass1['Weight_Age'])."\"  /></td>
											</tr>"; 
											$j++;
											}
											
						?>
						</table>
					</div>
				</fieldset>
			</div>
			<div class="form-group">
			<fieldset>
			<legend>Edit experimentation details </legend>
				<table class="table">  
					<tr>
					<td  >Group </td>
					
					<td  colspan="2" > <input required id="group" class="form-control" name="group"  type="text" value="<?php echo htmlspecialchars($pass['ExpGroup']); ?>" /> </td>
				  </tr>
				  <tr>
					<td  >Route of Administration </td>
					
					<td  colspan="2" > <select required class="form-control" name="route" id="route" onchange="showOtherRoute(this.value);">
							<option selected="selected" value="<?php echo htmlspecialchars($pass['Route']); ?>"><?php echo htmlspecialchars($pass['Route']); ?></option> 
							<option value="Oral"> Oral </option>  
							<option value="Sub-Lingual"> Sub-Lingual </option>
							<option value="Topical"> Topical </option>                                        
							<option value="Rectal"> Rectal </option>                                        
							<option value="Sub-cutaneous"> Sub-cutaneous </option>  
							<option value="Intravenous"> Intravenous </option>
							<option value="Intramuscular"> Intramuscular </option>                                        
							<option value="Implantation"> Implantation </option>
							<option  value="other" > Other </option>
							</select> 
			 </td> 
			 </tr > 
			 <tr style="display:none" id="otherRoute" placeholder="Enter other Route of Administration">
				<td   >&nbsp; </td>
				
				
				<td  colspan="2" ><input id="oRoute" class="form-control" name="oRoute"  type="text" /> </td>
			<tr>
			 
				  </tr>
				  <tr>
					<td  >Sample Collection </td>
					
					<td  colspan="2" > <select required class="form-control" name="SampleCollection" id="SampleCollection" onchange="showOtherSample(this.value);">
							<option selected="selected" value="<?php echo htmlspecialchars($pass['SampleCollection']); ?>"><?php echo htmlspecialchars($pass['SampleCollection']); ?></option> 
							<option value="Blood"> Blood(ml) </option>  
							<option value="Urine"> Urine(ml) </option>  
							<option value="Saliva"> Saliva(ml) </option>  
							<option value="Feces"> Feces(gm) </option>  
							<option value="Inflammation"> Inflammation(mm) </option>
							<option value="Tumor"> Tumor(mm) </option>  
							<option value="Liver Tissue"> Liver Tissue </option>  
							<option value="Lungs Tissue"> Lungs Tissue </option> 
							<option value="Pancreas Tissue"> Pancreas Tissue </option> 
							<option value="Kidney Tissue"> Kidney Tissue </option> 
							<option value="Lymph Node Tissue"> Lymph Node  Tissue </option> 
							<option value="Brain Tissue"> Brain Tissue </option> 
							<option value="Ovary Tissue"> Ovary Tissue </option> 
							<option value="Uterus Tissue"> Uterus Tissue </option> 
							<option value="Oviduct Tissue"> Oviduct Tissue </option> 
							<option value="Skin Tissue"> Skin Tissue </option> 
							<option value="Adipose Tissue"> Adipose Tissue </option> 
							<option value="Bone Tissue"> Bone Tissue </option> 
							<option  value="other" > Other </option>
							</select> 
						</td>
					</tr>
					
					<tr style="display:none" id="otherSample">
						<td >Other (Sample Type) </td>
						<td  colspan="2" ><input pattern="[a-zA-Z0-9\s]*" id="osample" class="form-control" name="osample" type="text" placeholder="Enter Other sample type" /> </td>
					<tr>
					<tr>
						<td>Value(Sample Type)</td>
						<td><input class="form-control" name="scval" id="scval"  type="text" size="5" value="<?php echo htmlspecialchars($pass['SCvalue']); ?>" placeholder="Enter sample type value"/></td>
					</tr>			
								
				  <tr>
					<td  >Sample Collection Interval </td>
					
					<td  colspan="2" > <select required class="form-control" name="SampleInterval" id="SampleInterval" onchange="showOtherInterval(this.value);">
						<option selected="selected" value="<?php echo htmlspecialchars($pass['SCInterval']); ?>"><?php echo htmlspecialchars($pass['SCInterval']); ?></option> 
						<option value="Zero Time Point"> Zero Time Point </option>  
						<option value="Minutes"> Minutes </option>  
						<option value="Hours"> Hours </option> 
						<option  value="other" > Other </option>
						</select> 
						
						</td>
				  </tr>
				  <tr style="display:none" id="otherInterval">
					
						<td>Other (Sample Interval) </td>
						<td  colspan="2" ><input pattern="[a-zA-Z0-9\s]*" id="ointerval" class="form-control" name="ointerval" type="text" placeholder="Enter Other Sample Collection Interval" /> </td>
					</tr>
					<tr>
						<td >Value (Sample Interval) </td>
						<td>
							<input class="form-control" name="sival" id="sival"  type="text" size="5" value="<?php echo htmlspecialchars($pass['SIvalue']); ?>" placeholder="Enter Sample Interval value" />
						</td>
					</tr>
				  
				  <tr>
					<td  >Experiment Date </td>
					
					<td   > <input required id="reqdate" class="form-control" name="reqdate" type="date" onchange="CheckDate(this.value)" value="<?php echo htmlspecialchars($pass['ExperimentDate']); ?>"/> </td>
				 
				  </tr>
				   
				</table>
			</fieldset>
		</div>
	
<!-- Add Task Button -->
	<div class="form-group">
	
		<div class="col-sm-offset-4 col-sm-6">
			<button type="submit" class="btn btn-danger">
				<i class="fa fa-btn fa-edit"></i> Edit Experimentation
			</button>
			<button type="button" class="btn btn-warning" onclick="window.history.back()">
				<i class="fa fa-btn fa-arrow-left"></i> Back
			</button>
		</div>
	
	</div>
</form>
</div>
		
	<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
	</div>
	
</body>
</html>
<?php 
	}
}
?>
