<?php include "include/sesionlauth.php"; ?>
<?php 
	$prcode= filter_var($_GET['projid'], FILTER_SANITIZE_STRING);
	$sdate= filter_var($_GET['seldate'], FILTER_SANITIZE_STRING);	
	
	if($prcode !="" && $sdate!=""){
		include "DBconnect.php" ;
		
		$result = mysqli_query($db,"SELECT FromDate,ToDate FROM projects WHERE ProjectCode='$prcode' ");
				
		if(!$result){
			$value="Error, contact admin.";
			echo $value;
			die();
		}else{			
			while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
						
				if(($sdate > $pass['ToDate']) || ($sdate < $pass['FromDate'])){
					
						$value="Invalid date, Project duration From: ".$pass['FromDate']." to ".$pass['ToDate']."";
						echo $value;
				}else{
					$value=1;
					echo $value;
				}		
			}
				
			
			mysqli_free_result($result);
		}
		mysqli_close($db);
	}else{
		$value="Error, contact admin.";
		echo $value;
	}	
?>