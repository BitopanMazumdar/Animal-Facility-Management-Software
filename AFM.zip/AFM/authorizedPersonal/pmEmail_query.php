<?php include "include/sesionlauth.php"; ?>
<?php 
	include "DBconnect.php"; 
	
	$mailid=filter_var($_GET['mailid'], FILTER_SANITIZE_STRING);
	$proj=filter_var($_GET['proj'], FILTER_SANITIZE_STRING);	
	$result = mysqli_query($db,"SELECT DISTINCT pmEmail FROM projectmember WHERE pmEmail='$mailid' AND ProjectCode='$proj'");	
	$str = 0;
	if($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
		
		$str = 1;				
	}	
	echo $str;
	mysqli_free_result($result);
	mysqli_close($db);
		
?>