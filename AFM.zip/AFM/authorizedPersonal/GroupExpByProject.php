<?php 
 
  $proj=$_GET['proj'];
  
  include "DBconnect.php";
	//experimentationform(ExperimentationNumber, Projectcode, Title, ExperimentBy, ExperimentDate, ExpGroup, Route, SampleCollection, SCInterval)  
	$result = mysqli_query($db,"SELECT DISTINCT ExpGroup FROM experimentationform WHERE Projectcode = '$proj'");
	
	$str = "<option value=\"\"> select</option>";
	while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
		
		$str = $str . "<option value=\"".$pass['ExpGroup']."\">".$pass['ExpGroup']."</option>";
		
	}
	echo $str;
	mysqli_free_result($result);
	mysqli_close($db);
 
 ?>