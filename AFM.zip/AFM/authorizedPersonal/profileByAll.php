<?php include "include/sesionlauth.php"; ?>
 <?php 
		include "DBconnect.php";
			
		//projectincharge(Piname,PiDesignation,PiDepartment,Piphone,Pimobile,PiEmail,PiExperience, PiPasscode,Role,PiAddress,Pin)
			$query= "SELECT Piname,PiDesignation,PiDepartment,Piphone,Pimobile,PiEmail,PiExperience,PiAddress,Pin FROM projectincharge WHERE PiEmail='$_SESSION[pie]'";
			
			$result = mysqli_query($db,$query);
						
			$i=1; 
			
			$str="<div class=\"panel-heading\">
                        <h4 class=\"text-primary\"><i class=\"fa fa-btn fa-user\"></i> Your information</h4>
                    </div>

                    <div class=\"panel-body\">
                        <table class=\"table table-striped task-table\">
                            <thead>
                                							
								
								<th>Name</th>
								<th>Email ID</th>
								<th>Contact</strong></th>				
								<th>Designation</th>
								<th>Department</th>
								<th>Experience</th>
								<th>Address</th>								
                                <th>&nbsp;</th>
                            </thead>
                            <tbody>";
							while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
								$str=$str."
								<tr>
									
									<td class=\"table-text\"><div>".$pass['Piname']."</div></td>
									<td class=\"table-text\"><div>".$pass['PiEmail']."</div></td>
									
									<td class=\"table-text\"><div>".$pass['Piphone']. "/".$pass['Pimobile']."</div></td>
									<td class=\"table-text\"><div>".$pass['PiDesignation']. "</div></td>
									<td class=\"table-text\"><div>".$pass['PiDepartment']. "</div></td>
									<td class=\"table-text\"><div>".$pass['PiExperience']. "</div></td>
									<td class=\"table-text\"><div>".$pass['PiAddress']."- ".$pass['Pin']."</div></td>
									
									
									<!-- Task Delete Button -->
									<td>
										<form action=\"editProfile.php\" method=\"POST\">
											<input type=\"hidden\" name=\"user\" value=\"".$pass['PiEmail']."\">
											<button type=\"submit\" class=\"btn btn-danger\">
												<i class=\"fa fa-btn fa-edit\"></i>Edit
											</button>
										</form>
									</td> 
								</tr>";
								$i++;
							}
							if ($i== 1){
								$str=$str. "<tr><td colspan=\"9\" class=\"table-text text-danger\"><div>*No Records found</div></td></tr>";
							}
							$str=$str."</tbody>
                        </table>
                    </div>
                </div>";
				
			echo $str;
			
	mysqli_free_result($result);
	mysqli_close($db);
?>