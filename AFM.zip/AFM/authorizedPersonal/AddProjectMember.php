<?php include "include/sesionlauth.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  
</head>
<body style="background-color:#F8F9FA">
	<nav >
		 <div class="container-fluid">
			<?php 
			include"include/headerboot.php"; 
			?>
		  </div>
		  <div class="container-fluid">
			<?php 
			include"include/MenuPi.php"; 
			?>		
		  </div> 
	</nav>
	
<!-- Script start-->

<script type="text/javascript">
function getTitle(val){
	$.get("TitleByProject.php", {prcode:val},function(data, status){
		$("#title").val(data);
	});
}
</script>

<!-- Script end-->
<script type="text/javascript">
$(document).ready(function(){
	$.get("sessionProjectByPi.php", function(data, status){
		$("#pcode").html(data);
	
	});
	$("#displaydiv").slideDown("slow");
});
</script>

<script type="text/javascript">
document.getElementById("email").onchange = function() {checkEmail()};
function checkEmail(){	
	//var mail = document.getElementById('email').value;
	mail=$("#email").val();
	pcode=$("#pcode").val();
	
	if(pcode==""){
		alert("Please select protocol first !");
		$("#email").val("");
	}else{
		$.get("pmEmail_query.php",{mailid:mail,proj:pcode}, function(data, status){
			 if(data==1){
				//$("#emailok").hide();
				 document.getElementById("emailexist").innerHTML = "Email Already exsist!";
				 
				 $("#emailexist").slideDown("slow");
				 $("#email").val("");
			 }else{
				 $("#emailexist").hide();
				 //document.getElementById('emailok').innerHTML="<img src='images/right.jpg' alt='Email ok' height='10' width='32' />";
				 //$("#emailok").slideDown("slow");
			 }
		});
	}
}
</script>
<script language="javascript" type="text/javascript" >
	function valid()
	{
		frm = document.regform;
		
		  if(frm.pcode.value ==0)
		  {
				alert("Please Select Project Code ! ");
				frm.pcode.focus();
				return false;
		  }	
		  if(frm.name.value =="")
		  {
				alert("Please enter the Name ! ");
				frm.name.focus();
				return false;
		  }
		  if(frm.email.value =="")
		  {
				alert("Please enter the Email Id/User Id ! ");
				frm.email.focus();
				return false;
		  }
		  
		/*  var x=frm.value;
		  var atpos=x.indexOf("@");
		  var dotpos=x.lastIndexOf(".");
		  if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length)
		  {
				alert("Not a valid e-mail address");
				return false;
		  }
		  */
		  	  
		   if(frm.pass.value =="")
		  {
				alert("Please enter Password !");
				frm.pass.focus();
				return false;
		  }
		  if(frm.re_pass.value =="")
		  {
				alert("Please Re type Password !");
				frm.re_pass.focus();
				return false;
		  }
		  if(frm.pass.value != frm.re_pass.value)
		  {
				alert("Password Does Not Match !");
				frm.pass.focus();
				return false;
		  }
		  r=confirm("confirm submission!");
		  if(r==true){
			  return true;
		  }else{
			  frm.name.focus;
			  return false;
		  }
		   
	}
</script>
<!--
<script type="text/javascript">
function valid(){
	
	frm = document.cmrform;
	var patt = /[%*+;<=>^]/;
	if(patt.test(frm.remark.value)){
			alert("invalid remark input class="form-control" ! special characters: %*+;<=>^ are not allowed");
			frm.remark.focus();
			return false;
	}
	r=confirm("confirm submission!");
	  if(r==true){
		  return true;
	  }else{
		  frm.date.focus;
		  return false;
	  }
}
</script> -->
	<div>&nbsp;</div>
	<div class="container" id="displaydiv" style="display:none">
       
       
        <!-- submit message -->
					<?php 
						
							if(isset($_SESSION['message'])){
								echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
								unset($_SESSION['message']);
							}
												
					?>
		<!-- submit message -->
		<div class="col-sm-offset-1 col-sm-10">
            <div class="panel panel-primary">
                <div class="panel-heading">
                  Project Member Management
				   <button type="button" class="btn btn-success col-sm-offset-6" onClick="document.location.href='ViewPM.php'">
						<i class="fa fa-btn fa-file"></i> View Project Member
					</button>
                </div>

                <div class="panel-body">
			 <form name="pmform" action="addpm_process.php"  method="POST" class="form-horizontal" onsubmit="return valid();">
			<div class="form-group">
				<label for="pcode" class="col-sm-3 control-label"><span style="color: red">*</span>IAEC/CPCSEA Protocol:</label>
				<div class="col-sm-6">
					<select class="form-control" required name="pcode" onchange="getTitle(this.value);" id="pcode">
					</select>
				</div>
			</div>
			<div class="form-group">
				<label for="title" class="col-sm-3 control-label"><span style="color: red">*</span>Investigation Title:</label>
				<div class="col-sm-6">
					<textarea class="form-control" name="title" readonly  id="title" type="text" placeholder="Enter title" ></textarea> 
				</div>
			</div>
			
			<div class="form-group">
				<label for="name" class="col-sm-3 control-label"><span style="color: red">*</span>Name:</label>
				<div class="col-sm-6">
					<input class="form-control" required style="text-transform: capitalize;" pattern="[A-Za-z\s]*" title="Special characters and digit not allowed" name="name" type="text" id="name" placeholder="Enter name" />
				</div>
			</div>
			
			<div class="form-group">
				<label for="email" class="col-sm-3 control-label"><span style="color: red">*</span>Email ID:</label>
				<div class="col-sm-6">
					<input class="form-control col-sm-6" required name="email" type="email" id="email" onchange="checkEmail()"  placeholder="Enter email id"/> 
				<div class="alert alert-danger col-sm-4 col-sm-offset-9" id="emailexist" style="display:none"> </div>
					<!--
					<p id="emailok" style="display:none"></p>
					<div class="alert alert-success col-sm-1 col-sm-offset-9" id="emailok" style="display:none"> 
					</div>-->
				</div>
				
			</div>
			
			<div class="form-group">
				<label for="phone" class="col-sm-3 control-label">Ext/Phone:</label>

				<div class="col-sm-6">
					<input class="form-control"  type="text" name="phone" pattern="[0-9\/\+\s-]{9,}" type="tel" title="digit + - and / allowed only" id="phone" size="15" placeholder="Enter phone number"/>
				</div>
			</div>
			<div class="form-group">
				<label for="mb" class="col-sm-3 control-label">Mobile:</label>

				<div class="col-sm-6">
					<input class="form-control" pattern="[0-9\+\s-]{9,}" title="digits + - allowed only minimum length:9 " name="mb" type="text" id="mb" size="15" placeholder="Enter mobile number"/>
				</div>
			</div>
			<div class="form-group">
				<label for="dg" class="col-sm-3 control-label">Designation:</label>

				<div class="col-sm-6">
					<input class="form-control" style="text-transform: capitalize;" pattern="[A-Za-z\s]*" title="Special characters and digit not allowed" name="dg" type="text" id="dg" placeholder="Enter designation"/>
				</div>
			</div>
			<div class="form-group">
				<label for="dpt" class="col-sm-3 control-label">Department:</label>

				<div class="col-sm-6">
					<input class="form-control" style="text-transform: capitalize;" pattern="[A-Za-z\s0-9-\/]*" title="Special characters and digit not allowed" name="dpt" type="text" id="dpt" placeholder="Enter department"/>
				</div>
			</div>
			
			<div class="form-group">
				<label for="ex" class="col-sm-3 control-label">Experience:</label>
				<div class="col-sm-6">
					<input class="form-control" style="text-transform: capitalize;" pattern="[A-Za-z0-9\s]*" title="Special characters are not allowed" name="ex" type="text" id="ex" placeholder="Enter experience"/>
				</div>
			</div>
			<div class="form-group">
				<label for="add" class="col-sm-3 control-label">Address:</label>
				<div class="col-sm-6">
					<textarea class="form-control" style="text-transform: capitalize;" name="add" type="text" id="add" rows="4" cols="30" placeholder="Enter address" ></textarea>
				</div>
			</div>
			<div class="form-group">
				<label for="pin" class="col-sm-3 control-label">Pin:</label>
				<div class="col-sm-6">
					<input class="form-control" pattern="[0-9]{6}" title="6 digit pin allowed only" name="pin" type="text" id="pin" placeholder="Enter pin number"  />
				</div>
			</div>
			<div class="form-group">
				<label for="pass" class="col-sm-3 control-label"><span style="color: red">*</span>Password:</label>
				<div class="col-sm-6">
					<input class="form-control" required name="pass" type="password" id="pass" size="18" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" placeholder="Enter password"/>
				</div>
			</div>
			
			<div class="form-group">
				<label for="re_pass" class="col-sm-3 control-label"><span style="color: red">*</span>Confirm Password:</label>
				<div class="col-sm-6">
					<input class="form-control" required name="re_pass" type="password" id="re_pass" size="18" placeholder="Enter same password"/>
				</div>
			</div>
			<!-- Add Task Button -->
			<div class="form-group">
				<div class="col-sm-offset-5 col-sm-6">
					<button type="submit" class="btn btn-primary">
						<i class="fa fa-btn fa-user-plus"></i> 	Add Member
					</button>
				</div>
			</div>
		</form>
    </div></div></div></div>
	<div>&nbsp;</div>
	<div>&nbsp;</div>
	
	<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
	</div>
	
</body>
</html>