<?php include "include/sesionlauth.php"; ?>
 	
<?php 		
	$pcode = filter_var($_GET['proj'], FILTER_SANITIZE_STRING);
	$str="<div class=\"panel-heading\">
				<button type=\"button\" class=\"btn btn-danger\" onclick=\"javascript:printDiv('printdiv')\" ><i class=\"fa fa-btn fa-print\"></i> Print</button>
				<span class=\"text-primary\" >&nbsp;&nbsp;&nbsp;&nbsp;	Animal Request-Reply Information</span>
			</div>

			<div class=\"panel-body  table-responsive\" id=\"printdiv\">
			<table class=\"table table-striped table-hover\">
				<thead >
					<th width=\"5%\" align=\"center\" ><strong>S.No</strong></th>
					<th width=\"19%\" align=\"left\" ><strong>Protocol </strong></th>
					<th width=\"19%\" align=\"left\" ><strong> Incharge </strong></th>
					<th width=\"17%\" align=\"center\" ><strong>Approved Date </strong></th>
					<th width=\"17%\" align=\"center\" ><strong>From </strong></th>
					<th width=\"23%\" align=\"center\" ><strong>To </strong></th>
				</thead>
				<tbody>";
	
	if($pcode!=""){
		include "DBconnect.php";
		$query1= "SELECT DISTINCT ProjectCode, PrincipalInvestigator,ApprovalDate,FromDate, ToDate FROM projects WHERE ProjectCode = '$pcode' ORDER BY FromDate DESC";
		
		$result1 = mysqli_query($db,$query1);
if($result1){
		$i=1;
		
		
			while($pass=mysqli_fetch_array($result1,MYSQLI_ASSOC)){
			
			$str=$str. "<tr bgcolor=\"#FFFFFF\"><td>".$i."</td>";
			$str=$str. "<td >".$pass['ProjectCode']."</td>";
			$str=$str. "<td >" .$pass['PrincipalInvestigator']. "</td>";
			$str=$str. "<td >" .$pass['ApprovalDate']. "</td>";
			$str=$str. "<td >".$pass['FromDate']. "</td>";
			$str=$str. "<td >".$pass['ToDate']."</td></tr>";
		  
			
			 $str=$str."<tr>
				<td colspan=\"6\"><div>
				<table class=\"table\" border=\"1\" style=\"border-color:#666;border-collapse:collapse;width:100%;\" cellpadding=\"10\">
				<thead style=\"background-color:#CAD4EB\">
					<th width=\"30%\">Species / Strain </th>
					<th width=\"15%\" align=\"left\" >Gender</th>
					<th width=\"15%\" align=\"left\" >Weight / Age</th>
					<th width=\"10%\" align=\"center\" >Approved</th>
					<th width=\"10%\" align=\"center\" >Requested No.</th>
					<th width=\"10%\" align=\"center\" >Replied No.</th>
					  
				</thead>
				<tbody>";
			
			
			$pcode= $pass['ProjectCode'];
	//query for approved number		
			
			$query11= "SELECT  SpStrain, Gender, Weight_Age, NoAnimal AS approvedNum FROM projectanimal WHERE ProjectCode='$pcode' ";
			$result11 = mysqli_query($db,$query11);
			$j=1;
			while($pass11=mysqli_fetch_array($result11,MYSQLI_ASSOC)){
					
	//	query ends
				$pspst=$pass11['SpStrain'];
				$pgender=$pass11['Gender'];
				$query2= "SELECT IndentNumber, SUM(NoAnimal) AS AppliedNum FROM indentanimal WHERE ProjectCode='$pcode' AND SpStrain='$pspst' AND Gender='$pgender'";
				$result2 = mysqli_query($db,$query2);
												
				if($pass1=mysqli_fetch_array($result2,MYSQLI_ASSOC)){
					$INum=$pass1['IndentNumber'];
					$issued=0;
					$query111= "SELECT  SUM(NoAnimal) AS issuedNum FROM responseanimal WHERE  IndentNumber='$INum' AND SpStrain='$pspst' AND Gender='$pgender'";
					$result111 = mysqli_query($db,$query111);
							if($pass111=mysqli_fetch_array($result111,MYSQLI_ASSOC)){
								$issued=$pass111['issuedNum'];
								$str=$str. "<tr bgcolor=\"#FFFFFF\">";
								$str=$str. "<td >".$pass11['SpStrain']."</td>";
								$str=$str. "<td >".$pass11['Gender']."</td>";
								$str=$str. "<td >" .$pass11['Weight_Age']."</td>";
								$str=$str. "<td >".$pass11['approvedNum']."</td>";
								$str=$str. "<td >".$pass1['AppliedNum']."</td>";				
								$str=$str. "<td >".$issued."</td>";
																
								$str=$str. "</tr>";
									  
						}
				}
				
			$j++;
			
			}
			if($j== 1){
				$str=$str. "<tr><td colspan="."8"." align="."center"." bgcolor="."red"." >No indents.</td></tr>";
			}		
			$i++;
			$str=$str."</tbody>
				</table>
				</td>
				</tr>";
		}	
		if ($i== 1){
			$str=$str. "<tr><td colspan="."8"." align="."center"." bgcolor="."red"." >No Records found.</td></tr>";
								  
		}
		$str=$str."
				</tbody>
				</table>
			</div>";
		
		echo $str;
		
}else{
	$_SESSION['message']="Error  ! Contact admin !";
	echo '<META HTTP-EQUIV="Refresh" Content="0; URL=ProjectInventories.php">';
}	
		mysqli_close($db);
	}else{
		$_SESSION['message']="Invalid input data  ! Failed to submit  !";
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=ProjectInventories.php">';
	}
		
?>
