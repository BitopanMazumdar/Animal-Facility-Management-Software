<?php include "include/sesionlauth.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  
  
  
</head>
<body style="background-color:#F8F9FA">

<!-- Script start-->
<script type="text/javascript">
$(document).ready(function(){
		$("#displaydiv").show("slow");
});
</script>
<script type="text/javascript">

$(document).ready(function(){
	$.get("sessionProjectByPi.php", function(data, status){
		$("#proj").html(data);
	
	});
		var xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = function() {
		  if (this.readyState == 4 && this.status == 200) {
			document.getElementById("viewdata").innerHTML = this.responseText;
			$("#viewdata").slideDown("slow");
		  }
		};
		
		xmlhttp.open("GET", "UtilizedAnimalByAll.php", true);
		xmlhttp.send();
});

</script>

<script type="text/javascript">
function UtizationByProject()
{ 
	$("#viewdata").hide();
	proj=$('#proj').val();
	
	//window.location='UAByProj.php?page=inventory&type='+type+'&proj='+proj+'';
	var xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = function() {
		  if (this.readyState == 4 && this.status == 200) {
			  //alert(this.responseText);
			document.getElementById("viewdata").innerHTML = this.responseText;
			$("#viewdata").slideDown("slow");
		  }
		};
		
		xmlhttp.open("GET", "UtilizedAnimalByProj.php?proj="+proj+"", true);
		xmlhttp.send();
}

</script>
<script type="text/javascript">
function printDiv(divID) {
	
        //Get the HTML of div
        var divElements = document.getElementById(divID).innerHTML;
        //Get the HTML of whole page
        var oldPage = document.body.innerHTML;
        //Reset the page's HTML with div's HTML only
		var htmlToPrint = '' +
        '<style type="text/css">' +
        'table th, table td {' +
        'border:1px solid #000;' +
        'padding;0.5em;' +
        '}' +
        '</style>';
        document.body.innerHTML = 
          "<html><head><title></title></head><body>" +  htmlToPrint + divElements + "</body>";
        //Print Page
        window.print();
        //Restore orignal HTML
        document.body.innerHTML = oldPage;

    }
</script> 
<!-- Script end-->
<nav >
	<div class="container-fluid">
		<?php 
		include"include/headerboot.php"; 
		?>
	</div>
	<div class="container-fluid">
		<?php 
		include"include/MenuPi.php"; 
		?>
	</div>
	<div class="container-fluid">
	&nbsp;
	</div>
</nav>

	<div class="container" id="displaydiv" style="display:none">
        <div class="col-sm-offset-2 col-sm-8">
            <div class="panel panel-primary">
                <div class="panel-heading">
                   Animal Utilization Records
                </div>

                <div class="panel-body">
                    <!-- Display Validation Errors -->
                    <!--@include('common.errors')-->

                    <!-- New Task Form -->
                    <form action="" name="indentresponseform" method="" class="form-horizontal">
                        
                        <!-- Task Name -->
                        <div class="form-group">
							<label for="pcode" class="col-sm-3 control-label"><span style="color: red">*</span>Protocol:</label>
							<div class="col-sm-6">
								<select class="form-control"  name="proj" id="proj">
									<option value="" selected="selected">Select</option>
								</select>
							</div>
						</div>
											
						<!-- Add Task Button -->
                        <div class="form-group">
                            <div class="col-sm-offset-3 col-sm-6">
                                <button type="button" class="btn btn-primary" onClick="UtizationByProject();">
                                    <i class="fa fa-btn fa-search"></i> Search
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
		</div>
		<div class="col-sm-12">
			<div id="viewdata" class="panel panel-success" style="display:none">
			</div>
		</div>
		
    </div>
	<div>&nbsp;</div><div>&nbsp;</div>
	<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
	</div>
</body>
</html> 
	
	
	
	
	 
	