<?php include "include/sesionlauth.php"; ?>
<?php 
	$spstrain= filter_var($_GET['aid'], FILTER_SANITIZE_STRING);
	$prcode= filter_var($_GET['pid'], FILTER_SANITIZE_STRING);
	$gender= filter_var($_GET['gen'], FILTER_SANITIZE_STRING);
	$val= filter_var($_GET['val'], FILTER_SANITIZE_STRING);
	$value=-2;	
	include "DBconnect.php" ;
	/*if($gender!="Any"){
		$result = mysqli_query($db,"SELECT NoAnimal AS noa FROM projectanimal WHERE ProjectCode='$prcode' AND SpStrain='$spstrain' AND Gender='$gender'");
	}else{
		$result = mysqli_query($db,"SELECT SUM(NoAnimal) AS noa FROM projectanimal WHERE ProjectCode='$prcode' AND SpStrain='$spstrain'");
	}*/
	$result = mysqli_query($db,"SELECT NoAnimal AS noa FROM projectanimal WHERE ProjectCode='$prcode' AND SpStrain='$spstrain' AND Gender='$gender'");
	if(!$result){
		$value=-2; 
		die();
	}else{
		if($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
				
			if($val <= $pass['noa']){
				 $value=-1; 
			}else{
				$value=$pass['noa']; 
			}		
		}
	}
		
	echo $value;
	
	mysqli_close($db);
		
?>