<?php include "include/sesionlauth.php"; ?>

<?php 
	$mcode=filter_var($_POST['mcode'], FILTER_SANITIZE_STRING);
	$species=filter_var($_POST['species'], FILTER_SANITIZE_STRING);
	$strain=filter_var($_POST['strain'], FILTER_SANITIZE_STRING);
	$stock=filter_var($_POST['stock'], FILTER_SANITIZE_STRING);
	$qm=filter_var($_POST['qm'], FILTER_SANITIZE_STRING);
	$qf=filter_var($_POST['qf'], FILTER_SANITIZE_STRING);
	$mdate=filter_var($_POST['mdate'], FILTER_SANITIZE_STRING);
if($mcode!="" && $species!="" && $mdate!=""){
	include "DBconnect.php" ;

	$sql="INSERT INTO Mortality(Mortalitycode,Species,strain,StockType,MALE,Female,MortalityDate) values ('$mcode', '$species', '$strain', '$stock', '$qm', '$qf', '$mdate')";

	$Result = mysqli_query($db, $sql);


	if(!$Result)
	  {
		 $_SESSION['message']="Error ! Contact admin  !";
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=Mortality.php">';
		die('Error: ' . mysqli_error($db));
	  }
	else
	{
		$_SESSION['message']="Successfully added mortality data  !";
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=Mortality.php">';
	}
	mysqli_close($db);
}else{
	$_SESSION['message']="Invalid Input  ! Please enter data properly  !";
	echo '<META HTTP-EQUIV="Refresh" Content="0; URL=Mortality.php">';
}

?>
