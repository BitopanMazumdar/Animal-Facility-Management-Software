<?php include "include/sesionlauth.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  <link rel="stylesheet" href="css/custom.css">
  
</head>
<body style="background-color:#F8F9FA">
<nav >
 <div class="container-fluid">
	<?php 
	include"include/headerboot.php"; 
	?>
  </div>
  <div class="container-fluid">
	<?php 
	include"include/MenuAi.php"; 
	?>		
  </div>
  <div class="container-fluid">
	<?php 
	include"include/moniRegMenu.php"; 
	?>		
  </div>
 
</nav>
<!-- Script start-->
<script type="text/javascript">
$(document).ready(function(){
	$("#main").show("slow");
	
 $.get("room_query.php", function(data, status){
		
    $("#room").html(data);
    });
});
</script>

<!-- Validation-->


<script type="text/javascript">
function valid(){
	frm = document.myform;
	
	  
	  
	   if(frm.room.value =="")
	  {
			alert("Please select Room ! ");
			frm.room.focus();
			return false;
	  }
	  
	  if(frm.edate.value =="")
	  {
			alert("Please select Entry date ! ");
			frm.edate.focus();
			return false;
	  }
	   if(frm.time.value =="" )
	  {
			alert("Please enter Time !");
			frm.time.focus();
			return false;
	  }
	  if(frm.emin.value =="")
	  {
			alert("Please select Minimum Temperature !");
			frm.emin.focus();
			return false;
	  }
	  if(frm.emax.value =="")
	  {
			alert("Please select Maximum Temperature !");
			frm.emax.focus();
			return false;
	  }
	   
	   if(frm.havg.value =="")
	  {
			alert("Please enter Humdity!");
			frm.havg.focus();
			return false;
	  }
	
	  var r = confirm("confirm submit!");
	  if (r == true) {
		return true;
	  } else {
		frm.room.focus();
		return false;
	  }
	  
}

</script>		
<!-- End of validation -->

<!-- Script end-->
 
<div class="container" id="main" style="display:none">
<br>
<!-- submit message -->
	<?php 
		
		if(isset($_SESSION['message'])){
			echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
			unset($_SESSION['message']);
		}
								
	?>
<!-- submit message -->
<form  autocomplete="off" action="Monitoring_process.php" class="form-horizontal" name="myform" method="post" onsubmit="return valid();">
<br>
	<button type="button" class="btn btn-danger col-sm-offset-6" onClick="document.location.href='MonitoringReports.php'"><i class="fa fa-btn fa-plus"></i> View Room Parameter
					</button>
	<div class="form-group" >
	<fieldset>
		<legend>Room Parameter Management</legend>
		<label class="control-label"  for="mcode">Room No:<span id="red">*</span>:</label>
			<select required class="form-control" name="room" id="room" >
						<option value="">Select</option>
					</select>
		<label class="control-label" for="mdate">Date:<span id="red">*</span>:</label>
			<input required class="form-control" name="edate" type="date" id="edate" />  
		<label class="control-label" for="species">Time:<span id="red">*</span>:</label>
			<select required class="form-control" name="time" id="time">
					  <option value="">Select</option>
							  <option value="10:00">10:00</option>
							<option value="16:00">16:00</option>
							  </select>
		
	</fieldset>
	</div>
	<div class="form-group" >
	<fieldset>
		<legend>Temperature and humidity</legend>		
		<label class="control-label" for="stock">Min Temperature  </strong> (<sup>0</sup>C)<span id="red">*</span>:</label>
			 <input required class="form-control" name="emin" type="number" min="-20" max="90" id="emin"  />
			<label class="control-label" for="stock">Max Temperature </strong> (<sup>0</sup>C)<span id="red">*</span>:</label>
			<input required class="form-control" name="emax" type="number" id="emax"   />
			<label class="control-label" for="stock">Humdity </strong>(Avg. %)<span id="red">*</span>:</label>
			<input required class="form-control" name="havg" type="number" id="havg"  />
	</fieldset>
	</div>
	<div class="form-group" >
	<fieldset>
		<legend>Other parameter</legend>
		<label class="control-label" for="stock">Light Intensity</strong>(Lux)<span id="red">*</span>:</label>
			<input class="form-control" name="lintensity" type="number" id="lintensity"  />
		<label class="control-label" for="stock">Air velocity</strong>(ACH)<span id="red">*</span>:</label>
			<input class="form-control" name="av" type="number" id="av"   /> 
		<label class="control-label" for="stock">Sound</strong>(Decibel)<span id="red">*</span>:</label>
			<input class="form-control" name="sound" type="number" id="sound"    />
			
			
	</fieldset>
	</div>
	
	<!-- Add Task Button -->
	<div class="form-group">
	
		<div class="col-sm-offset-4 col-sm-6">
			<button type="submit" class="btn btn-danger">
				<i class="fa fa-btn fa-plus"></i> submit
			</button>
			<button type="button" class="btn btn-warning" onclick="window.history.back()">
				<i class="fa fa-btn fa-arrow-left"></i> Back
			</button>
		</div>
	
	</div>
</form>
</div>
		
	<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
	</div>
	
</body>
</html>
