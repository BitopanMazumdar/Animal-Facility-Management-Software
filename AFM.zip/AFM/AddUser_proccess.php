<?php include "include/sesionlauth.php"; ?>
 
<?php 
	$type=$_POST['type'];
	$name=$_POST['name'];
	$e=$_POST['email'];
	$phone=$_POST['phone'];
	$mobile=$_POST['mb'];
	$dg=$_POST['dg'];
	$dpt=$_POST['dpt'];
	$ex=$_POST['ex'];
	$add=$_POST['add']; 
	$pin=$_POST['pin'];
	$passNofilter=$_POST['pass'];
	$pass=$_POST['pass'];
	if($pass!=$passNofilter){
		$_SESSION['message']="Password not acceptable  ! Please enter acceptable password !";
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=registration.php">';
		exit();
	}
	$p=sha1($pass);
	/*
	if(isset($_SESSION['pie'])){
	  $pie=$_SESSION['pie'];
	  
	}else{
		header("Location: index.php", true, 301);
		exit();
	} */
	//first registration

	if($e!="" && $p !==""){
		include "DBconnect.php";

		$sql= "INSERT INTO projectincharge(Piname,PiDesignation,PiDepartment,Piphone,Pimobile,PiEmail,PiExperience, PiPasscode,Role,PiAddress,Pin) values ('$name','$dg','$dpt','$phone','$mobile','$e','$ex','$p','$type','$add','$pin')";

		$result = mysqli_query($db,$sql);


		if(!$result)
		  {
			//echo "<script>alert('Database error, contact admin  !'); window.history.go(-1);</script>";
			$_SESSION['message']="Database error, contact admin  !";
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=AddUser.php">';
			die('Error: ' . mysqli_error($db));
		  }
		else
		{
			$_SESSION['message']="successful added user  !";
			//echo '<META HTTP-EQUIV="Refresh" Content="0; URL=index.php">';
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=AddUser.php">';
		}
		mysqli_close($db);
	}else{
		//echo "<script>alert('Invalid Email !'); window.history.go(-1);</script>";
		
		$_SESSION['message']="Invalid Email !";
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=AddUser.php">';
	}
	
?>

</body>
</html>