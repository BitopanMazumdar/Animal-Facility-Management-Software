<?php include "include/sesionlauth.php"; ?>
 
<?php 
	$oldst=filter_var($_GET['oldst'], FILTER_SANITIZE_STRING);
	$newst=filter_var($_GET['newst'], FILTER_SANITIZE_STRING);
	$newst=trim($newst);
	$str="";
	if($newst != ""){
		include "Dbconnect.php";
		$sqlck="SELECT Species, strain FROM animals WHERE strain= '$newst'";
		$resultck = mysqli_query($db, $sqlck);
		if(!$resultck){
			 $_SESSION['message']="Fail to add  ! contact admin";
			echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=AddStrain.php?species=".str_replace (' ', '%20',$species)."\">";
			die('Error: ' . mysqli_error($db));
		}else{
			if($passck = mysqli_fetch_array($resultck,MYSQLI_ASSOC)){
				$sp=$passck['Species'];
				//$_SESSION['message']="Not Added, Strain:  $newst of species: $sp already exist ! ";
				echo "Not Added, Strain:  $newst of species: $sp already exist ! ";
			}else{
		
				mysqli_query($db,"UPDATE animals SET strain='$newst' WHERE strain='$oldst'" );
				$result = mysqli_affected_rows($db);
				if($result >=0){
					//$str="Strain: ".$oldst." is Successfully edited to: ".$newst;
					mysqli_query($db,"UPDATE census SET strain='$newst' WHERE strain='$oldst'" );
					$result = mysqli_affected_rows($db);
					if($result >=0){
					$str="Strain: ".$oldst." is Successfully edited to: ".$newst;
					}else{
						$str="Failed to edit Strain: ".$oldst;
					}
					
				}else{
					$str="Failed to edit Strain: ".$oldst;
				}
				echo $str;
				//mysqli_free_result($result);
			}
		}
		mysqli_close($db);
	}else{
		echo"You have not enter new strain name !";
	}
		
	?>
	
		
	
		
		
		
	