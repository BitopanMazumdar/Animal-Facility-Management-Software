<?php include "include/sesionlauth.php"; ?>
 <?php 


$cuemail=filter_var($_POST['cemail'], FILTER_SANITIZE_STRING);
$type=filter_var($_POST['type'], FILTER_SANITIZE_STRING);
	$name=filter_var($_POST['name'], FILTER_SANITIZE_STRING);
	$e=filter_var($_POST['email'], FILTER_SANITIZE_STRING);
	$phone=filter_var($_POST['phone'], FILTER_SANITIZE_STRING);
	$mobile=filter_var($_POST['mb'], FILTER_SANITIZE_STRING);
	$add=filter_var($_POST['add'], FILTER_SANITIZE_STRING); 
	$pin=filter_var($_POST['pin'], FILTER_SANITIZE_STRING);

if($e !=""){
	include "DBconnect.php";
	////cpcseanominee(Ctype, CName, CEmail, CPhone, CMobile, CAddress, Cpin)
	$query="UPDATE cpcseanominee SET Ctype='$type', CName='$name', CEmail='$e' , CPhone='$phone', CMobile='$mobile', CAddress='$add', Cpin='$pin'  WHERE CEmail= '$cuemail'" ;
	mysqli_query($db,$query);
		$result = mysqli_affected_rows($db);
		
		if($result >= 0){ 
			$_SESSION['message']="User: ".$cuemail." is Successfully edited ";
			echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=ViewCM.php\">";
						
		}else{
			$_SESSION['message']="Could not update data: contact admin";
			echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=ViewCM.php\">";
			die();
		}
						
		mysqli_close($db);
	
}else{
	$_SESSION['message']="Failed to Update User: You have not select any option !";
	echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=ViewCM.php\">";
}
?>