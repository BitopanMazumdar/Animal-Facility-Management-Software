<?php include "include/sesionlauth.php"; ?>
<?php 

$sdate=filter_var($_POST['sdate'], FILTER_SANITIZE_STRING);
$room=filter_var($_POST['room'], FILTER_SANITIZE_STRING);
$species=filter_var($_POST['species'], FILTER_SANITIZE_STRING);
$strain=filter_var($_POST['strain'], FILTER_SANITIZE_STRING);
$sex=filter_var($_POST['sex'], FILTER_SANITIZE_STRING);
$ano=filter_var($_POST['ano'], FILTER_SANITIZE_STRING);
$sdbye=filter_var($_POST['sdby'], FILTER_SANITIZE_STRING);

if($room!="" && $sdate!=""){
	include "DBconnect.php" ;

	$sql="INSERT INTO microbialsampling(MCollectionDate,RoomNo,Species,strain,Gender,AnimalNo,MCollectedBy) values ('$sdate', '$room', '$species', '$strain', '$sex', '$ano', '$sdbye')";

	$Result = mysqli_query($db, $sql);

	if(!$Result)
	  {
		$_SESSION['message']="Error, Contact admin  !";
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=MicrobialSampling.php">';
		die('Error: ' . mysqli_error($db));
	  }
	else
	{
		$_SESSION['message']="Successfully saved  !";
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=MicrobialSampling.php">';
	}
	mysqli_close($db);
}else{
	$_SESSION['message']="Error, Invalid input  !";
	echo '<META HTTP-EQUIV="Refresh" Content="0; URL=MicrobialSampling.php">';
}
?>
