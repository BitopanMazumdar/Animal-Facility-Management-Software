<?php include "include/sesionlauth.php"; ?>
 
<?php 
	$prcode= $_GET['prcode'];
	//$prcode="project3";	
	$str ="";
	include "DBconnect.php" ;
	$sql="SELECT DISTINCT Species FROM animals WHERE (strain IN (SELECT DISTINCT SpStrain FROM projectanimal WHERE ProjectCode='$prcode')) OR (Species IN (SELECT DISTINCT SpStrain FROM projectanimal WHERE ProjectCode='$prcode')) ";
	$result = mysqli_query($db,$sql);
	
	
    $str =" <option value=\"\" >Select</option>";
	                                
	while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
		
		$str = $str . "<option value=\"".$pass['Species']."\">".$pass['Species']."</option>";
		
	}
		
	echo $str;
	mysqli_free_result($result);
	mysqli_close($db);
		
?>			
				
