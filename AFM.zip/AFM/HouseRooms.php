<?php include "include/sesionlauth.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  <link rel="stylesheet" href="css/custom.css">
  
</head>
<body style="background-color:#F8F9FA">
<nav >
 <div class="container-fluid">
	<?php 
	include"include/headerboot.php"; 
	?>
  </div>
  <div class="container-fluid">
	<?php 
	include"include/MenuAi.php"; 
	?>		
  </div> 
</nav>
<!-- Script start-->
<script type="text/javascript">
$(document).ready(function(){
		$("#displaydiv").slideDown("slow");
});
</script>

<script type="text/javascript">

$(document).ready(function(){
	
		var xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = function() {
		  if (this.readyState == 4 && this.status == 200) {
			document.getElementById("viewdata").innerHTML = this.responseText;
			$("#viewdata").slideDown("slow");
		  }
		};
		
		xmlhttp.open("GET", "RoomByAll.php", true);
		xmlhttp.send();
	
});		
</script>
<script type="text/javascript">
function editRoom(i){
				 
		$("#editrm"+i).slideDown("slow"); 
		
}

function NewRoomName(i){ 
	 newrm= $("#newrname"+i).val();
	 oldrm=$("#oldname"+i).val();
	if(newrm == ""){
		alert("Please Enter room name");
		$("#newrname"+i).focus();
	}else{
		var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() {
			  if (this.readyState == 4 && this.status == 200) {
				//document.getElementById("tdata").innerHTML = this.responseText;
				//alert(this.responseText);
				location.reload(true);
			  }
			};
			
			xmlhttp.open("GET", "EditRoom.php?newrm="+newrm+"&oldrm="+oldrm, true);
			xmlhttp.send();
	}
}

function ValidateForm()
{
	frm = document.form1;
	
	  if(frm.rname.value =="")
	  {
			alert("Please select Room Name ! ");
			frm.rname.focus();
			return false;
	  }
  
  var r = confirm("confirm submit!");
  if (r == true) {
    return true;
  } else {
	frm.rname.focus();
    return false
  }
}
</script>
<!-- Script end-->
<!-- body-->
<div class="container" id="displaydiv" >
<div class="col-sm-12">&nbsp;</div>
	<div class="col-sm-offset-2 col-sm-8">
		<div class="panel panel-default">
		
			<div class="panel-heading">
				Room Management
			</div>

			<div class="panel-body">
				
				<!-- New Task Form -->
				<form id="form1" name="form1" method="post" action="HouseRooms_proccessing.php" onsubmit="return ValidateForm();" class="form-horizontal">
					
					<!-- Task Name -->
					<div class="form-group">
						<label for="rname" class="col-sm-3 control-label"><span style="color: red">*</span>Room Name:</label>
						<div class="col-sm-6">
							<input class="form-control" name="rname" type="text" id="rname"/>
						</div>
						
					</div>
					
					<!-- Add Task Button -->
					<div class="form-group">
						<div class="col-sm-offset-3 col-sm-6">
							<button type="submit" class="btn btn-default">
								<i class="fa fa-btn fa-plus"></i> Add Room
							</button>
						</div>
					</div>
				</form>
			</div>
		</div>
		
		
	</div>
	<div class="col-sm-offset-1 col-sm-10">
		<!-- submit message -->
			<?php 
				
					if(isset($_SESSION['message'])){
						echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
						unset($_SESSION['message']);
					}						
			?>
		<!-- submit message -->
			<div id="viewdata" class="panel panel-default" style="display:none">
			
			</div>
		
	</div>
</div>
<div class="footer" >
		<?php 
			include"include/footerboot.php"; 
		?>
</div>			
</body>
</html>
