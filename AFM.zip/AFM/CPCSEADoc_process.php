<?php include "include/sesionlauth.php"; ?>
<?php 

$type=filter_var($_POST['type'], FILTER_SANITIZE_STRING);
$dtitle=filter_var($_POST['dtitle'], FILTER_SANITIZE_STRING);
$rdate=filter_var($_POST['rdate'], FILTER_SANITIZE_STRING);
//$dfile=$_POST['dfile']; 

/* File upload */
$targetDir = "uploads/";
$fileName = basename($_FILES["dfile"]["name"]);

$targetFilePath = $targetDir . $fileName;
/* echo $fileName;
echo $targetDir ;
echo $targetFilePath;
*/
$statusMsg ="";

$fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);

if($fileName!=""){
	include "DBconnect.php" ;
	   // Allow certain file formats
	   
    $allowTypes = array('jpg','png','jpeg','gif','pdf','docx');
    if(in_array($fileType, $allowTypes)){
        // Upload file to server
        if(move_uploaded_file($_FILES["dfile"]["tmp_name"], $targetFilePath)){
            
			$sql="INSERT INTO documents (DocumentType,DocumentTitle,ReferenceDate,MainDocument ) values ('$type', '$dtitle', '$rdate', '$fileName')";

			$Result = mysqli_query($db, $sql);													
			if(!$Result)
			  {
				$_SESSION['message']="Error ! Contact admin  !";
				echo '<META HTTP-EQUIV="Refresh" Content="0; URL=CPCSEADoc.php">';
				die('Error: ' . mysqli_error($db));
			  }
			else
			{
				//$statusMsg = "The file ".$fileName. " has been uploaded successfully.";	
				$_SESSION['message']="The file ".$fileName. " has been uploaded successfully.";
								
			}
			mysqli_close($db);
			
			/* Insert image file name into database
            $insert = $db->query("INSERT into images (file_name, uploaded_on) VALUES ('".$fileName."', NOW())");
            if($insert){
                $statusMsg = "The file ".$fileName. " has been uploaded successfully.";
            }
			else{
                $statusMsg = "File upload failed, please try again.";
            } */
        }else{
           // $statusMsg = "Sorry, there was an error uploading your file.";
			$_SESSION['message']="Sorry, there was an error uploading your file. Something wrong with the file";
        }
    }else{
        //$statusMsg = 'Sorry, only JPG, JPEG, PNG, GIF, & PDF files are allowed to upload.';
		$_SESSION['message']="Sorry, only JPG, JPEG, PNG, GIF, & PDF files are allowed to upload.";
    }
}else{
    //$statusMsg = 'Please select a file to upload.';
	$_SESSION['message']="Please select a file to upload.";
	
}
echo '<META HTTP-EQUIV="Refresh" Content="0; URL=CPCSEADoc.php">';

?>
