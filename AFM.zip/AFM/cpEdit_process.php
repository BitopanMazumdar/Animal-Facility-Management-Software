<?php include "include/sesionlauth.php"; ?>
 <?php 
 $cpold=filter_var($_POST['cpold'], FILTER_SANITIZE_STRING);
$cname = filter_var($_POST['cname'], FILTER_SANITIZE_STRING);
$cdesignation = filter_var($_POST['cdesignation'], FILTER_SANITIZE_STRING);
$cmobile1 = filter_var($_POST['cmobile1'], FILTER_SANITIZE_STRING);
$cmobile2 = filter_var($_POST['cmobile2'], FILTER_SANITIZE_STRING);
$cphone1 = filter_var($_POST['cphone1'], FILTER_SANITIZE_STRING);
$cphone2 = filter_var($_POST['cphone2'], FILTER_SANITIZE_STRING);
$cemail1 = filter_var($_POST['cemail1'], FILTER_SANITIZE_STRING);
$cemail2 = filter_var($_POST['cemail2'], FILTER_SANITIZE_STRING);
$caddress = filter_var($_POST['caddress'], FILTER_SANITIZE_STRING);

//contactperson(cpId, clientID, cpName, cpDesignation, mobile1, mobile2, phone1, phone2, email1, email2, adderss)

if($cpold!=""){
	include "DBconnect.php";
	
	$query="UPDATE contactperson SET cpName='$cname', cpDesignation='$cdesignation', mobile1='$cmobile1', mobile2='$cmobile2', phone1='$cphone1', phone2='$cphone2', email1='$cemail1', email2='$cemail2', adderss='$caddress', author='$pie' WHERE cpId='$cpold'" ;
	mysqli_query($db,$query);
		$result = mysqli_affected_rows($db);
		if($result >=0){
			$_SESSION['message']="Successfully edited !";
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=viewClient.php">';			
		}else{
			$_SESSION['message']="Error  ! Contact admin !";
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=viewClient.php">';
		}
		mysqli_close($db);
	
}else{
	$_SESSION['message']="Invalid data !";
	echo '<META HTTP-EQUIV="Refresh" Content="0; URL=viewClient.php">';
}
?>