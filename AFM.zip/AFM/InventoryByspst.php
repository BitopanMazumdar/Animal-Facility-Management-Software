<?php include "include/sesionlauth.php"; ?>
 <?php 
	$species = filter_var($_GET['vspecies'], FILTER_SANITIZE_STRING);	
	$strain = filter_var($_GET['vstrain'], FILTER_SANITIZE_STRING);
	
		$str="<div class=\"panel-heading\">
				<button type=\"button\" class=\"btn btn-danger\" onclick=\"javascript:printDiv()\" ><i class=\"fa fa-btn fa-print\"></i> Print</button>
				<span class=\"text-primary\" >&nbsp;&nbsp;&nbsp;&nbsp;	List of production data</span>
			</div>

			<div class=\"panel-body  table-responsive\" id=\"printdiv\">
				<table class=\"table table-bordered table-hover\">
						<thead>
						<th ><strong>Line</strong></th>
							<th ><strong>Bred Date</strong></th>
							<th ><strong>Delivery Date</strong></th>
							<th ><strong>Weaning Date</strong></th>
							<th ><strong>Production Type</strong> </th>
							<th ><strong>Species</strong></th>
							<th ><strong>Strain</strong></th>
							<th ><strong>Genotype</strong></th>
							
							<th ><strong>Stock Type </strong></th>
							<th ><strong>Quantity</strong></th>
							<th class=\"remOnPrint\">&nbsp;</th>
						</thead>
						<tbody>";	
	
	if($species == "" && $strain == ""){
		$str=$str. "<tr><td colspan=\"8\" class=\"table-text text-danger\"><div>*Invalid input, You have not selected anything to filter search.</div></td></tr>";
	}else{	
			include "DBconnect.php";
			$i=1;
			if($strain == ""){
				$query= "SELECT * FROM production WHERE Species = '$species' ORDER BY ProductionNo DESC";
			}else{
				$query= "SELECT * FROM production WHERE strain = '$strain' ORDER BY ProductionNo DESC";
			}
			
			$result = mysqli_query($db,$query);
			if($result){
				
					while($pass2=mysqli_fetch_array($result,MYSQLI_ASSOC)){
						$str=$str."<tr ><td>".$i."</td>";
				$str=$str."<td>".$pass2['BredDate']."</td>";
				$str=$str."<td>".$pass2['ProductionDate']."</td>";
				$str=$str."<td>".$pass2['WeanDate']."</td>";
				$str=$str."<td >".$pass2['ProductionCode']."</td>";
				$str=$str."<td >" .$pass2['Species']. "</td>";
				$str=$str. "<td >" .$pass2['strain']. "</td>";
				$str=$str. "<td >".$pass2['Genotype']. "</td>";
				$str=$str. "<td >".$pass2['StockType']. "</td>";
						$str=$str."<td >".$pass2['MALE']."(M)+" .$pass2['Female']."(F)</td>";
						$str=$str."<td class=\"remOnPrint\">
								<form action=\"EditProduction.php\" method=\"POST\">
									<input type=\"hidden\" name=\"prno\" value=\"".$pass['ProductionNo']."\">
									<button type=\"submit\" class=\"btn btn-danger\">
										<i class=\"fa fa-btn fa-edit\"></i> Edit
									</button>
								</form>
							</td>";
						$str=$str."</tr>";
						$i++; 
					}
						
				if ($i== 1){
					$str=$str. "<tr><td colspan=\"8\" class=\"table-text text-danger\"><div>*No Records found</div></td></tr>";
				}
				mysqli_free_result($result);
			}else{
				$str=$str. "<tr><td colspan=\"8\" class=\"table-text text-danger\"><div>*Error, Contact Admin.</div></td></tr>";
			}
			mysqli_close($db);	
		}
	$str=$str."</tbody>
			</table>
		</div>
	</div>";
	echo $str;
	?>
	