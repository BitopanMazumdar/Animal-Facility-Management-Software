<?php include "include/sesionlauth.php"; ?>
 <?php 

$prcode=$_POST['prcode'];
$rowno= $_POST['rowno'];

for($i=1; $i<=$rowno; $i++){
$EntryNumber[$i]=$_POST['EntryNumber'.$i];
$strain[$i]=$_POST['strain'.$i];
$sex[$i]=$_POST['sex'.$i];
$age[$i]=$_POST['age'.$i];
$issueyear[$i]=$_POST['issueyear'.$i];
//$iso[$i]=$_POST['iso'.$i];
$noa[$i]=$_POST['noa'.$i];
}

$flag=1;
if($prcode !=""){
	include "DBconnect.php";
	
	for($i=1; $i<=$rowno; $i++){
		//projectanimal(EntryNumber, ProjectCode, SpStrain, Gender, Weight_Age, NoAnimal)		
		$sql="UPDATE projectanimal SET SpStrain='$strain[$i]', Gender='$sex[$i]', Weight_Age='$age[$i]', NoAnimal='$noa[$i]', IssueYear='$issueyear[$i]' WHERE EntryNumber= '$EntryNumber[$i]' AND ProjectCode='$prcode'";
		
		mysqli_query($db,$sql);
		$result = mysqli_affected_rows($db);
		if($result < 0){ 
			$flag=0;
			$_SESSION['message']="Could not update data: contact admin";
			echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=Projects.php\">";
			die();						
		}
	}
	if($flag==1){
		$_SESSION['message']="Successfully edited !";
		echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=Projects.php\">";
		//$str="Successfully edited ";
	}else{
		$_SESSION['message']="Could not update data: contact admin !";
		echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=Projects.php\">";
		//$str="Successfully edited ! You have not changed Specification of animal !";
	}			
	
	mysqli_close($db);
	
}else{
	$_SESSION['message']="Invalid input data !";
}