<?php include "include/sesionlauth.php"; ?>

<?php 

$PiEmail=$_POST['user']; //filter_var($_POST['PiEmail'], FILTER_SANITIZE_STRING);

if($PiEmail!=""){
include"DBconnect.php";
	//Piname,PiDesignation,PiDepartment,Piphone,Pimobile,PiEmail,PiExperience, PiPasscode,Role,PiAddress,Pin,created_at,updated_at,author 
	$result = mysqli_query($db,"SELECT DISTINCT Piname,PiDesignation,PiDepartment,Piphone,Pimobile,PiEmail,PiExperience, PiPasscode,Role,PiAddress,Pin FROM projectincharge WHERE PiEmail='$PiEmail'");
	
	if($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
	?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  <link rel="stylesheet" href="css/custom.css">
  
</head>
<body style="background-color:#F8F9FA">
<nav >
 <div class="container-fluid">
	<?php 
	include"include/headerboot.php"; 
	?>
  </div>
  <div class="container-fluid">
	<?php 
	include"include/MenuAi.php"; 
	?>		
  </div>
 
 
</nav>
	<div>&nbsp;</div>
<!-- Script start-->

<script type="text/javascript">
function getTitle(val){
	$.get("TitleByProject.php", {prcode:val},function(data, status){
		$("#title").val(data);
	});
}
</script>

<!-- Script end-->
<script type="text/javascript">
$(document).ready(function(){
	$.get("sessionProjectByPi.php", function(data, status){
		$("#pcode").html(data);
	
	});
	$("#displaydiv").slideDown("slow");
});
</script>

<script language="javascript" type="text/javascript" >
	function valid()
	{
		
		frm = document.userform;
		var patt = /[%*+;<=>^]/;
		  if(frm.type.value ==0)
		  {
				alert("Please user type ! ");
				frm.type.focus();
				return false;
		  }	
		  if(frm.name.value =="")
		  {
				alert("Please enter the Name ! ");
				frm.name.focus();
				return false;
		  }
		 if(frm.email.value =="")
		  {
				alert("Please enter the Email Id/User Id ! ");
				frm.email.focus();
				return false;
		  } 	 
		
		if(patt.test(frm.add.value)){
				alert("invalid address input ! special characters: %*+;<=>^ are not allowed");
				frm.add.focus();
				return false;
		}
		/*
		  
		else if(frm.email.value != frm.emailold.value){
				mail=frm.emailold.value;
				
				$.get("email_query.php",{mailid:mail}, function(data, status){
					 if(data==1){
						alert("Email already taken by other user ! Enter different email id ! ");
						return false;
					 }
				}); 
				
		}else{  
		 
		} */
		 r=confirm("confirm submission!");
		  if(r==true){
			  return true;
		  }else{
			  frm.name.focus;
			  return false;
		  }
	}

</script>
	
	<div class="container" id="displaydiv" style="display:none">
        <h3 class="text-primary"><i class="fa fa-user-circle "></i> Edit Profile</h3>
        <form name="userform" id="userform"   action="editProfile-process.php"  method="POST" class="form-horizontal" onsubmit="return valid();">
        
			<div class="form-group">
				<label for="type" class="col-sm-3 control-label"><span style="color: red">*</span>User Type:</label>
				<div class="col-sm-6">
					<select class="form-control" readonly id="type" name="type" > 
						<option value="<?php echo htmlspecialchars($pass['Role']); ?>"><?php echo htmlspecialchars($pass['Role']); ?></option>						
					</select>
				</div>
			</div>
						
			<div class="form-group">
				<label for="name" class="col-sm-3 control-label"><span style="color: red">*</span>Name:</label>
				<div class="col-sm-6">
					<input class="form-control" required style="text-transform: capitalize;" pattern="[A-Za-z\s]*" title="Special characters and digit not allowed" name="name" type="text" id="name" placeholder="Enter name" value="<?php echo htmlspecialchars($pass['Piname']); ?>" />
				</div>
			</div> 
			
			<div class="form-group">
				<label for="email" class="col-sm-3 control-label"><span style="color: red">*</span>Email ID:</label>
				<div class="col-sm-6">
					<input class="form-control col-sm-6" required readonly name="email" type="email" id="email" placeholder="Enter email id" value="<?php echo htmlspecialchars($pass['PiEmail']); ?>" />
					
					<input class="form-control col-sm-6" readonly name="emailold" type="hidden" id="emailold" value="<?php echo htmlspecialchars($pass['PiEmail']); ?>" />
				<div class="alert alert-danger col-sm-4 col-sm-offset-9" id="emailexist" style="display:none"> </div>
					<!--
					<p id="emailok" style="display:none"></p>
					<div class="alert alert-success col-sm-1 col-sm-offset-9" id="emailok" style="display:none"> 
					</div>-->
				</div>
				
			</div> 
			
			<div class="form-group">
				<label for="phone" class="col-sm-3 control-label">Ext/Phone:</label>

				<div class="col-sm-6">
					<input class="form-control"  type="text" name="phone" pattern="[0-9\/\+\s-]{9,}" type="tel" title="digit + - and / allowed only" id="phone" size="15" placeholder="Enter phone number"value="<?php echo htmlspecialchars($pass['Piphone']); ?>" />
				</div>
			</div>
			<div class="form-group">
				<label for="mb" class="col-sm-3 control-label">Mobile:</label>

				<div class="col-sm-6">
					<input class="form-control" pattern="[0-9\+\s-]{9,}" title="digits + - allowed only minimum length:9 " name="mb" type="text" id="mb" size="15" placeholder="Enter mobile number"value="<?php echo htmlspecialchars($pass['Pimobile']); ?>" />
				</div>
			</div>
			<div class="form-group">
				<label for="dg" class="col-sm-3 control-label">Designation:</label>

				<div class="col-sm-6">
					<input class="form-control" style="text-transform: capitalize;" pattern="[A-Za-z\s]*" title="Special characters and digit not allowed" name="dg" type="text" id="dg" placeholder="Enter designation"value="<?php echo htmlspecialchars($pass['PiDesignation']); ?>" />
				</div>
			</div>
			<div class="form-group">
				<label for="dpt" class="col-sm-3 control-label">Department:</label>

				<div class="col-sm-6">
					<input class="form-control" style="text-transform: capitalize;" pattern="[A-Za-z\s0-9-\/]*" title="Special characters and digit not allowed" name="dpt" type="text" id="dpt" placeholder="Enter department"value="<?php echo htmlspecialchars($pass['PiDepartment']); ?>" />
				</div>
			</div>
			
			<div class="form-group">
				<label for="ex" class="col-sm-3 control-label">Experience:</label>
				<div class="col-sm-6">
					<input class="form-control" style="text-transform: capitalize;" pattern="[A-Za-z0-9\s]*" title="Special characters are not allowed" name="ex" type="text" id="ex" placeholder="Enter experience"value="<?php echo htmlspecialchars($pass['PiExperience']); ?>" />
				</div>
			</div>
			<div class="form-group">
				<label for="add" class="col-sm-3 control-label">Address:</label>
				<div class="col-sm-6">
					<textarea class="form-control" style="text-transform: capitalize;" name="add" type="text" id="add" rows="4" cols="30" placeholder="Enter address" ><?php echo htmlspecialchars($pass['PiAddress']); ?></textarea>
				</div>
			</div>
			<div class="form-group">
				<label for="pin" class="col-sm-3 control-label">Pin:</label>
				<div class="col-sm-6">
					<input class="form-control" pattern="[0-9]{6}" title="6 digit pin allowed only" name="pin" type="text" id="pin" placeholder="Enter pin number"  value="<?php echo htmlspecialchars($pass['Pin']); ?>" />
				</div>
			</div>
			
			<!-- Add Task Button -->
			<div class="form-group">
				<div class="col-sm-offset-5 col-sm-6">
					<button type="submit" class="btn btn-danger">
						<i class="fa fa-btn fa-edit"></i> Edit 
					</button>
				</div>
			</div>
		</form>
    </div>
	<div>&nbsp;</div>
	<div>&nbsp;</div>
	
	<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
	</div>
	
</body>
</html>
<?php 
	}
}
?> 