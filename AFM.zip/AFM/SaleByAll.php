<?php include "include/sesionlauth.php"; ?>
  <?php 
	
	include "DBconnect.php";
	$str="<div class=\"panel-heading\">
				<button type=\"button\" class=\"btn btn-danger\" onclick=\"javascript:printDiv()\" ><i class=\"fa fa-btn fa-print\"></i> Print</button>
				<span class=\"text-primary\" >&nbsp;&nbsp;&nbsp;&nbsp;	List of sale data</span>
			</div>

			<div class=\"panel-body  table-responsive\" id=\"printdiv\">
				<table class=\"table table-bordered table-hover\">
				<tr>
					<th rowspan=\"2\" align=\"center\" >Date</th>
					<th rowspan=\"2\" align=\"center\" >Species</th>
					<th rowspan=\"2\"align=\"center\" >Strain</th>
					<th rowspan=\"2\" align=\"center\" >Quantity (M+F = Total)
					</th><th rowspan=\"2\" align=\"center\" >Bill No.</th>
					<th colspan=\"3\" class=\"text-center\" >Sold to</th>
					<th rowspan=\"2\" align=\"center\" >Date & IAEC No.</th>
					<th rowspan=\"2\" class=\"remOnPrint\" >&nbsp;</th>
				</tr>
				<tr>
					<th align=\"center\" >Name</th>
					<th align=\"center\" >Address</th>
					<th align=\"center\" >Reg. No.</th>
				</tr>
				<tbody>";
				
			//fsale(SaleID, Saledate, Scode, Bcode, IEACdate, IAECno, BillNo)
			
			$query= "SELECT SaleID, Saledate, Scode, Bcode, IEACdate, IAECno, BillNo FROM fsale ORDER BY SaleID DESC";
			
			$result = mysqli_query($db,$query);
			if($result){
				$i=1; 
				
				while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
					$spid=$pass['SaleID'];
					$spdata=$pass['Saledate'];
					$spto=$pass['Bcode'];
					$spfrom=$pass['Scode'];
					$IEACdate=$pass['IEACdate'];
					$IAECno=$pass['IAECno'];
					$BillNo=$pass['BillNo'];
					//animalbuyer`(`BCode`, `Bname`, `BRegNum`, `BAddress`, `Bpin`, `Bphone`, `Bmobile`, `BEmail`)
						$Bname="";
						$BRegNum="";
						$BAddress="";
						$Bpin="";
						$queryBuyer= "SELECT Bname, BRegNum, BAddress,Bpin FROM anbuyer WHERE BCode ='$spto' ";
					
						$resultBuyer = mysqli_query($db,$queryBuyer);
						
						if($passBuyer=mysqli_fetch_array($resultBuyer,MYSQLI_ASSOC)){
							$Bname=$passBuyer['Bname'];
							$BRegNum=$passBuyer['BRegNum'];
							$BAddress=$passBuyer['BAddress'];
							$Bpin=$passBuyer['Bpin'];
						} 
					$query1= "SELECT EntrySaleNumber, Species, strain, StockType, MALE, Female FROM sanimal WHERE SaleID ='$spid' ";
				
					$result1 = mysqli_query($db,$query1);
					while($pass1=mysqli_fetch_array($result1,MYSQLI_ASSOC)){
						
						$str=$str. "<td >".$spdata."</td>";
						$str=$str. "<td >" .$pass1['Species']. "</td>";
						$str=$str. "<td >" .$pass1['strain']."</td>";
						$quantity= $pass1['MALE'] + $pass1['Female'];
						$str=$str. "<td >".$pass1['MALE']." + ".$pass1['Female']." = ".$quantity."</td>";
						
						$str=$str. "<td >".$BillNo."</td>";
						$str=$str. "<td >".$Bname."</td>";
						
						$str=$str. "<td >".$BAddress."-".$Bpin."</td>";
						$str=$str. "<td >".$BRegNum."</td>";
						$str=$str. "<td >".$IEACdate." \n ".$IAECno."</td>";
						$str=$str."<td class=\"remOnPrint\">
								<form action=\"editSale.php\" method=\"POST\">
									<input type=\"hidden\" readonly name=\"saleno\" value=\"".$pass['SaleID']."\">
									<input type=\"hidden\" readonly name=\"EntrySaleNumber\" value=\"".$pass1['EntrySaleNumber']."\">
									<button type=\"submit\" class=\"btn btn-danger\">
										<i class=\"fa fa-btn fa-edit\"></i> Edit
									</button>
								</form>
							</td>";
						$str=$str."</tr>";
											
						$i=$i+1;
					}
				}
									
				if ($i== 1){
					$str=$str. "<tr><td colspan=\"10\" class=\"table-text text-danger\"><div>*No Records found</div></td></tr>";
				}	
				
				mysqli_free_result($result);
			}else{
				$str=$str. "<tr><td colspan=\"10\" class=\"table-text text-danger\"><div>*Error, Contact Admin.</div></td></tr>";
			}
	
		mysqli_close($db);
		$str=$str."</tbody>
			</table>
		</div>
	</div>";
	echo $str;
			
	?>
