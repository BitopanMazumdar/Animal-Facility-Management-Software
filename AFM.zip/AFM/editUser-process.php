<?php include "include/sesionlauth.php"; ?>
 <?php 

$emailold=$_POST['emailold'];
//$type=filter_var($_POST['type'], FILTER_SANITIZE_STRING);
	$name=filter_var($_POST['name'], FILTER_SANITIZE_STRING);
	$e=filter_var($_POST['email'], FILTER_SANITIZE_STRING);
	$phone=filter_var($_POST['phone'], FILTER_SANITIZE_STRING);
	$mobile=filter_var($_POST['mb'], FILTER_SANITIZE_STRING);
	$dg=filter_var($_POST['dg'], FILTER_SANITIZE_STRING);
	$dpt=filter_var($_POST['dpt'], FILTER_SANITIZE_STRING);
	$ex=filter_var($_POST['ex'], FILTER_SANITIZE_STRING);
	$add=filter_var($_POST['add'], FILTER_SANITIZE_STRING); 
	$pin=filter_var($_POST['pin'], FILTER_SANITIZE_STRING);

include "DBconnect.php";

//$sql= "INSERT INTO projectincharge(Piname='$name',PiDesignation='$dg',PiDepartment='$dpt',Piphone='$phone',Pimobile='$mobile',PiEmail='$e',PiExperience='$ex', ,Role='$type',PiAddress='$add',Pin='$pin')";
if($emailold !=""){
$query="UPDATE projectincharge SET Piname='$name', PiDesignation='$dg',PiDepartment='$dpt',Piphone='$phone',Pimobile='$mobile',PiEmail='$e',PiExperience='$ex',PiAddress='$add',Pin='$pin', author='$pie'  WHERE PiEmail= '$emailold'" ;
	mysqli_query($db,$query);
		$result = mysqli_affected_rows($db);
		
		if($result >= 0){ 
			$_SESSION['message']="Successfully Edited !";
			echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=user.php\">";
						
		}else{
			$_SESSION['message']="Could not update data: contact admin";
			echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=user.php\">";
			die();
		}
						
		mysqli_close($db);
	
}else{
	$_SESSION['message']="Failed to Update User: You have not select any user !";
	echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=user.php\">";
}
?>
