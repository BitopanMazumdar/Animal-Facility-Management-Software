<?php include "include/sesionlauth.php"; ?>
<?php 

$name = filter_var($_POST['name'], FILTER_SANITIZE_STRING);

$cname = filter_var($_POST['cname'], FILTER_SANITIZE_STRING);
$cdesignation = filter_var($_POST['cdesignation'], FILTER_SANITIZE_STRING);
$cmobile1 = filter_var($_POST['cmobile1'], FILTER_SANITIZE_STRING);
$cmobile2 = filter_var($_POST['cmobile2'], FILTER_SANITIZE_STRING);
$cphone1 = filter_var($_POST['cphone1'], FILTER_SANITIZE_STRING);
$cphone2 = filter_var($_POST['cphone2'], FILTER_SANITIZE_STRING);
$cemail1 = filter_var($_POST['cemail1'], FILTER_SANITIZE_STRING);
$cemail2 = filter_var($_POST['cemail2'], FILTER_SANITIZE_STRING);
$caddress = filter_var($_POST['caddress'], FILTER_SANITIZE_STRING);

	if($cname != ""){	
		include "DBconnect.php" ;
		//INSERT INTO contactperson(cpId, clientID, cpName, cpDesignation, mobile1, mobile2, phone1, phone2, email1, email2, adderss) VALUES 
			$sql1="INSERT INTO contactperson(clientID, cpName, cpDesignation, mobile1, mobile2, phone1, phone2, email1, email2, adderss) VALUES ('$name', '$cname', '$cdesignation','$cmobile1', '$cmobile2', '$cphone1', '$cphone2', '$cemail1','$cemail2','$caddress')";

				$result1 = mysqli_query($db, $sql1);					
				if(!$result1){					
					$_SESSION['message']="Error ! contact admin !";
					echo '<META HTTP-EQUIV="Refresh" Content="0; URL=viewClient.php?">';
					die();
				}
				else{
					$_SESSION['message']="Successfully added person to client : ".$name."  !";
					echo '<META HTTP-EQUIV="Refresh" Content="0; URL=viewClient.php?">';
				}
		
		mysqli_close($db);
	}


?>