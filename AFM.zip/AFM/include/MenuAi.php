<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Animal Facility Management Software</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script> 
<script src="Jquery/jquery-3.js"></script> 
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
.topnav {
  overflow: hidden;
  background-color: #86af49;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 11px 13px;
  text-decoration: none;
  font-size: 15px;
  font-weight:500;
}

.active {
  background-color: blue;
  color: white;
}

.topnav .icon {
  display: none;
}

.dropdownAi {
  float: left;
  overflow: hidden;
}

.dropdownAi .dropbtn {
  font-size: 15px;
  font-weight:500;	
  border: none;
  outline: none;
  color: white;
  padding: 11px 13px;
  text-align: center;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.dropdownAi-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdownAi-content a {
  float: none;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.topnav a:hover, .dropdownAi:hover .dropbtn {
  background-color: red;
  color: white;
}

.dropdownAi-content a:hover {
  background-color: #ddd;
  color: black;
}

.dropdownAi:hover .dropdownAi-content {
  display: block;
}

@media screen and (max-width: 900px) {
  .topnav a:not(:first-child), .dropdownAi .dropbtn {
    display: none;
  }
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 900px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
  .topnav.responsive .dropdownAi {float: none;}
  .topnav.responsive .dropdownAi-content {position: relative;}
  .topnav.responsive .dropdownAi .dropbtn {
    display: block;
    width: 100%;
    text-align: left;
  }
}
</style>
</head>
<body>

<script type="text/javascript">
function profile(){
		
		$("#welcome").hide();
		$("#profile").show();
}

function welcome(){
		
		$("#welcome").show();
		$("#profile").hide();
}
</script> 
<div class="topnav" id="myTopnav">
	<a href="Aihome.php" class="active"><i class="fa fa-home"></i></a>
	   
	<div class="dropdownAi">
		<button class="dropbtn">Protocol 
		  <i class="fa fa-caret-down"></i>
		</button>
		<div class="dropdownAi-content">
			<a href="Projects.php?page=view_proj">Add Protocol</a> 
			<a href="Indents.php?page=view_indents">Animal Request</a>
			<a href="ProjectInventories.php?page=inventory">Animal Request Records</a>
			<a href="IndentArchive.php?page=archive">Protocol Records</a>
		</div>
	</div>
	
	<div class="dropdownAi">
		<button class="dropbtn">Register 
		  <i class="fa fa-caret-down"></i>
		</button>
		<div class="dropdownAi-content">
			<a href="InventoryRegister.php?page=animalhouse"> Inventory Register </a>
            <a href="MonitoringRegister.php?page=room_monitoring">Monitoring Register</a>
            <a href="UploadDocuments.php?page=minutes">Upload Documents</a>
			<a href="ExperimentationAi.php?page=view_util">Experimentation Register</a> 
			<a href="DisposalAi.php?page=view_util">Disposal Register</a> 
		</div>
	</div>
	
	<div class="dropdownAi">
		<button class="dropbtn">Add 
		  <i class="fa fa-caret-down"></i>
		</button>
		<div class="dropdownAi-content">
			<a href="HouseAnimals.php?page=hanimals">Add Animal</a>			 
            <a href="HouseRooms.php?page=ahroom">Add Room</a>
			<a href="User.php?page=view_users"> Add User</a> 
		</div>
	</div>
	
	<div class="dropdownAi">
		<button class="dropbtn">Generate 
		  <i class="fa fa-caret-down"></i>
		</button>
		<div class="dropdownAi-content">
			<a href="FormCReports.php?page=ahreports">Form C</a>
			<a href="FormDReports.php?page=ahreports">Form D</a>
			<a href="FormEReports.php?page=ahreports">Form E</a> 
		</div>
	</div>
	
	<div class="dropdownAi">
		<button class="dropbtn">Report 
		  <i class="fa fa-caret-down"></i>
		</button>
		<div class="dropdownAi-content">
			<a href="InventoryReports.php?page=ahreports">Inventory Reports</a>
			<a href="MonitoringReports.php?page=mon_reports">Monitoring Reports</a>
			<a href="ViewDocuments.php?page=mon_reports">View Documents</a>
			<a href="ViewExperimentationAi.php?page=view_util">Experimentation Report</a>
			<a href="ViewDisposalAi.php?page=view_util">Disposal Report</a> 
		</div>
	</div>
	
	<div class="dropdownAi">
		<button class="dropbtn">Admin 
		  <i class="fa fa-caret-down"></i>
		</button>
		<div class="dropdownAi-content">
			<a href="viewClient.php">Buyer</a>
			<a href="ViewSupplier.php">Supplier</a> 
		</div>
	</div>
	<div class="dropdownAi">
		<button class="dropbtn">CPCSEA 
		  <i class="fa fa-caret-down"></i>
		</button>
		<div class="dropdownAi-content">
			<a href="ViewCM.php">CPCSEA Nominee</a>	
			<a href="ViewIM.php">IAEC Member</a>
			<a href="CPCSEADoc.php">CPCSEA Document</a>
			<a href="Cmeeting.php">Meeting</a> 
		</div>
	</div>
	<a href="profile.php"><i class="fa fa-user"></i> Profile</a>
	<a href="Logout.php"><i class="fa fa-sign-out"></i> Logout</a>
	<a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
	</div>
	<!--
	<div id="welcome" class="profile" onmouseover="profile();"> Welcome : 		
	</div>
	<div id="profile" class="profile" style="display:none" onmouseleave="welcome();">
			<a style="text-decoration:none;" href="profile.php?page=profile">Profile</a>
	</div> 
	-->

<script>
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
</script>

</body>
</html>
