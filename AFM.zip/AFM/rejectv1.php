<?php include "include/sesionlauth.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  
</head>
<body style="background-color:#F8F9FA">
	<nav >
		 <div class="container-fluid">
			<?php 
			include"include/headerboot.php"; 
			?>
		  </div>
		  <div class="container-fluid">
			<?php 
			include"include/MenuAi.php"; 
			?>		
		  </div> 
	</nav>
	
 <!-- srcipt strat -->
<script type="text/javascript">
$(document).ready(function(){
	$("#displaydiv").slideDown("slow");
	$("#displaydiv2").slideDown("slow");
});
</script>


<script type="text/javascript">

function valid(){
	frm=document.issue_form;
	var patt = /[%*+;<=>^]/;
	
	if(frm.msg.value == ""){
		alert("Please enter reason of Rejection!");
		frm.msg.focus();
		return false;
		
	}
	if(patt.test(frm.msg.value)){
			alert("invalid input for remark ! special characters: %*+;<=>^ are not allowed");
			frm.msg.focus();
			return false;
		}
	
  var r = confirm("confirm submit!");
  if(r == true){
    return true;
  }else{
	frm.msg.focus();
    return false;
  }
}

</script>
 <!-- srcipt end -->
<div>&nbsp;</div>

<?php 
$pcode=htmlspecialchars($_POST['pcode']);
$inumber=htmlspecialchars($_POST['inumber']);  
?>
 <div class="container" >
    <div class="col-sm-offset-2 col-sm-8 ">
	<!-- submit message -->
		<?php 
				if(isset($_SESSION['message'])){
					echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
					unset($_SESSION['message']);
				}		
		?>		                    
    </div>
		<h4><span class="col-sm-12 text-primary"><i class="fa fa-check"></i>Animal Request Management </span></h4>
                   
</div>
 <div class="container" id="displaydiv" style="display:none">
	 <form action="Reject_processing.php" method="post" name="myform" id="myform" onsubmit="return valid();" class="form-horizontal">
		<?php 
			include "DBconnect.php";
			$result = mysqli_query($db,"SELECT IndentNumber, Projectcode, Title,  RName, ARDate,IndentTime, Duration, TAssistance, SRequest FROM indentform WHERE IndentNumber='$inumber'");
			
			if($result){
				$str="<div class=\"container\" >
				<div class=\"panel panel-success\">
				<div class=\"panel-heading\">
					Animal Request details
				</div>
				<div class=\"panel-body  table-responsive\" >
					<table class=\"table table-striped table-hover\">
						<thead>
							<th>Protocol</th>
							<th>Title</th>
							<th>Requested By</th>
							<th>Needed On</th>
							<th>Time</th>
							<th>Duration</th>
							<th>Assistant</th>
							<th>Sp. Request</th>
						</thead>
						<tbody>";
					
				$i=1;
				while($pass=mysqli_fetch_array($result,MYSQLI_BOTH)){
					//IndentNumber, Projectcode, Title,  RName, ARDate,IndentTime, Duration, TAssistance, SRequest
					$str=$str."<tr> 
							<td class=\"table-text\"><div>".htmlspecialchars($pass['Projectcode'])."</div></td>
							<td class=\"table-text\"><div>".htmlspecialchars($pass['Title'])."</div></td>
							<td class=\"table-text\"><div>".htmlspecialchars($pass['RName'])."</div></td>
							<td class=\"table-text\"><div>".htmlspecialchars($pass['ARDate'])."</div></td>
							<td class=\"table-text\"><div>".htmlspecialchars($pass['IndentTime'])."</div></td>
							<td class=\"table-text\"><div>".htmlspecialchars($pass['Duration'])."</div></td>
							<td class=\"table-text\"><div>".htmlspecialchars($pass['TAssistance'])."</div></td>
							<td class=\"table-text\"><div>".htmlspecialchars($pass['SRequest'])."</div></td>
						</tr>";
						$i++;
						
					$result1 = mysqli_query($db,"SELECT SpStrain, Gender, Weight_Age,NoAnimal FROM indentanimal WHERE IndentNumber='$inumber' ");
					$j=0;
					if($result){
						$str=$str."<tr>
						<td colspan=\"9\">
						<div class=\"table responsive\">
						<table class=\"table\" border=\"1\" style=\"border-color: #666;border-collapse:collapse;width:80%;\" cellpadding=\"10\" align=\"center\">
							<tr>
								<th>Line</th>
								<th>Animal</th>
								<th>Gender</th>
								<th>Quantity</th>
								<th>Wieght/Age</th>  
							</tr>
								<input type=\"hidden\" name=\"ai1\" value=\"155\" />
								<input type=\"hidden\" id=\"inum\" name=\"inum\" value=\"".$inumber."\"  />
								<input type=\"hidden\" name=\"pc\" value=\"".$pcode."\" />";
							
						while($pass1=mysqli_fetch_array($result1,MYSQLI_BOTH)){
							$j++;
							$str=$str."<tr>
								<td class=\"table-text\"><div>".$j."</div></td>
								<td class=\"table-text\"><div>
									<input class=\"form-control\" type=\"text\" readonly id=\"strain".$j."\" name=\"strain".$j."\" value=\"".htmlspecialchars($pass1['SpStrain'])."\" />
								</div></td>
								
								<td class=\"table-text\"><div>
									<input class=\"form-control\" type=\"text\" readonly  id=\"sex".$j."\" name=\"sex".$j."\" value=\"".htmlspecialchars($pass1['Gender'])."\"  />
								</div></td>
								
								<td class=\"table-text\"><div>
									<input class=\"form-control\" size=\"10%\" type=\"number\" min=\"1\" name=\"isno".$j."\" id=\"isno".$j."\"  value=\"".htmlspecialchars($pass1['NoAnimal'])."\" onchange=\"checkNo(this.value,".htmlspecialchars($pass1['NoAnimal']).",".$j.")\"  />
								</div></td>
								<td class=\"table-text\"><div>
									<input class=\"form-control\" readonly type=\"text\" id=\"age".$j."\" name=\"age".$j."\" value=\"".htmlspecialchars($pass1['Weight_Age'])."\"  />
								</div></td>
								
							</tr>";			  
						
						}
					$str=$str."<input type=\"hidden\" id=\"rowno\" name=\"rowno\" value=\"".$j."\"  />	
								</table>
							</div>
						</td>
					</tr>
					</tbody>
				</table>
			</div>
		</div>";
					}else{
						//
					}
				}
			}else{
				//
			}
					
			echo $str;
			
			mysqli_free_result($result);
			mysqli_close($db);
				 					
		?> 
	<div class="container" id="displaydiv2" style="display:none">
        <div class="col-sm-offset-1 col-sm-10">
            <div class="panel panel-info">
                <div class="panel-heading">
                   Animal House Reply
                </div>

                <div class="panel-body">
                    <!-- submit message -->
						<?php 
								if(isset($_SESSION['message'])){
									echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
									unset($_SESSION['message']);
								}		
						?>
					<!-- submit message -->	
                                        
                        <!-- Task Name -->
                        
						<div class="form-group">
							<label for="zone" class="col-sm-3 control-label"><span style="color: red">*</span>Remark:</label>
							<div class="col-sm-6">
								<textarea class="form-control" required name="msg" cols="30" rows="3" id="msg"></textarea>
							</div>
						</div>
						<!-- Add Task Button -->
                        <div class="form-group">
                            <div class="col-sm-offset-4 col-sm-6">
                                <button type="submit" class="btn btn-danger">
                                    <i class="fa fa-btn fa-close"></i> Reject Request
                                </button>
								<button type="submit" class="btn btn-warning" onclick="window.history.back()">
									<i class="fa fa-btn fa-user-arrow-left"></i> Back
								</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
		</div>
	</div>		

	<div>&nbsp;</div>
	<div>&nbsp;</div>
	
	<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
	</div>
	
</body>
</html>	