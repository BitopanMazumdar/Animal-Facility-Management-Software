<?php include "include/sesionlauth.php"; ?>
 <?php 
	include "DBconnect.php";
	
	$result = mysqli_query($db,"SELECT DISTINCT PiEmail FROM projectincharge ");
	
	$str = "<option value=\"\"> Select</option>";
	if($result){
		while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
			
			$str = $str . "<option value=\"".$pass['PiEmail']."\">".$pass['PiEmail']."</option>";
		}
		echo $str;
		mysqli_free_result($result);
		
	}
	mysqli_close($db);	
	?>