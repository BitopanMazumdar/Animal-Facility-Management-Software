<?php include "include/sesionlauth.php"; ?>
 <?php 

	$MortalityNo=filter_var($_POST['MortalityNo'], FILTER_SANITIZE_STRING);
	
	$mcode=filter_var($_POST['mcode'], FILTER_SANITIZE_STRING);
	$species=filter_var($_POST['species'], FILTER_SANITIZE_STRING);
	$strain=filter_var($_POST['strain'], FILTER_SANITIZE_STRING);
	$stock=filter_var($_POST['stock'], FILTER_SANITIZE_STRING);
	$qm=filter_var($_POST['qm'], FILTER_SANITIZE_STRING);
	$qf=filter_var($_POST['qf'], FILTER_SANITIZE_STRING);
	$mdate=filter_var($_POST['mdate'], FILTER_SANITIZE_STRING);

//Mortality(MortalityNo,Mortalitycode,Species,strain,StockType,MALE,Female,MortalityDate) 
//('$mcode', '$species', '$strain', '$stock', '$qm', '$qf', '$mdate')
if($MortalityNo!=""){
	include "DBconnect.php";
	
	$query="UPDATE Mortality SET Mortalitycode='$mcode', Species='$species', strain='$strain', StockType='$stock', MALE='$qm', Female='$qf', MortalityDate='$mdate' WHERE MortalityNo= '$MortalityNo'" ;
	mysqli_query($db,$query);
		$result = mysqli_affected_rows($db);
		if($result>=0){
			$_SESSION['message']="Successfully edited  !";
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=MortalityReport.php">';
			
		}else{
			$_SESSION['message']="Error, Contact Admin  !";
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=MortalityReport.php">';
		}
		
		mysqli_close($db);
	
}else{
	$_SESSION['message']="Error, Invalid input  !";
	echo '<META HTTP-EQUIV="Refresh" Content="0; URL=MortalityReport.php">';
}