<?php include "include/sesionlauth.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Form E</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  
</head>
<body style="background-color:#F8F9FA">
	<nav >
		 <div class="container-fluid">
			<?php 
			include"include/headerboot.php"; 
			?>
		  </div>
		  <div class="container-fluid">
			<?php 
			include"include/MenuAi.php"; 
			?>		
		  </div> 
	</nav>
	
<!-- Script start-->
<script type="text/javascript">
$(document).ready(function(){
	$("#displaydiv").slideDown("slow");
});
</script>

<script type="text/javascript">
function showList()
{
	$("#viewdata").hide();
	$("#loader").show();
	type=$('input:radio[name=type]:checked').val();
	sc=$('#scode').val();
	bc=$('#bcode').val();
	vdate=$('#vdate').val();
	vdate1=$('#vdate1').val();
	if(type==1){
		
		var xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = function() {
		  if (this.readyState == 4 && this.status == 200) {
			  
			document.getElementById("viewdata").innerHTML = this.responseText;
			$("#viewdata").slideDown("slow");
			$("#loader").hide();
		  }
		};
		
		xmlhttp.open("GET", "FormEByBcode.php?bc="+bc, true);
		xmlhttp.send();
	}
	if(type==2){
		
		var xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = function() {
		  if (this.readyState == 4 && this.status == 200) {
			document.getElementById("viewdata").innerHTML = this.responseText;
			$("#viewdata").slideDown("slow");
			$("#loader").hide();
		  }
		};
		
		xmlhttp.open("GET", "FormEByScode.php?sc="+sc, true);
		xmlhttp.send();
	}
	if(type==3){
		
		if(vdate==""){
			alert("Select From date");
		}else if(vdate1==""){
			alert("Select To date");
		}else if (new Date(vdate) > new Date(vdate1)){ 
			alert("To Date must be greater than From date");
		}else{
			//window.location='FormEByDate.php?page=ahreports&pg=supprep&type='+type+'&sd='+vdate+'&sd1='+vdate1+'';
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() {
			  if (this.readyState == 4 && this.status == 200) {
				document.getElementById("viewdata").innerHTML = this.responseText;
				$("#viewdata").slideDown("slow");
				$("#loader").hide();
			  }
			};
			
			xmlhttp.open("GET","FormEByDate.php?sd="+vdate+"&sd1="+vdate1, true);
			xmlhttp.send();
		}
	}
}

function checkType(val)
{
//alert(val);

$('input:radio[name=type]')[val].checked = true;
}
</script>

<script type="text/javascript">
$(document).ready(function(){
		
	$.get("Buyer_query.php", function(data, status){
		$("#bcode").html(data);
		
	});
	$.get("Supplier_query.php", function(data, status){
		$("#scode").html(data);
		
	});
	var xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = function() {
		  if (this.readyState == 4 && this.status == 200) {
			document.getElementById("viewdata").innerHTML = this.responseText;
			$("#viewdata").slideDown("slow");
			$("#loader").hide();
		  }
		};
		
		xmlhttp.open("GET", "FormEByAll.php", true);
		xmlhttp.send();	
	
});

</script>
<!-- Script end-->
<script type="text/javascript">
function printDiv() {
        //Get the HTML of whole page
        var oldPage = document.body.innerHTML;
        //remove unwanted elements
		
		$("th").remove(".remOnPrint");
		$("td").remove(".remOnPrint");
		//$("#rempbdiv").remove(); 
		//Reset the page's HTML with div's HTML only
		//Get the HTML of div
        var divElements = document.getElementById('printdiv').innerHTML; 
        //alert(divElements);
		var htmlToPrint = '' +
        '<style type="text/css">' +
        'table th, table td {' +
        'border:1px solid black;' +
        'padding;0.5em;' +
        '}' +'table thead {'+'border:1px solid black; background-color:#F8F9FA;'+'}'+
        '</style>';
        document.body.innerHTML = 
          "<html><head><title>All Client List</title>" +  htmlToPrint+"</head><body>" + divElements + "</body></html>";
        //Print Page
        window.print();
        //Restore orignal HTML
        document.body.innerHTML = oldPage;

    }
</script>
 <!-- srcipt end -->
<div>&nbsp;</div>
<div class="container" id="displaydiv" style="display:none">
        <div class="col-sm-offset-2 col-sm-8">
            <div class="panel panel-default">
                <div class="panel-heading">
                   Sale Record Management
                </div>

                <div class="panel-body">
                    <!-- submit message -->
						<?php 
								if(isset($_SESSION['message'])){
									echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
									unset($_SESSION['message']);
								}		
						?>
					<!-- submit message -->	

                    <!-- New Task Form -->
                    <form class="form-horizontal">
						<div class="row">
							<div class="radio col-sm-3">
							  <label><input  name="type" type="radio" value="1" checked>Buyer</label>
							</div>
							
							<div class="form-group col-sm-6">
								<select class="form-control" name="bcode" id="bcode"  onfocus="checkType('0')">
									<option value="">Select</option>
								</select> 
							</div>
						</div>
						<div class="row">
							<div class="radio col-sm-3">
							  <label><input  name="type" type="radio" value="2" checked>Supplier</label>
							</div>
							
							<div class="form-group col-sm-6">
								<select class="form-control" name="scode" id="scode"  onFocus="checkType('1') ">
									<option value="">Select</option>
								</select> 
							</div>
						</div>
						<div class="row">
							<div class="radio col-sm-3">
							  <label><input name="type" type="radio" value="3" >Date</label>
							</div>
							
							<div class="form-group col-sm-4">
								<label for="vdate" class="col-sm-3 control-label">From:</label>
								<div class="col-sm-6">
									<input class="form-control" style="width:10em;" type="date" name="vdate" id="vdate"  onfocus="checkType('2')" />
								</div>
							</div>
							
							<div class="form-group col-sm-4">
								<label for="vdate1" class="col-sm-3 control-label">To:</label>
								<div class="col-sm-6">
									<input class="form-control" style="width:10em;" type="date" name="vdate1" id="vdate1"  onfocus="checkType('2')" />
								</div>
							</div>
						</div>
						<div class="row">
							<div class="form-group">
								<div class="col-sm-offset-4 col-sm-6">
									
									<button type="button" onClick="showList()" class="btn btn-success">
										<i class="fa fa-btn fa-search"></i> Search
									</button>
								</div>
							</div>
						</div>
					</form>
                </div>
            </div>
		</div>
	</div>
	<div class="container">
        <div class="col-sm-offset-0 col-sm-12">
            <div id="viewdata" class="panel panel-default" style="display:none">
			<!-- load data-->	
			</div>
		</div>
		</div>
	</div>
    
	<div class="container" >
		<div id="loader" class="col-sm-offset-5 col-sm-7 loader">
		</div>
	</div>
	
	<div>&nbsp;</div><div>&nbsp;</div>
	<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
	</div>
	
</body>
</html>