<?php include "include/sesionlauth.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  
</head>
<body style="background-color:#F8F9FA">
	<nav >
		 <div class="container-fluid">
			<?php 
			include"include/headerboot.php"; 
			?>
		  </div>
		  <div class="container-fluid">
			<?php 
			include"include/MenuAi.php"; 
			?>		
		  </div> 
	</nav>
	
 <!-- srcipt strat -->
<script type="text/javascript">
$(document).ready(function(){
	$("#displaydiv").slideDown("slow");
});
</script>
<script type="text/javascript">
 $(document).ready(function(){
	$.get("species_query.php", function(data, status){
		$("#species1").html(data);
		
	});    
	$.get("AddprojectPi_query.php", function(data, status){
		
		$("#pi").html(data);
	});
	$.get("emailByPi_query.php", function(data, status){
		
		$("#email").html(data);
	});
});	
function getStrain(val,no)
{
	
$.get("strain_query.php",
  {
    sp:val
  },
  function(data,status){
  //sleep(1000);
 
    $("#strain"+no).html(data);
    //$("#strain"+no).css("width":"150px");
  });
}
function getSpecies(no){
	
	$.get("species_query.php", function(data, status){
		//alert(data);
		$("#species"+no).html(data);
	});
}

</script>
	 
<script type="text/javascript">

$(document).ready(function(){
  $("#addRow").click(function(){
   //alert("hello");
   val=$("#row_no").val();
   if(val!=10)
   {
   val++;
   getSpecies(val);
   $("#row_no").val(val);
    $("#row"+val).slideDown();
    $("#close"+val).show();
    val--;
    $("#close"+val).hide();
    }
  }); 
  
  
});

function Close(val)
{

 $("#row"+val).slideUp();
 val--;
 $("#row_no").val(val);
 $("#close"+val).show("slow");
 }
 

</script>

<script type="text/javascript">
function valid(){
	frm = document.myform;
	no=frm.row_no.value;
	var patt = /[%*+;<=>^]/;
	
	 if(frm.code.value =="")
	  {
			alert("Please enter the Project Code ! ");
			frm.code.focus();
			return false;
	  }
	  
	  if(frm.name.value =="")
	  {
			alert("Please enter Project Name !");
			frm.name.focus();
			return false;
	  }
	  if(patt.test(frm.name.value)){
			alert("invalid address ! special characters: %*+;<=>^ are not allowed");
			frm.name.focus();
			return false;
		}
	  if(frm.pi.value =="")
	  {
			alert("Please enter Project Incharge !");
			frm.pi.focus();
			return false;
	  }
	  if(frm.doa.value =="")
	  {
			alert("Please enter Date of Approval !");
			frm.doa.focus();
			return false;
	  }
	  if(frm.dfrom.value =="")
	  {
			alert("Please enter Duration of Approval From Date!");
			frm.dfrom.focus();
			return false;
	  }
	  if(frm.dto.value =="")
	  {
			alert("Please enter Duration of Approval To Date !");
			frm.dto.focus();
			return false;
	  } 
	 
	  for(j=1;j<=no;j++)
		{
			//alert("strain" + j);
		if(document.getElementById("species" + j).value =="")
		  {
				alert("Please enter species !");
				document.getElementById("species" + j).focus();
				return false;
		  }			
		  if(document.getElementById("strain" + j).value =="")
		  {
				alert("Please enter starin !");
				document.getElementById("strain" + j).focus();
				return false;
		  }
		  //	alert("sex" + j);	  
		 if(document.getElementById("sex" + j).value =="")
		  {
				alert("Please enter Gender !");
				document.getElementById("sex" + j).focus();
				return false;
		  }
		  //alert("no_of_an" + j);
		  if(document.getElementById("no_of_an" + j).value =="")
		  {
				alert("Please enter No. OF Animals !");
				document.getElementById("no_of_an" + j).focus();
				return false;
		  }
		  
		  if(document.getElementById("issueyear" + j).value =="")
		  {
				alert("Please enter year !");
				document.getElementById("issueyear" + j).focus();
				return false;
		  } 
		  //alert("age" + j);
		  if(document.getElementById("age" + j).value =="" )
		  {
				alert("Please enter Weight/Age !");
				document.getElementById("age" + j).focus();
				return false;
		  }*/
		}
		r=confirm("confirm submission!");
		  if(r==true){
			  return true;
		  }else{
			  frm.code.focus;
			  return false;
		  }
	  
}
</script>		
<!-- End of validation -->


 <!-- srcipt end -->
	
	<div class="container" id="displaydiv" style="display:none">
        
		<div class="panel panel-default">
			<div class="panel-heading">
				<h4 class="text-primary"><i class="fa fa-plus"></i>  Add Protocol/Form B Information</h4>
			</div>
		  
		  <div class="panel-body">
        <form name="myform" id="myform" autocomplete="off" action="AddProject_processing.php" method="post" onsubmit="return valid();" class="form-horizontal" >
        <!-- submit message -->
					<?php 
						
							if(isset($_SESSION['message'])){
								echo "<div class=\"alert alert-danger\">".$_SESSION['message']."</div>"; 
								unset($_SESSION['message']);
							}
												
					?>
		<!-- submit message -->
			<div class="form-group">
				<label for="code" class="col-sm-3 control-label">Protocol:</label>
				<div class="col-sm-6">
					<input class="form-control" style="text-transform:capitalize;" title="Special characters: . / \ - are allowed only" required name="code" type="text" id="code" placeholder="Enter protocol number" />
				</div>
			</div>
			<div class="form-group">
				<label for="name" class="col-sm-3 control-label">Title:</label>
				<div class="col-sm-6">
					<textarea class="form-control" style="text-transform:capitalize;" name="name" rows="2" cols="30" id="name" type="text" placeholder="Enter title of protocol"></textarea>
				</div>
			</div>
			
			<div class="form-group">
				<label for="pi" class="col-sm-3 control-label">Incharge:</label>
				<div class="col-sm-6">
					<select class="form-control" required   name="pi" id="pi" >
							  <option value="" selected>Select</option>
									  
							  </select> 
				</div>
			</div>
			<div class="form-group">
				<label for="email" class="col-sm-3 control-label">Email ID:</label>
				<div class="col-sm-6">
					<select class="form-control" required   name="email" id="email" >
							  <option value="" selected>Select</option>
									  
							  </select> 
				</div>
			</div>
						
			<div class="form-group">
				<label for="doa" class="col-sm-3 control-label">Date of CPCSEA Approval:</label>

				<div class="col-sm-6">
					<input class="form-control" required   name="doa" type="date" id="doa" />
				</div>
			</div>
			<div class="form-group">
				<label for="idoa" class="col-sm-3 control-label">Date of IEAC Approval:</label>

				<div class="col-sm-6">
					<input class="form-control" required   name="idoa" type="date" id="idoa" />
				</div>
			</div>
			<div class="form-group">
				<label for="dfrom" class="col-sm-3 control-label">Duration Form:</label>

				<div class="col-sm-6">
					<input class="form-control" required  name="dfrom" type="date" id="dfrom"  />
				</div>
			</div>
			<div class="form-group">
				<label for="dto" class="col-sm-3 control-label">Duration To:</label>

				<div class="col-sm-6">
					<input class="form-control" required  name="dto" type="date" id="dto"  />
				</div>
			</div> 
			<div class="form-group">
				<label for="remark" class="col-sm-3 control-label">Remark:</label>

				<div class="col-sm-6">
					<input class="form-control"   name="remark" type="text" id="remark"  />
				</div>
			</div>
			<!-- anspecification  -->
			<div class="form-group col-sm-offset-1 col-sm-11 ">
				<?php include "animalSpecification.php"; ?>
			</div>
			<!-- anspecification end -->
			<!-- Add Task Button -->
			<div class="form-group">
				<div class="col-sm-offset-4 col-sm-6">
					<button type="submit" class="btn btn-danger">
						<i class="fa fa-btn fa-user-plus"></i> 	Add protocol</button> 
					<button type="reset" class="btn btn-primary"><i class="fa fa-btn fa-refresh">
						</i> Reset</button> 
					<button type="button" class="btn btn-warning" onclick="window.history.back()">
						<i class="fa fa-btn fa-arrow-circle-left"></i> Back</button>
					</button>
				</div>
			</div>
		</form>
    </div></div></div>
	<div>&nbsp;</div>
	<div>&nbsp;</div>
	
	<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
	</div>
	
</body>
</html>