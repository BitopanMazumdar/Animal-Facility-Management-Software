<?php include "include/sesionlauth.php"; ?>

<?php 

//session_start();

$species=$_POST['species'];
$species=trim($species);
if($species!=""){

	include "DBconnect.php";
	$sqlck="SELECT Species FROM animals WHERE Species= '$species'";
		$resultck = mysqli_query($db, $sqlck);
		if(!$resultck){
			 $_SESSION['message']="Fail to add  ! contact admin";
			echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=HouseAnimals.php\">";
			die('Error: ' . mysqli_error($db));
		}else{
			if($passck = mysqli_fetch_array($resultck,MYSQLI_ASSOC)){
				
				$_SESSION['message']="Not Added, Species:  $species already exist ! ";
				echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=HouseAnimals.php\">";
			}else{
	
				$st="";
				$sql="INSERT IGNORE INTO animals(Species,strain ) values ('$species','$st')";

				$Result = mysqli_query($db, $sql);


				if(!$Result)
				  {
					$_SESSION['message']="Fail to add  ! contact admin";
					echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=HouseAnimals.php\">";
					die('Error: ' . mysqli_error($db));
				  }
				else
				{
					$_SESSION['message']="Succssesfully added new species  !";
					echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=HouseAnimals.php\">";

				}
			}
		}
	mysqli_close($db);
	
}else{
	$_SESSION['message']="Fail, Invalid input data  !";
	echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=HouseAnimals.php\">";	
}

?>
