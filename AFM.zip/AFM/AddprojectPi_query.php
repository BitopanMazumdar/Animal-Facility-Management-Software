<?php include "include/sesionlauth.php"; ?>
<?php 
	
	include"DBconnect.php";
	$str="<option value=\"\"> Select </option>";
	$result = mysqli_query($db,"SELECT PiName FROM projectincharge " );
	while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
		
		$str=$str."<option value=\"" .$pass['PiName']. "\">".$pass['PiName']."</option>";
	}
	echo $str;
	mysqli_free_result($result);
	mysqli_close($db);
		
?>