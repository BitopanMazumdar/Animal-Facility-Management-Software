<?php include "include/sesionlauth.php"; ?>
<?php 

$disnumber= htmlspecialchars($_POST['disnumber']);

if($disnumber!=""){
include"DBconnect.php";
	//disposeform (DisposeNumber, Projectcode, Title, DisposeBy, DisposeDate, Reason, Euthanasia) 
	$result = mysqli_query($db,"SELECT DISTINCT DisposeNumber, Projectcode, Title, DisposeBy, DisposeDate, Reason, Euthanasia FROM disposeform WHERE DisposeNumber ='$disnumber'");
	while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
			
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  <link rel="stylesheet" href="css/custom.css">
  
</head>
<body style="background-color:#F8F9FA">
<nav >
 <div class="container-fluid">
	<?php 
	include"include/headerboot.php"; 
	?>
  </div>
  <div class="container-fluid">
	<?php 
	include"include/MenuAi.php"; 
	?>		
  </div>  
</nav>
<!-- Script start-->
<script type="text/javascript">     
    
$(document).ready(function(){
	$("#main").show("slow");
	// get piname from session variable and fetch projects of the PI    
	$.get("Project_queryAll.php", function(data, status){
	$("#pcode").html(data);
	
	});	
});
</script>

<script type="text/javascript">
function CheckAvail(val,no)
{
		
	check=1;
	z=$("#rowno").val();
	
	for(x=1;x<=z;x++)
	{
	//alert(x);
	if(x!=no)
	{
		if($("#strain"+x).val()==$("#strain"+no).val())
		{
			//alert("strain same");
			if($("#sex"+x).val()==$("#sex"+no).val())
			{
				$("#strain"+no).val("");
				$("#sex"+no).val("");
				$("#no_of_an"+no).val("");
				check=0;
				alert("Species/Strain allready selected");
			}
			else
			{
				//alert("gender different");
				if($("#no_of_an"+x).val()=="")
				nav=0;
				else
				nav=$("#no_of_an"+x).val();
				val=parseInt(val)+parseInt(nav);
				
			}
		}
	}
	//x++;
	}

	
	pid=$("#pcode").val();
	aid=$("#strain"+no).val();
	gen=$("#sex"+no).val();
	if(check==1 && val!="" && pid!=0 && aid!="")
	{
		//$("#avl"+no).html("<img src='images/loading.gif' height='20' width='20' />");
		$.get("AnimalAvailabilty.php",{
			aid:aid,
			pid:pid,
			gen:gen,
			val:val
		},
		  function(data,status){
			 
			if(data==-2){
				 $("#avl"+no).html("");
				  $("#no_of_an"+no).val("");
				alert("Error, contact admin!");
			}else if(data==-1)
			  {
				 $("#avl"+no).html("<img src='images/right.jpg' height='10' width='12' />"); //  
			  }
			  else
			  {
				$("#avl"+no).html("");
				  $("#no_of_an"+no).val("");
				  alert("Exeeds approved Species/Strain limit, Approved = "+data);
			  }
			  });

	}
	else
	 $("#avl"+no).html("");
}

function checkGender(val,no)
{
	 $("#no_of_an"+no).val("");
	 $("#avl"+no).html("");
	 pco=$("#pcode").val();
	 $.get("Genderquery.php",
	  {
		aid:val, pc:pco
	  },
	  function(data,status){
		 //alert(data);
		 $("#sex"+no+"").html(data);
	   
	  }); 
}

function showTitle(val)
{
	window.location="Title_query.php?page=indent_form&proj="+val;
}

function CheckDate(ete)
{
    
	return true;
    
}
</script>
<script type="text/javascript">
function showOtherReason(eve){
	
	//alert(eve);
	if(eve=="other"){
		//document.getElementById('otherRoute').style.display = "block";
		$('#otherReason').show();
   } else{
		$('#otherReason').hide();
   }
	//$("#route").show();
}
function showOtherEuthanasia(eve){ 
	if(eve=="other"){
		//document.getElementById('otherRoute').style.display = "block";
		$('#otherEuthanasia').show();
   } else{
		$('#otherEuthanasia').hide();
   }
}

function getTitle(val){
	$.get("TitleByProject.php", {prcode:val},function(data, status){
	//$("#title").html(data);
	$("#title").val(data);
	});
}
</script>
<script type="text/javascript">

function getSpstrain(val){
	rowno=$("#rowno").val();
	$.get("SpStrainByProject.php", {prcode:val}, function(data, status){
		
		for(i=1; i<=rowno; i++){
			// "<select class=\"form-control\" name=\"strain1\" id=\"strain"+i+"\" onchange=\"checkGender(this.value,1)\"><option value=\"\">Select</option>" + data+"</select>";
            //alert(data);    
			$("#strain"+i).html(data);
		}
    });
}	
</script>

<!-- Validation-->
<script type="text/javascript">
function valid(){
	frm = document.myform;
	no=frm.rowno.value;
	
	  if(frm.recn.value =="")
	  {
			alert("Please Enter Disposed By !");
			frm.recn.focus();
			return false;
	  }
	  	 
	  for(j=1;j<=no;j++)
		{
					
		  if(document.getElementById("strain" + j).value =="")
		  {
				alert("Please enter species/starin !");
				document.getElementById("strain" + j).focus();
				return false;
		  }
		  		  
		/* if(document.getElementById("sex" + j).value =="")
		  {
				alert("Please enter Gender !");
				document.getElementById("sex" + j).focus();
				return false;
		  }
		  */
		  if(document.getElementById("no_of_an" + j).value ==0)
		  {
				alert("Please enter No. OF Animals !");
				document.getElementById("no_of_an" + j).focus();
				return false;
		  }
		   
		  if(document.getElementById("age" + j).value =="" )
		  {
				alert("Please enter Weight/Age !");
				document.getElementById("age" + j).focus();
				return false;
		  }
		}
	
		if(frm.reason.value =="other")
	  {
		  if(frm.oReason.value==""){
			alert("Please Enter Reason for Disposal !");
			frm.oReason.focus();
			return false;
		  }
	  }
	  if(frm.euthanasia.value =="other")
	  {
		  if(frm.oEuthanasia.value==""){
			alert("Please Enter Method of Euthanasia !");
			frm.oEuthanasia.focus();
			return false;
		  }
	  }
	  if(frm.reqdate.value =="")
	  {
			alert("Please Enter Requested Date!");
			frm.reqdate.focus();
			return false;
	  }
	 
	  var r = confirm("confirm submit!");
	  if (r == true) {
		return true;
	  } else {
		frm.pcode.focus();
		return false;
	  }
	  
}
</script>		

<!-- End of validation -->

<!-- Script end-->
<div class="container" id="main" style="display:none">
<br>
<!-- submit message -->
	<?php 
		
		if(isset($_SESSION['message'])){
			echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
			unset($_SESSION['message']);
		}
								
	?>
<!-- submit message -->
<form class="form-horizontal" name="myform" id="myform" autocomplete="off" method="post" action="EditDis_proccess.php" onsubmit="return valid();"> 
	
	<div class="form-group">
	<fieldset>
	<legend>Edit Disposal management </legend>
		<table class="table"  align="center" >
					 <tr>
						<td   ><strong>Protocol</strong></td>
						
						<td    ><input class="form-control" class="form-control" name="pcode" id="pcode" readonly type="text" value="<?php echo htmlspecialchars($pass['Projectcode']); ?>" />
						 </td>
					  </tr>
					 
					  <tr>
						<td  ><strong>Disposed by</strong></td>
						
						<td  colspan="3" ><input required value="<?php echo htmlspecialchars($pass['DisposeBy']); ?>" class="form-control" name="recn" type="text" id="recn" /></td>
					  </tr>
					 </table>
			</fieldset>
		</div>
		<div class="form-group">
			<fieldset>
			<legend>Edit animal specification </legend>
				<div class="table-responsive">
					<table class="table anspecification"  border="0" align="center" cellpadding="5" cellspacing="1">
						
								
						  <tr  id="row1">
							<th  align="left" ><strong> Species / Strain </strong></th>
							<th  align="left" ><strong>Gender</strong></th>
							<th align="left" ><strong>No of Animals </strong></th>
							<th align="left" ><strong>Weight/age</strong></th>
							
						  </tr>
						  
						  
						<?php //query for spstrain  
							 echo "<input type=\"hidden\" id=\"inum\" class=\"form-control\" name=\"inum\" value=\"".$disnumber."\"  />";
							 $prcode=$pass['Projectcode']; 
							//experimentationanimal(EntryNo, ExperimentationNumber, SpStrain, Gender, Weight_Age, NoAnimal)	
							$result1 = mysqli_query($db,"SELECT EntryNo,SpStrain, Gender, Weight_Age,NoAnimal FROM disposeanimal WHERE DisposeNumber='$disnumber' ");
							$j=1;
							
							while($pass1=mysqli_fetch_array($result1,MYSQLI_BOTH)){

							echo"<tr>
							  <td><select required id=\"strain".$j."\" class=\"form-control\" name=\"strain".$j."\" onchange=\"checkGender(this.value,".$j.")\"/> 
							  <option value=\"".htmlspecialchars($pass1['SpStrain'])."\" selected=\"selected\">".htmlspecialchars($pass1['SpStrain'])."</option>";
								   $resultsp = mysqli_query($db,"SELECT DISTINCT SpStrain FROM projectanimal WHERE ProjectCode='$prcode'");
											while($passsp=mysqli_fetch_array($resultsp,MYSQLI_ASSOC)){
											
											echo "<option value=\"".htmlspecialchars($passsp['SpStrain'])."\">".$passsp['SpStrain']."</option>";
													
										}
										mysqli_free_result($resultsp);            
							echo "</select></td>";
							  
							echo "<td>
							  <select required type=\"text\" id=\"sex".$j."\" class=\"form-control\" name=\"sex".$j."\">
								<option value=\"".htmlspecialchars($pass1['Gender'])."\" selected=\"selected\">".htmlspecialchars($pass1['Gender'])."</option>
							  </select></td>";
							  
							  echo "<input type=\"hidden\" id=\"rowno\" class=\"form-control\" name=\"rowno\" value=\"".$j."\"  />";		  
							 echo "<input type=\"hidden\" id=\"EntryNo".$j."\" class=\"form-control\" name=\"EntryNo".$j."\" value=\"".htmlspecialchars($pass1['EntryNo'])."\"  />";
							  
							 echo "<td>
			 <input required size=\"10%\" type=\"number\" min=\"1\" class=\"form-control\" name=\"no_of_an".$j."\" id=\"no_of_an".$j."\" value=\"".htmlspecialchars($pass1['NoAnimal'])."\" onchange=\"CheckAvail(this.value,".$j.")\" /><span id=\"avl$j\"></span></td>
							  <td><input required type=\"text\" id=\"age".$j."\" class=\"form-control\" name=\"age".$j."\" value=\"".htmlspecialchars($pass1['Weight_Age'])."\"  /></td>
							  
							</tr>"; 
							$j++;
							}
							
						?>
						</table>
					</div>
				</fieldset>
			</div>
			<div class="form-group">
			<fieldset>
			<legend>Edit disposal details </legend>
				<table class="table">
					  <tr>
						<td  ><strong>Reason for Disposal</strong></td>
						
						<td   > 
						<select required class="form-control" name="reason" id="reason" onchange="showOtherReason(this.value); ">
							<option selected="selected" value="<?php echo htmlspecialchars($pass['Reason']); ?>"><?php echo htmlspecialchars($pass['Reason']); ?></option> 
							<option value="Experimental End Point"> Experimental End Point </option>  
							<option value="Deviation in Parameter"> Deviation in Parameter </option>
							<option value="Disease Condition"> Disease Condition </option>                                        
							<option  value="other" > Other </option>
							</select> 
						 </td> 
						 </tr >
				
						<tr style="display:none" id="otherReason">
						<td>Other Reason </td>
						<td   ><input class="form-control" style="text-transform: capitalize;" pattern="[a-zA-Z ]*" id="oReason" name="oReason"  type="text" placeholder="Enter other"/> </td>
						</tr>
						
						<tr>
						<td  ><strong>Method of Euthanasia </strong></td>
						
						<td   > 
						<select required class="form-control" name="euthanasia" id="euthanasia" onchange="showOtherEuthanasia(this.value);">
								<option selected="selected" value="<?php echo htmlspecialchars($pass['Euthanasia']); ?>"><?php echo htmlspecialchars($pass['Euthanasia']); ?></option>  
								<option value="C02  Euthanasia"> C02  Euthanasia </option>  
								<option value="Overdose of Isoflurane"> Overdose of Isoflurane </option>
								<option value="Overdose of injectable Anesthesia"> Overdose of injectable Anesthesia </option>    
								<option  value="Cervical Dislocation" > Cervical Dislocation </option>                                    
								<option  value="other" > Other </option>
								</select> </td>
					  </tr>
					  <tr style="display:none" id="otherEuthanasia">
						<td>Other Euthanasia Method </td>	
						
						<td   ><input style="text-transform: capitalize;" pattern="[a-zA-Z ]*" id="oEuthanasia" class="form-control" name="oEuthanasia" type="text" placeholder="Enter other"/> </td>
						</tr>
						<tr>
						<td  ><strong>Disposal Date </strong></td>
						
						<td   > <input required id="reqdate" class="form-control" name="reqdate" type="date" value="<?php echo htmlspecialchars($pass['DisposeDate']); ?>" /> </td>
						 </tr>
						 
					</table>
			</fieldset>
		</div>
	
<!-- Add Task Button -->
	<div class="form-group">
	
		<div class="col-sm-offset-4 col-sm-6">
			<button type="submit" class="btn btn-danger">
				<i class="fa fa-btn fa-edit"></i> Edit
			</button>
			<button type="button" class="btn btn-warning" onclick="window.history.back()">
				<i class="fa fa-btn fa-arrow-left"></i> Back
			</button>
		</div>
	
	</div>
</form>
</div>
		
	<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
	</div>
	
</body>
</html>
<?php 
	}
}
?>