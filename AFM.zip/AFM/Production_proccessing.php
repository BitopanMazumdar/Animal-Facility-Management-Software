<?php include "include/sesionlauth.php"; ?>
<?php 

$pcode=filter_var($_POST['pcode'], FILTER_SANITIZE_STRING);
$species=filter_var($_POST['species'], FILTER_SANITIZE_STRING);
$strain=filter_var($_POST['strain'], FILTER_SANITIZE_STRING);
$stock=filter_var($_POST['stock'], FILTER_SANITIZE_STRING);
$qm=filter_var($_POST['qm'], FILTER_SANITIZE_STRING);
$qf=filter_var($_POST['qf'], FILTER_SANITIZE_STRING);
$pdate=filter_var($_POST['pdate'], FILTER_SANITIZE_STRING);

$bdate=filter_var($_POST['bdate'], FILTER_SANITIZE_STRING);
$wdate=filter_var($_POST['wdate'], FILTER_SANITIZE_STRING);
$genotype=filter_var($_POST['genotype'], FILTER_SANITIZE_STRING);
if($pcode=="Acquired"){
	$pcode=filter_var($_POST['scode'], FILTER_SANITIZE_STRING);
}
if($pcode!="" && $species!="" && $pdate!=""){
	include "DBconnect.php" ;

	$sql="INSERT INTO production(ProductionCode,Species,strain,StockType,MALE,Female,ProductionDate,BredDate,WeanDate,Genotype) values ('$pcode', '$species', '$strain', '$stock', '$qm', '$qf', '$pdate','$bdate','$wdate','$genotype')";

	$Result = mysqli_query($db, $sql);

	if(!$Result)
	  {
		
		$_SESSION['message']="Error ! Contact admin  !";
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=InventoryRegister.php">';
		die('Error: ' . mysqli_error($db));
	  }
	else
	{
		$_SESSION['message']="Successfully added production data  !";
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=InventoryRegister.php">';
	}
	mysqli_close($db);
}else{
	$_SESSION['message']="Invalid Input  ! Please enter data properly  !";
	echo '<META HTTP-EQUIV="Refresh" Content="0; URL=InventoryRegister.php">';
}

?>