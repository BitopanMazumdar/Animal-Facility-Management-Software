<?php include "include/sesionlauth.php"; ?>
 <?php
	  
	include "DBconnect.php";
	
	//$result = mysqli_query($db,"SELECT IndentNumber,Projectcode,RName,ARDate FROM indentform");
	$sql="SELECT IndentNumber,Projectcode,RName,ARDate FROM indentform WHERE (IndentNumber NOT IN(SELECT IndentNumber FROM responsenew) AND IndentNumber NOT IN(SELECT IndentNumber FROM Rejection)) ORDER BY IndentNumber DESC";
	$result = mysqli_query($db,$sql);
	if($result){
	$i=1;
	$str="<div class=\"panel-heading\">
				<h4 class=\"text-danger\"><i class=\"fa fa fa-exclamation-circle\"></i> Pending Animal Request</h4>
			</div>

			<div class=\"panel-body  table-responsive\" >
				<table class=\"table table-striped table-hover\">
					<thead>
						<th>S.No.</th>
						<th>Requested By</th>
						<th>Protocol</th>
						<th>Requested date</th>
						<th>Status</th>
						<th>&nbsp;</th>
						<th>&nbsp;</th>
					</thead>
					<tbody>";
	
			while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
				$projcode=$pass['Projectcode'];
				$status="Unknown";
				$sqlstatus="SELECT ToDate FROM projects WHERE ProjectCode ='$projcode'";
				$resultstatus = mysqli_query($db,$sqlstatus);
				$today = date("Y-m-d");
				if($resultstatus){
					if($passstatus=mysqli_fetch_array($resultstatus,MYSQLI_ASSOC))
					{
						$todate=$passstatus['ToDate'];
						if($todate >= $today)
						{
							$status="Active";
						}else{
							$status="Expired";
						}
					}
					
				}
				$str=$str."
						<tr>
							<td class=\"table-text\"><div>".$i."</div></td>
							<td class=\"table-text\"><div>".$pass['RName']."</div></td>
							<td class=\"table-text\"><div>".$pass['Projectcode']."</div></td>
							<td class=\"table-text\"><div>".$pass['ARDate']."</div></td>
							<td class=\"table-text\"><div class=\"text-danger\"\>".$status."</div></td>
							<!-- Task Delete Button -->
							<td>
								<form action=\"reply.php\" method=\"POST\">
									<input type=\"hidden\" name=\"pcode\" value=\"".$pass['Projectcode']."\">
									<input type=\"hidden\" name=\"inumber\" value=\"".$pass['IndentNumber']."\">
									<button type=\"submit\" class=\"btn btn-success\">
										<i class=\"fa fa-btn fa-check\"></i> Issue
									</button>
								</form>
							</td>
							<td>
								<form action=\"rejectv1.php\" method=\"POST\">
									<input type=\"hidden\" name=\"pcode\" value=\"".$pass['Projectcode']."\">
									<input type=\"hidden\" name=\"inumber\" value=\"".$pass['IndentNumber']."\">
									<button type=\"submit\" class=\"btn btn-danger\">
										<i class=\"fa fa-btn fa-close\"> </i> Reject
									</button>
								</form>
							</td>
						</tr>";
						$i++;
					}
					if ($i== 1){
						$str=$str. "<tr><td colspan=\"5\" class=\"table-text text-danger\"><div>*No Records found</div></td></tr>";
					}
					$str=$str."</tbody>
				</table>
			</div>
		</div>";
			
			echo $str;
			mysqli_free_result($result);
		}else{
			$_SESSION['message']="Error  ! Contact admin !";
				
		}

mysqli_close($db);
?>
			
					