<?php include "include/sesionlauth.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  <link rel="stylesheet" href="css/styles.css">
  
  
</head>
<body style="background-color:#F8F9FA">
	<nav >
		 <div class="container-fluid">
			<?php 
			include"include/headerboot.php"; 
			?>
		  </div>
		  <div class="container-fluid">
			<?php 
			include"include/MenuAi.php"; 
			?>		
		  </div> 
	</nav>
	<div>&nbsp;</div>
<script type="text/javascript">
$(document).ready(function(){
	$("#home").slideDown("slow");
	$("#note").slideDown("slow");	
});

</script>

	<div>&nbsp;</div>
	<div class="container" id="displaydiv" >
	<!-- submit message -->
			<?php 
					if(isset($_SESSION['message'])){
						echo "<div class=\"alert alert-danger\">Welcome ".htmlspecialchars($_SESSION['piname'])."  !</div>"; 
						unset($_SESSION['message']);
					}		
			?>
		<!-- submit message -->	
	<div class="text-center"><h4>Welcome To Animal Facility  Management Software</h4></div>
	<div>&nbsp;</div>
        <div class="col-sm-offset-1 col-sm-10">
			<div class="panel panel-default" >
                <div class="panel-heading text-center" style="background-color:#cfd8dc; color:black;">
                    <h5><strong>Note:</h5>
                </div>

                <div class="panel-body" style="background-color:#eceff1; color:black;">
                   <div  style="display:none" id="note">
				<table  style="width:98%" align="center" >		
					<tr >
						<td style="width:100%" >
								<p >1. Enter room and animal information first (using Add menu).</p>
		<p >2. Enter buyer and supplier information before sale and supply of animals (using Admin menu).</p>
		<p >3. Enter Principal investigator/in-charge details before entering protocol/form B information (using Add user menu).</p>
		<p >4. Add user to authorize person for using the system (using Add user menu).</p>
		<p >5. Contact Kuhipaat IT and IP service if you see contact admin message.</p> 
		
						</td>
						
					</tr>
			</table>
			</div>
                </div>
            </div>

			
            <div class="panel panel-default" >
                <div class="panel-heading text-center" style="background-color:#cfd8dc; color:black;">
                    <h5><strong>SOFLAM </strong>(Software For Laboratory Animal Management) Features:</h5>
                </div>

                <div class="panel-body" style="background-color:#eceff1; color:black;">
                   <div  style="display:none" id="home">
				<table  style="width:98%" align="center" >		
					<tr >
						<td style="width:100%" >
								<p >1. Maintaining the inventory of Experimental animals.</p>
		<p >2. Automating the animal indenting process.</p>
		<p >3. Easily and quickly generating Form C, D and E as per CPCSEA.</p>
		<p >4. Maintaining all records (Production, Mortality, Experiment, Treatment). </trong>related to animal health easily</p> 
		<p >5. Maintaining animal house parameters and interrelationship.</p>
		<p >6. Generating Insight of production, mortality and animal house parameter effect on animal health.</p> 
		<p >7. Reducing human data input errors by internal calculations.</p>
						</td>
						
					</tr>
			</table>
			</div>
                </div>
            </div>
			
			
		</div>
    </div>
	<div>&nbsp;</div><div>&nbsp;</div><div>&nbsp;</div><div>&nbsp;</div>
	<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
	</div>
</body>
</html> 
	 
	