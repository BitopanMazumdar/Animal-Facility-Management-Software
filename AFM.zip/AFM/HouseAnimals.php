<?php include "include/sesionlauth.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  <link rel="stylesheet" href="css/custom.css">
  
</head>
<body style="background-color:#F8F9FA">
<nav >
 <div class="container-fluid">
	<?php 
	include"include/headerboot.php"; 
	?>
  </div>
  <div class="container-fluid">
	<?php 
	include"include/MenuAi.php"; 
	?>		
  </div>
   
</nav>
	<div>&nbsp;</div>
<!-- Script start-->
<script type="text/javascript">
$(document).ready(function(){
		$("#displaydiv").slideDown("slow");
});
</script>
<script type="text/javascript">
function validate(){
	
	frm = document.myform;
	
	 if(frm.species.value =="")
	  {
			alert("Please enter Species! ");
			frm.species.focus();
			return false;
	  }
	    
}
</script>
<script type="text/javascript">

$(document).ready(function(){
		var xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = function() {
		  if (this.readyState == 4 && this.status == 200) {
			document.getElementById("viewdata").innerHTML = this.responseText;
			$("#viewdata").slideDown("slow");
		  }
		};
		
		xmlhttp.open("GET", "HAByAll.php", true);
		xmlhttp.send();
});
	
</script>
<script type="text/javascript">
function editSp(i){
		$("#editspecies"+i).hide();
		$("#editspecies"+i).slideDown("slow");
		$("#newspecies"+i).focus();
}

function New_Sp(i){ 
	 newsp= $("#newspecies"+i).val();
	 oldsp=$("#oldspecies"+i).val();
	 var patt = /[%*+,;<=>^]/;
	 
	if(patt.test(newsp)){
		alert("invalid input! special characters: %*+,;<=>^ are not allowed");
		return false;
	}else{
		if(newsp == ""){
			alert("Please Enter New species to edit !");
			$("#newspecies"+i).focus();
		}else{
			var xmlhttp = new XMLHttpRequest();
				xmlhttp.onreadystatechange = function() {
				  if (this.readyState == 4 && this.status == 200) {
					//document.getElementById("tdata").innerHTML = this.responseText;
					alert(this.responseText);
					location.reload(true);
				  }
				};
				
				xmlhttp.open("GET", "EditSpecies.php?newsp="+newsp+"&oldsp="+oldsp, true);
				xmlhttp.send();
		}
	}
}

</script>
<!-- Script end-->
<!-- body-->
<div class="container" id="displaydiv" >
<div class="col-sm-12">&nbsp;</div>
	<div class="col-sm-offset-2 col-sm-8">
		<div class="panel panel-default">
		
			<div class="panel-heading">
				Species Management
			</div>

			<div class="panel-body">
				
				<!-- New Task Form -->
				<form name="myform" action="HouseAnimals_proccessing.php" method="post" onSubmit="return validate();" class="form-horizontal">
					
					<!-- Task Name -->
					<div class="form-group">
						<label for="species" class="col-sm-3 control-label"><span style="color: red">*</span>Species Name:</label>
						<div class="col-sm-6">
							<input class="form-control" required name="species" type="text" id="species" />
						</div>
						
					</div>
					
					<!-- Add Task Button -->
					<div class="form-group">
						<div class="col-sm-offset-3 col-sm-6">
							<button type="submit" class="btn btn-default">
								<i class="fa fa-btn fa-plus"></i> Add Species
							</button>
						</div>
					</div>
				</form>
			</div>
		</div>
		
		
	</div>
	<div class="col-sm-offset-1 col-sm-10">
		<!-- submit message -->
			<?php 
				
					if(isset($_SESSION['message'])){
						echo "<div class=\"alert alert-danger\">".$_SESSION['message']."</div>"; 
						unset($_SESSION['message']);
					}						
			?>
		<!-- submit message -->
		<div id="viewdata" class="panel panel-default" style="display:none">
		
		</div>
		
	</div>
</div>
<div class="footer" >
		<?php 
			include"include/footerboot.php"; 
		?>
</div>			
</body>
</html>
