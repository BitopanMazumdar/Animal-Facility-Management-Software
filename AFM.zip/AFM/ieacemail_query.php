<?php include "include/sesionlauth.php"; ?>
<?php 
	include "DBconnect.php";
	
	$mailid=filter_var($_GET['mailid'], FILTER_SANITIZE_STRING);
$type=filter_var($_GET['type'], FILTER_SANITIZE_STRING);
$ttenure=filter_var($_GET['ttenure'], FILTER_SANITIZE_STRING);
//`iaecmember`(`Itype`, `IName`, `Ftenure`, `Ttenure`, `IEmail`, `IPhone`, `IMobile`, `IAddress`, `Ipin`)
	$result = mysqli_query($db,"SELECT DISTINCT IEmail FROM iaecmember WHERE IEmail='$mailid' AND Itype='$type' AND Ftenure='$ftenure' AND Ttenure='$ttenure' ");	
	$str = 0;
	if($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
		
		$str = 1;				
	}	
	echo $str;
	mysqli_free_result($result);
	mysqli_close($db);
		
	?>