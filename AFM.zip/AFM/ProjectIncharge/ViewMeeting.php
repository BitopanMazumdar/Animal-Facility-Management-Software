<?php include "include/sesionlauth.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  <link rel="stylesheet" href="css/custom.css">
  
</head>
<body style="background-color:#F8F9FA">
<nav >
 <div class="container-fluid">
	<?php 
	include"include/headerboot.php"; 
	?>
  </div>
  <div class="container-fluid">
	<?php 
	include"include/MenuPi.php"; 
	?>		
  </div>
   
</nav>

<!-- Script start-->
<script type="text/javascript">
 $(document).ready(function(){
	 $("#displaydiv").slideDown("slow");
	
});
</script>
<script type="text/javascript">
function showList()
{
	
	type=$('input:radio[name=type]:checked').val();
	var spe=$('#species').val();
	//alert(spe);
	vdate=$('#vdate').val();
	vdate1=$('#vdate1').val();
	if(type==1){
		if(spe==""){
			alert("Please select Meeting title");
			
		}else{
		//alert(type);
		//window.location='ExperimentByspst.php?page=ahreports&pg=expanmrep&type='+type+'&spe='+spe+'&str='+str+'';
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() {
			  if (this.readyState == 4 && this.status == 200) {
				  //alert("hi here");
				  document.getElementById("viewdata").innerHTML = this.responseText;
			$("#viewdata").slideDown("slow");
			$("#loader").hide();
			  }
			};
			//alert("ViewMeetingByTitle.php?dtype="+spe+"");
			xmlhttp.open("GET","ViewMeetingByTitle.php?dtype="+spe+"", true);
			xmlhttp.send();
		}
	}
	if(type==2)
	{
		if(vdate=="")
		{	alert("Select From date");}
		else if(vdate1=="")
		{	alert("Select To date");}
		else if (new Date(vdate) > new Date(vdate1)) 
		{	alert("To Date is not more than From date");}
		else{
			//window.location='ExperimentByDate.php?page=ahreports&pg=expanmrep&type='+type+'&sd='+vdate+'&sd1='+vdate1+'';
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() {
			  if (this.readyState == 4 && this.status == 200) {
				document.getElementById("viewdata").innerHTML = this.responseText;
			$("#viewdata").slideDown("slow");
			$("#loader").hide();
			  }
			};
			
			xmlhttp.open("GET", "ViewMeetingByDate.php?sd="+vdate+"&sd1="+vdate1, true);
			xmlhttp.send();
		}
	}

}


function checkType(val)
{
//alert(val);

$('input:radio[name=type]')[val].checked = true;
}
</script>
<script type="text/javascript">

$(document).ready(function(){
	
		$.get("MeetingTitleByAll.php", function(data, status){
		$("#species").html(data);
		
		});
		var xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = function() {
		  if (this.readyState == 4 && this.status == 200) {
			document.getElementById("viewdata").innerHTML = this.responseText;
			$("#viewdata").slideDown("slow");
			$("#loader").hide();
		  }
		};
		
		xmlhttp.open("GET", "ViewMeetingByAll.php", true);
		xmlhttp.send();
});

</script>

<!-- Script end-->
 <div>&nbsp;</div>
<div class="container" id="displaydiv" style="display:none">
        <div class="col-sm-offset-2 col-sm-8">
            <div class="panel panel-default">
                <div class="panel-heading">
                  <i class="fa fa-btn fa-file"></i>  Meeting Management
				  <!--<button type="button" class="btn btn-primary col-sm-offset-6" onClick="document.location.href='Cmeeting.php'">
						<i class="fa fa-btn fa-plus"></i> ADD Meeting
					</button> -->
                </div>

                <div class="panel-body">
                    <!-- submit message -->
						<?php 
								if(isset($_SESSION['message'])){
									echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
									unset($_SESSION['message']);
								}		
						?>
					<!-- submit message -->	

                    <!-- New Task Form -->
                    <form class="form-horizontal">
						<div class="row">
							<div class="radio col-sm-3">
							  <label>
          <input name="type" type="radio" value="1" checked>
         Meeting Title</label>
							</div>
							
							<div class="form-group col-sm-4">
								<select class="form-control" name="species" id="species" onFocus="checkType('0')">
								  <option value="">Select</option>
								 </select> 
							</div>
							
							<div class="form-group col-sm-5 sr-only">
								<label for="vdate1" class="col-sm-3 control-label">Strain:</label>
								<div class="col-sm-7">
									<select class="form-control" id="strain" name="strain">
									<option value="" selected="selected"> Select </option>
								</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="radio col-sm-3">
							  <label><input name="type" type="radio" value="2" >Date</label>
							</div>
							
							<div class="form-group col-sm-4">
								<label for="vdate" class="col-sm-3 control-label">From:</label>
								<div class="col-sm-6">
									<input class="form-control" style="width:10em;" type="date" name="vdate" id="vdate"  onfocus="checkType('1')" />
								</div>
							</div>
							
							<div class="form-group col-sm-4">
								<label for="vdate1" class="col-sm-3 control-label">To:</label>
								<div class="col-sm-6">
									<input class="form-control" style="width:10em;" type="date" name="vdate1" id="vdate1"  onfocus="checkType('1')" />
								</div>
							</div>
						</div>
						<div class="row">
							<div class="form-group">
								<div class="col-sm-offset-4 col-sm-6">
									
									<button type="button" onClick="showList()" class="btn btn-success">
										<i class="fa fa-btn fa-search"></i> Search
									</button>
								</div>
							</div>
						</div>
					</form>
                </div>
            </div>
		</div>
	</div>
	<div class="container">
        <div class="col-sm-offset-0 col-sm-12">
            <div id="viewdata" class="panel panel-default" style="display:none">
			<!-- load data-->	
			</div>
		</div>
		</div>
	</div>
    
	<div class="container" >
		<div id="loader" class="col-sm-offset-5 col-sm-7 loader">
		</div>
	</div>
	
	<div>&nbsp;</div><div>&nbsp;</div>
	<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
	</div>
	
</body>
</html>
