<?php include "include/sesionlauth.php"; ?>
 <?php 
	//session_start();
	
					
	include "DBconnect.php" ;
	
	$result = mysqli_query($db,"SELECT RoomName FROM rooms" );
	
	$str = "<option value=\"\"> select</option>";
	while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
		
		$str = $str . "<option value=\"".$pass['RoomName']."\">".$pass['RoomName']."</option>";
	}
	$str = $str .'<option value="Random">Random</option><option value="All">All</option>';
	
	echo $str;
	mysqli_free_result($result);
	mysqli_close($db);
		
	?>