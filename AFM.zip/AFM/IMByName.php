<?php include "include/sesionlauth.php"; ?>
  <?php 
	$uname = $_GET['uname'];	
			
	
	if($uname != ""){
		include "DBconnect.php";
		//iaecmember(Itype, IName, IEmail, IPhone, IMobile, IAddress, Ipin)
		$sql="SELECT Itype, IName, IEmail, IPhone, IMobile, IAddress, Ipin FROM iaecmember WHERE IName = '$uname' ";
		$result = mysqli_query($db,$sql);
		
		$i=1;
		$str="<tr><th width=\"4%\" bgcolor=\"#07A6E2\"><strong>S.No. </strong></th>
			<th width=\"10%\" bgcolor=\"#07A6E2\"><strong>Type </strong></th>
			<th width=\"20%\" bgcolor=\"#07A6E2\"><strong>Name </strong></th>
			<th width=\"15%\" bgcolor=\"#07A6E2\"><strong>Phone </strong></th>
			<th width=\"15%\" bgcolor=\"#07A6E2\"><strong>Mobile </strong></th>
			<th width=\"20%\" bgcolor=\"#07A6E2\"><strong>Email ID </strong></th>
			<th width=\"25%\" bgcolor=\"#07A6E2\"><strong>Address </strong></th>
			<th width=\"6%\" align=\"center\" bgcolor=\"#07A6E2\"><strong>Edit</strong></th>
			</tr>";
		
		while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){				
									
			$str=$str. "<tr>";
			$str=$str. "<td >";
			$str=$str. "<b>".$i."<b>";
			$str=$str. "</td>";
				
			$str=$str. "<td >";
			$str=$str. "<b>".$pass['Itype']. "<b>";
			$str=$str. "</td>";
			$str=$str. "<td >";
			$str=$str. "<b>".$pass['IName']. "<b>";
			$str=$str. "</td>";
			$str=$str. "<td >";
			$str=$str. "<b>".$pass['IPhone']. "<b>";
			$str=$str. "</td>";
			
			$str=$str. "<td >";
			$str=$str. "<b>".$pass['IMobile']."<b>";
			$str=$str. "</td>";
			$str=$str. "<td >";
			$str=$str. "<b>".$pass['IEmail']."<b>";
			$str=$str. "</td>";
			$str=$str. "<td >";
			$str=$str. "<b>".$pass['IAddress']." - ".$pass['Ipin']."<b>";
			$str=$str. "</td>";
			$str= $str. "<td align=\"center\" ><button id=\"newIMuser\" onclick=\"editIMuser(this.value)\" value=\"".$pass['IEmail']."\" style=\"width:5em; \" > edit </button> </td>";
				
			$str=$str. "</tr>";
			
			$i++;		 
		}
		if($i==1){
			$str=$str. "<tr ><td colspan=\"8\" class=\"norecord\">*No records found</td></tr>";
		}
		echo $str;
		mysqli_free_result($result);
		mysqli_close($db);
	}else{
			echo " <tr bgcolor=\" #9F5E45\"> <td colspan=\"8\" align=\"center\" ><strong> Pelease Enter Name! <strong></td></tr>";
	}
	?>