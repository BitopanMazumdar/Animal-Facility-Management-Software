<?php include "include/sesionlauth.php"; ?>
<?php 
	
	$fq= $_GET['fq'];
	$sp= $_GET['sp'];
	$st= $_GET['st'];
	$stock= $_GET['stock'];
	$value=-2; 
	
	include "DBconnect.php" ;
	if($st!=""){
		$result = mysqli_query($db,"SELECT Female FROM census WHERE Species='$sp' AND strain='$st' AND StockType='$stock'");
	}else{
		$result = mysqli_query($db,"SELECT Female FROM census WHERE Species='$sp' AND StockType='$stock'");
	}
	
   	                              
	if($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
				
		if($fq <= $pass['Female']){
			 $value=-1; 
		}else{
			$value=$pass['Female'];
		}		
	}
		
	echo $value;
	mysqli_free_result($result);
	mysqli_close($db);
		
?>