<?php 
if(session_id() == '' || !isset($_SESSION)) {
	// session isn't started
	session_start();
}

$e= filter_var($_POST['femail'], FILTER_SANITIZE_STRING);

if($e!=""){
	include "DBconnect.php";

	$sql="SELECT PiEmail,PiPasscode from projectincharge WHERE PiEmail='$e'";
	$result = mysqli_query($db,$sql);
	if($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
		
		$to_email = $pass['PiEmail'];
		//echo $to_email;
		$password_hash = rand(999, 99999);
		
		//insert into forgot 
		//INSERT INTO forgot_pass(emailId, tocken, created_at) VALUES
			$sql1="INSERT INTO forgot_pass(emailId, tocken) VALUES ('$to_email','$password_hash')";

			$result1 = mysqli_query($db, $sql1);
					
			if(!$result1)
			  {
				$_SESSION['message']="New mail not sent ! You may have old mail for reseting password  !"; 
				echo "<script> window.history.go(-1);</script>";
				//die('Error: ' . mysqli_error($db));
			  }else{
					$message="Password activation link: http://172.31.15.17/NBRC/newPass.php?email=$to_email&code=$password_hash";
					$message=$message."\n\n Click on the above link to create new password. \nNote: Activation link will be disabled after 24 hours.";
					//$message = "Use: ".$password."as password to generate new password\n";
					$subject="Recover Password";
					$headers = "From: ithylasco123@gmail.com";
					if(!mail($to_email,$subject,$message,$headers) ) {
						$_SESSION['message']="Not able to mail activation link, Contact Admin !"; 
						echo "<script> window.history.go(-1);</script>";
						//$error_message = 'Problem in Sending Password Recovery Email';
					 } else {
						$_SESSION['message']="Activation link is sent to your email, for reseting password ! Activation link will be disabled after 24 hours.";
						echo "<script> window.history.go(-1);</script>";	
						//echo "Activation link is sent to your email, for reseting password! ";
						//$success_message = 'Please check your email to reset password!';
					 }
			  }
		//echo $to_email; echo " hi "; echo $subject, $message, $headers;
		
		
	}else{
		$_SESSION['message']="User Does Not Exist !";
		echo "<script> window.history.go(-1);</script>";
	}

	mysqli_close($db);
}else{
	$_SESSION['message']="Invalid Email !";
	echo "<script> window.history.go(-1);</script>";
	//echo "<script>alert('Invalid Email !'); window.history.go(-1);</script>";
}
?>
