for($i=1; $i<=$rowno; $i++){
	if($strain[$i]!=""){
		$animal=$strain[$i];
	}elseif($species[$i]!=""){
		$animal=$species[$i];
	}else{
		//invalid data
	}
	if($qm[$i]!=""){
		$gender='Male';
		$sql2="INSERT INTO responseanimal(SPStrain, Gender, Weight_Age, NoAnimal) values ('$animal','$gender','age','$qm[$i]')";
	
		$result2 = mysqli_query($db, $sql2);
		if(!$result2)
		  {						
			$flag=0;
			$_SESSION['message']="Error ! Contact admin  !";
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=Supply.php">';
		  }
		else
		{
			$flag=1;
		}
	}
	//responseanimal(ResponseEntryId, ResponseNumber, SPStrain, Gender, Weight_Age, NoAnimal, IndentNumber)
	if($qf[$i]!=""){
		$gender='Female';
		$sql2="INSERT INTO responseanimal(SPStrain, Gender, Weight_Age, NoAnimal) values ('$animal','$gender','age','$qf[$i]')";
	
		$result2 = mysqli_query($db, $sql2);
		if(!$result2)
		  {						
			$flag=0;
			$_SESSION['message']="Error ! Contact admin  !";
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=Supply.php">';
		  }
		else
		{
			$flag=1;
		}
	}
	
}