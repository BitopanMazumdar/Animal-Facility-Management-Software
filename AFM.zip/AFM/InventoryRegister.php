<?php include "include/sesionlauth.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  <link rel="stylesheet" href="css/custom.css">
  
</head>
<body style="background-color:#F8F9FA">
<nav >
 <div class="container-fluid">
	<?php 
	include"include/headerboot.php"; 
	?>
  </div>
  <div class="container-fluid">
	<?php 
	include"include/MenuAi.php"; 
	?>		
  </div>
  <div class="container-fluid">
	<?php 
	include"include/inventorynav.php"; 
	?>		
  </div>
 
</nav>

<!-- Script start-->
<script type="text/javascript">
 $(document).ready(function(){
	 $("#main").slideDown("slow");
	    
	/*$.get("Buyer_query.php", function(data, status){
		$("#bname").html(data);
		
	}); */
	//alert("in sup");
	$.get("Supplier_query.php", function(data, status){
		$("#scode").html(data);
		
	});
});

function changeMode(val)
{
if(val==0)
{
/*$("#inst").removeAttr("disabled");
$("#iname").attr("disabled","disabled");
$("#pcode").attr("disabled","disabled");*/

//$("#stock").hide();
$("#scodeh").show(); 

}
else
{

$("#scodeh").hide();
$("#stock").show();
}
}
</script>

<script type="text/javascript">
function valid(){
	frm = document.myform;
	
	  if(frm.pcode.value =="")
	  {
			alert("Please select Project Code ! ");
			frm.pcode.focus();
			return false;
	  }
	  if(frm.pcode.value!="In House")
	{	
			if(frm.scode.value ==""){
			alert("Please select supplier Code ! ");
			frm.scode.focus();
			return false;}
	  }
	  
	  if(frm.species.value =="" && frm.strain.value =="" )
	  {
			alert("Please enter Species/Strain !");
			frm.species.focus();
			return false;
	  }
	  /*if(frm.strain.value =="")
	  {
			alert("Please enter Password !");
			frm.strain.focus();
			return false;
	  }
	  */
	  
	  if(frm.pcode.value=="In House" && frm.stock.value =="")
	  {
			alert("Please select Stock type !");
			frm.stock.focus();
			return false;
	  }
	  
	   if(frm.pdate.value =="")
	  {
			alert("Please enter Production date !");
			frm.pdate.focus();
			return false;
	  }
	 if(frm.qm.value =="" && frm.qf.value =="" )
	  {
			alert("Please enter Male/Female quantity !");
			frm.qm.focus();
			return false;
	  }
	  
	 var r = confirm("confirm submit!");
	  if (r == true) {
		return true;
	  } else {
		frm.rname.focus();
		return false
	  }
	  
}
</script>		
 
<script type="text/javascript">

$(document).ready(function(){
  	$.get("species_query.php", function(data, status){
	$("#species").html(data);
	
	});
});

</script>
<script type="text/javascript">
function getStrain(val){
	
	$.get("strain_query.php", {sp:val}, function(data, status){
		
    $("#strain").html(data);
    });
}	
</script>
 
<div class="container" id="main" style="display:none">
<br>
<!-- submit message -->
	<?php 
		
		if(isset($_SESSION['message'])){
			echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
			unset($_SESSION['message']);
		}
								
	?>
<!-- submit message -->
<form action="Production_proccessing.php" name="myform" method="post" onsubmit="return valid();">
<br>
	<button type="button" class="btn btn-danger col-sm-offset-6" onClick="document.location.href='InventoryReports.php'"><i class="fa fa-btn fa-plus"></i> View Production Report
					</button>
	<div class="form-group" id="box">
	<fieldset>
		<legend>Production details</legend>
		<label class="control-label" for="">Production Type<span id="red">*</span>:</label>			  
		<div class="radio">
			<label onclick="changeMode(1)">
				<input name="pcode" id="pcode" type="radio" value="In House" checked="checked" />In House 
			</label>
			<label  onclick="changeMode(0)">
		  <input name="pcode" id="pcode" type="radio" value="Acquired" />
		  Acquired</label>
		</div>
		<label class="control-label"   for="bdate">Breeding Date<span id="red">*</span>:</label>
			<input class="form-control" required name="bdate" type="date" id="bdate" />	
		<label class="control-label"   for="pdate">Delivery Date<span id="red">*</span>:</label>
			<input class="form-control" required name="pdate" type="date" id="pdate" />
		<label class="control-label"   for="wdate">Weaning Date<span id="red">*</span>:</label>
			<input class="form-control" required name="wdate" type="date" id="wdate" />			
		<div id="scodeh" style="display:none;">
		<label class="control-label" for="scode">Supplier Code<span id="red">*</span>:</label>
			<select class="form-control" name="scode" type="text" id="scode">
				<option value="">Select</option>
						
			</select>
		</div>
	</fieldset>
	</div>
	<div class="form-group" id="box">
	<fieldset>
		
		<label class="control-label" for="species">Species Name<span id="red">*</span>:</label>
			<select class="form-control" required name="species" id="species" onchange="getStrain(this.value);">
				<option value="">Select</option>
			 </select>    
		<label class="control-label"   for="strain">Strain Name<span id="red">*</span>:</label>
			<select class="form-control" id="strain" name="strain">
				<option value=""> select </option>
			</select>
		<label class="control-label"   for="genotype">Genotype<span id="red">*</span>:</label>
			<select class="form-control" id="genotype" name="genotype">
				<option value=""> select </option>
				<option value="Inbred"> Inbred </option>
				<option value="Outbred"> Outbred </option>
			</select>
		<label class="control-label"   for="stock">Stock Type<span id="red">*</span>:</label>
			<select class="form-control" required  name="stock" id="stock">
				<option value="">Select</option>
				<option value="Breeding Pair">Breeding Pair</option>
				<option value="Issue Stock">Issue Stock</option>
			</select>
			
			
	</fieldset>
	</div>
	<div class="form-group">
	<fieldset>
	<legend>Quantity</legend>
		<label class="control-label"   for="qm">Male<span id="red">*</span>:</label>
			<input class="form-control" name="qm" type="number" id="qm"  pattern="[0-9]"  min="1" />
		<label class="control-label"   for="qf">Female<span id="red">*</span>:</label>
			<input class="form-control" name="qf" type="number" id="qf"  pattern="[0-9]" min="1" />

	</fieldset>
	</div>
	<!-- Add Task Button -->
	<div class="form-group">
	
		<div class="col-sm-offset-4 col-sm-6">
			<button type="submit" class="btn btn-danger">
				<i class="fa fa-btn fa-plus"></i> Add Production
			</button>
			<button type="button" class="btn btn-warning" onclick="window.history.back()">
				<i class="fa fa-btn fa-arrow-left"></i> Back
			</button>
		</div>
	
	</div>
</form>
</div>
		
	<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
	</div>
	
</body>
</html>
