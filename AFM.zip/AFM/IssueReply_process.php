<?php include "include/sesionlauth.php"; ?>
 <?php 

$inum=filter_var($_POST['inum'], FILTER_SANITIZE_STRING);
$ResponseNumber=filter_var($_POST['pc'], FILTER_SANITIZE_STRING);
//=filter_var($_POST['ResponseNumber'], FILTER_SANITIZE_STRING);

//animal specification
$rowno= filter_var($_POST['rowno'], FILTER_SANITIZE_STRING); 

for($i=1; $i<=$rowno; $i++){
	$SPStrain[$i]=filter_var($_POST['strain'.$i], FILTER_SANITIZE_STRING);
	$gender[$i]=filter_var($_POST['sex'.$i], FILTER_SANITIZE_STRING);
	$age[$i]=filter_var($_POST['age'.$i], FILTER_SANITIZE_STRING);
	$stock[$i]= filter_var($_POST['stock'.$i], FILTER_SANITIZE_STRING);
	//$iso[$i]=filter_var($_POST['iso'.$i], FILTER_SANITIZE_STRING);
	$noa[$i]=filter_var($_POST['isno'.$i], FILTER_SANITIZE_STRING);
	$ResponseEntryId[$i]=filter_var($_POST['ResponseEntryId'.$i], FILTER_SANITIZE_STRING);
}
$flag=1;
if($ResponseEntryId[1]!="" && $noa[1]!="" && $ResponseNumber!=""){
	include "DBconnect.php";
	$query1="UPDATE responsenew SET issued=1 WHERE ResponseNumber= '$ResponseNumber'" ;
		mysqli_query($db,$query1);
			$result1 = mysqli_affected_rows($db);
			if($result1< 0){
				$flag=0;
				
			}
	//responseanimal(ResponseEntryId, ResponseNumber, SPStrain, Gender, Weight_Age, NoAnimal, IndentNumber)
	for($i=1; $i<=$rowno; $i++){
		$query="UPDATE responseanimal SET NoAnimal='$noa[$i]' WHERE ResponseEntryId= '$ResponseEntryId[$i]'" ;
		mysqli_query($db,$query);
			$result = mysqli_affected_rows($db);
			if($result< 0){
				$flag=0;
				
			}else{
				/*finding corresponding species or strain*/
	$sql1="Select DISTINCT strain FROM animals WHERE strain='$SPStrain[$i]'";
	$res1 = mysqli_query($db, $sql1);
	$species="";
	$strain=$SPStrain[$i];
	if(!$res1){
		$_SESSION['message']="Error ! Contact admin  !";
			//echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=Issue.php\">";
			die('Error: ' . mysqli_error($db));
	}else{
		
		if($pass1=mysqli_fetch_array($res1,MYSQLI_ASSOC)){
			$strain=$SPStrain[$i];
			/*finding male female quantity from census*/
			$sql2="Select  Male, Female FROM census WHERE strain='$strain' AND StockType='$stock[$i]'";
			$res2 = mysqli_query($db, $sql2);
			
			if(!$res2){
				$flag=0;
				$_SESSION['message']="Error ! Contact admin  !";
					//echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=Issue.php\">";
					die('Error: ' . mysqli_error($db));
			}else{
				if($pass2=mysqli_fetch_array($res2,MYSQLI_ASSOC)){
					$malquantity=$pass2['Male'];
					$femalquantity=$pass2['Female'];
					if($gender[$i]=='Male'){
						$malquantity=$malquantity-$noa[$i];
						$queryCen="UPDATE census SET Male='$malquantity' WHERE strain='$strain' AND StockType='$stock[$i]'" ;
						mysqli_query($db,$queryCen);
							$resultCen = mysqli_affected_rows($db);
							if($resultCen< 0){
								$flag=0;				
							}
							
					}
					if($gender[$i]=='Female'){
						$femalquantity=$femalquantity-$noa[$i];
						$queryCen2="UPDATE census SET Female='$femalquantity' WHERE strain='$strain' AND StockType='$stock[$i]'" ;
						mysqli_query($db,$queryCen2);
							$resultCen2 = mysqli_affected_rows($db);
							if($resultCen2< 0){
								$flag=0;				
							}
							
					}
				}
				
			}
		}else{
			echo 'in update census species';
			$species=$SPStrain[$i];
			/*finding male female quantity from census*/
			$sql2="Select  Male, Female FROM census WHERE Species='$species' AND StockType='$stock[$i]'";
			$res2 = mysqli_query($db, $sql2);
			
			if(!$res2){
				$flag=0;
				$_SESSION['message']="Error ! Contact admin  !";
					//echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=Issue.php\">";
					die('Error: ' . mysqli_error($db));
			}else{
				if($pass2=mysqli_fetch_array($res2,MYSQLI_ASSOC)){
					$malquantity=$pass2['Male'];
					$femalquantity=$pass2['Female'];
					if($gender[$i]=='Male'){
						$malquantity=$malquantity-$noa[$i];
						$queryCen="UPDATE census SET Male='$malquantity' WHERE Species='$species' AND StockType='$stock[$i]'"  ;
						mysqli_query($db,$queryCen);
							$resultCen = mysqli_affected_rows($db);
							if($resultCen< 0){
								$flag=0;				
							}
					}
					if($gender[$i]=='Female'){
						$femalquantity=$femalquantity-$noa[$i];
						$queryCen2="UPDATE census SET Female='$femalquantity' WHERE Species='$species' AND StockType='$stock[$i]'" ;
						mysqli_query($db,$queryCen2);
							$resultCen2 = mysqli_affected_rows($db);
							if($resultCen2< 0){
								$flag=0;				
							}
					}
				}
				
			}
		}
	}
			}
	}
	if($flag==1){
		$_SESSION['message']="Successfully saved animal delivery record !";
		//echo '<META HTTP-EQUIV="Refresh" Content="0; URL=Issue.php">';
	}else{
		$_SESSION['message']="Error, Contact Admin  !";
		//echo '<META HTTP-EQUIV="Refresh" Content="0; URL=Issue.php">';
	}	
		mysqli_close($db);
	
}else{
	$_SESSION['message']="Error, Invalid input  !";
	//echo '<META HTTP-EQUIV="Refresh" Content="0; URL=Issue.php">';
}
?>