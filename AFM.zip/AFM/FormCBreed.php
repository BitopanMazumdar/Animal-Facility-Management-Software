<?php include "include/sesionlauth.php"; ?>
 <?php 

	/*<td width=\"15%\" align=\"center\" bgcolor=\"#CCCCCC\">Stock Type </td>
	<td width=\"17%\" align=\"center\" bgcolor=\"#CCCCCC\">Production Type </td>
	Date species sex age (Animals acquired Name, Address and date) */
	$str="<div class=\"panel-heading\">
				<button type=\"button\" class=\"btn btn-danger\" onclick=\"javascript:printDiv('printdiv')\" ><i class=\"fa fa-btn fa-print\"></i> Print</button>
				<span class=\"text-primary\" >&nbsp;&nbsp;&nbsp;&nbsp;	Form C data</span>
			</div>

			<div class=\"panel-body  table-responsive\" id=\"printdiv\">
				<table class=\"table table-bordered table-hover\">
				<caption class=\"text-success\"><strong>Breed (In house)</strong></caption>
				<tr>
				<th width=\"17%\" align=\"center\" bgcolor=\"#CCCCCC\">Date</th>
				<th width=\"25%\" align=\"left\" bgcolor=\"#CCCCCC\">Species</th>
				<th width=\"30%\" align=\"left\" bgcolor=\"#CCCCCC\">Strain</th>
				<th width=\"13%\" align=\"center\" bgcolor=\"#CCCCCC\">Male </th>
				<th width=\"13%\" align=\"center\" bgcolor=\"#CCCCCC\">Female</th>
				</tr>
				<tbody>";
	include "DBconnect.php";
		//production(ProductionNo, ProductionCode, Species, strain, StockType, MALE, Female, ProductionDate)
		
		$query2= "SELECT * FROM production WHERE ProductionCode ='In house' ORDER BY ProductionDate DESC";
		$result2 = mysqli_query($db,$query2);
		$i=1;
		
		if($result2){
		
		while($pass2=mysqli_fetch_array($result2,MYSQLI_ASSOC)){
			$str=$str."<tr ><td>".$pass2['ProductionDate']."</td>";
			//$str=$str."<td >".$pass2['ProductionCode']."</td>";
			$str=$str."<td >" .$pass2['Species']. "</td>";
			$str=$str. "<td >" .$pass2['strain']. "</td>";
			//$str=$str. "<td >".$pass2['StockType']. "</td>";
			$str=$str."<td >".$pass2['MALE']."</td>";
			$str=$str."<td >".$pass2['Female']."</td></tr>";
			$i++; 
		}
		if ($i== 1){
						$str=$str. "<tr><td colspan=\"8\" class=\"table-text text-danger\"><div>*No Records found</div></td></tr>";
					}	
				
				mysqli_free_result($result2);
			}else{
				$str=$str. "<tr><td colspan=\"8\" class=\"table-text text-danger\"><div>*Error, Contact Admin.</div></td></tr>";
			}
			$str=$str."</tbody>
			</table>
		</div>
	</div>";
	echo $str;
	mysqli_close($db);
				
	?>