<?php include "include/sesionlauth.php"; ?>

<?php 

$fdate=filter_var($_POST['fdate'], FILTER_SANITIZE_STRING); 
$room=filter_var($_POST['room'], FILTER_SANITIZE_STRING);
$durt=filter_var($_POST['durt'], FILTER_SANITIZE_STRING);
$fdbye=filter_var($_POST['fdby'], FILTER_SANITIZE_STRING);

if($room!=""){
	include "DBconnect.php" ;

	$sql="INSERT INTO fumigationregister(FumigationDate,RoomNo,Duration,FumigationBy) values ('$fdate', '$room', '$durt','$fdbye')";

	$Result = mysqli_query($db, $sql);

	if(!$Result)
	  {
		$_SESSION['message']="Error, Contact admin  !";
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=RoomFumigation.php">';
		die('Error: ' . mysqli_error($db));
	  }
	else
	{
		$_SESSION['message']="Successfully submitted  !";
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=RoomFumigation.php">';
	}
	mysqli_close($db);
}else{
	$_SESSION['message']="Error, Invalid input  !";
	echo '<META HTTP-EQUIV="Refresh" Content="0; URL=RoomFumigation.php">';
}
?>
