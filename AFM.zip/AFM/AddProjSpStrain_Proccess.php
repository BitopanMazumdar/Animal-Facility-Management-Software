<?php include"include/sesionlauth.php"; ?>
<?php 

//session_start();
$pcode=$_POST['prcode'];
$rowno= $_POST['row_no'];

for($i=1; $i<=$rowno; $i++){

$strain[$i]=$_POST['strain'.$i];
$gender[$i]=$_POST['sex'.$i];
$age[$i]=$_POST['age'.$i];
$issueyear[$i]=$_POST['issueyear'.$i];
//$iso[$i]=$_POST['iso'.$i];
$noa[$i]=$_POST['no_of_an'.$i];
}
$flag=1;
if($pcode!=""){
	include "DBconnect.php";
			
		for($i=1; $i<=$rowno; $i++){
			$sql2="INSERT INTO projectanimal (ProjectCode,SpStrain, Gender,Weight_Age,NoAnimal, IssueYear) values ('$pcode','$strain[$i]','$gender[$i]', '$age[$i]', '$noa[$i]', '$issueyear[$i]')";
			$result2 = mysqli_query($db, $sql2);
			if(!$result2)
			  {	
				$flag=0;
				$_SESSION['message']="Could not update data: contact admin";
				echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=Projects.php\">";
				die('Error: ' . mysqli_error($db));
			  }
			
		}
		if($flag==1){
			$_SESSION['message']="Successfully Added new animal !";
			echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=Projects.php\">";
			
		}else{
			$_SESSION['message']="Could not update data properly : contact admin !";
			echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=Projects.php\">";
		}
	mysqli_close($db);
}else{
	$_SESSION['message']="Invalid input data !";
}
?>
