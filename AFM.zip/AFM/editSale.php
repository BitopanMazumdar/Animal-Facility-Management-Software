<?php include "include/sesionlauth.php"; ?>
<?php 

$SaleID= htmlspecialchars($_POST['saleno']);
$EntrySaleNumber=htmlspecialchars($_POST['EntrySaleNumber']);

if($SaleID!=""){
include"DBconnect.php";
	////fsale(SaleID, Saledate, Scode, Bcode, IEACdate, IAECno, BillNo) 
	$result = mysqli_query($db,"SELECT DISTINCT Saledate, Scode, Bcode, IEACdate, IAECno, BillNo FROM fsale WHERE SaleID ='$SaleID'");
	if($result){
		if($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
				
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  <link rel="stylesheet" href="css/custom.css">
  
</head>
<body style="background-color:#F8F9FA">
<nav >
 <div class="container-fluid">
	<?php 
	include"include/headerboot.php"; 
	?>
  </div>
  <div class="container-fluid">
	<?php 
	include"include/MenuAi.php"; 
	?>		
  </div>
   
</nav>

<!-- Script start-->
<script type="text/javascript">
$(document).ready(function(){
		$("#main").slideDown("slow");
});
</script>
<script type="text/javascript">
function getStrain(val,no)
{
	
$.get("strain_query.php",
  {
    sp:val
  },
  function(data,status){
  //sleep(1000);
 
    $("#strain"+no).html(data);
    //$("#strain"+no).css("width":"150px");
  });
}

$(document).ready(function(){
   $("#addRow").click(function(){   
   val=$("#row_no").val();
   if(val!=7)
   {
   val++;
   
    $("#row_no").val(val);
    $("#row"+val).slideDown();
    $("#close"+val).show();
    val--;
    $("#close"+val).hide();
    }
  }); 
	 
});

function getBuyeradd(bname){
	
$.get("BuyerAdd_query.php",
  {
    bnam:bname
  },
  function(data,status){
      $("#add").val(data); 
	   $("#baddh").show();
	  });
$.get("BuyerPin_query.php",
  {
    bnam:bname
  },
  function(data,status){
      $("#pin").val(data); 
	 	 $("#bpinh").show();  
	  });
}

function Close(val)
{

 $("#row"+val).slideUp();
 val--;
 $("#row_no").val(val);
 $("#close"+val).show("slow");
 }
 
 

function changeMode(val)
{
if(val==0)
{
$("#inst").removeAttr("disabled");
$("#iname").attr("disabled","disabled");
$("#pcode").attr("disabled","disabled");
}
else
{
$("#iname").removeAttr("disabled");
$("#pcode").removeAttr("disabled");
$("#inst").attr("disabled","disabled");
}
}
</script>

<script type="text/javascript">     
        
    $(document).ready(function(){
	   
});
</script>

<!-- Validation-->


<script type="text/javascript">
function valid(){
	frm = document.myform;
	no=$("#row_no").val();
		
	  if(frm.sdate.value ==""){
			alert("Please enter sale date !");
			frm.sdate.focus();
			return false;
	  }
	  if(frm.bname.value ==""){
			alert("Please Select Buyer Code !");
			frm.bname .focus();
			return false;
	  }
	  /* if(frm.add.value =="")
	  {
			alert("Please enter Address !"); 
			frm.add.focus();
			return false;
	  }
	  if(frm.pin.value =="")
	  {
			alert("Please enter Pin !");
			frm.pin.focus();
			return false;
	  }*/
	   if(frm.bname.value =="New")
	  {
			alert("Please Register the buyer First!"); 
			//window.location.href="AnimalBuyer.php";
			return false;
	  }
	  if(frm.sname.value =="")
	  {
			alert("Please select Supplier Code !"); 
			frm.sname.focus();
			return false;
	  }
	  
	   if(frm.sname.value =="New")
	  {
			alert("Please Register the Supplier First !"); 
			//window.location.href="AnimalBuyer.php";
			return false;
	  }
	/*  if(frm.idate.value =="")
	  {
			alert("Please enter Date of the protocols against which animals sold!");
			frm.idate.focus();
			return false;
	  }
	  if(frm.iaecno.value =="")
	  {
			alert("Please enter IAEC No. of the protocols against which animals sold!");
			frm.iaecno.focus();
			return false;
	  } */
	  for(j=1;j<=no;j++)
		{
					
		  if(document.getElementById("strain" + j).value =="" && document.getElementById("species" + j).value =="")
		  {
				alert("Please enter species/starin !");
				document.getElementById("species" + j).focus();
				return false;
		  }
		  
		   if(document.getElementById("stock" + j).value =="")
		  {
				alert("Please specify Stock Type !");
				document.getElementById("stock" + j).focus();
				return false;
		  }		  
		  if(document.getElementById("qm" + j).value =="0" && document.getElementById("qf" + j).value =="0")
		  {
				alert("Please specify MALE or Female quantity, both cannot be zero.");
				document.getElementById("qm" + j).focus();
				return false;
		  }	 
		 		  
		}
		var flag=0;
		var r=false;
		for(j=1;j<=no;j++)
		{
			if(document.getElementById("strain" + j).value =="")
			  {
				  alert("Reminder: You have not selected Strain for row no. = "+j);
				  document.getElementById("strain" + j).focus();
				  flag=1;
			  }
		}
	  if(flag){
		  r=confirm("Confirm submission without selecting Strain !");
	  }else{
		  r=confirm("Confirm submission !");
	  }
	  if(r==true ){
		  return true;
	  }else{
		  return false;
	  }
	  
}
function malenumber(quantity,no){
	sp=$("#species"+no).val();
	st=$("#strain"+no).val();
	stock=$("#stock"+no).val();
	if(sp==""){
		alert("please select Species");
		$("#qm"+no).val(0);
		return false;
	}
	if(stock==""){
		alert("please select Stock Type");
		$("#qm"+no).val(0);
		return false;
	}
	$.get("checkmalenumber.php",{mq:quantity, sp:sp, st:st, stock:stock}, function(data, status){
		//alert(data);
		if(data==-1){
			return true;
		}else if(data==-2){
			$("#qm"+no).val(0);
			alert("stock not available in animal house! Species: "+sp+" Strain: "+st +" Stock Type: "+stock);
			return false;
		}else{
			$("#qm"+no).val(0);
			alert("Quantity is more than available stock! Available stock = "+data);
			return false;
			
		}
	});
}
function femalenumber(quantity,no){
	sp=$("#species"+no).val();
	st=$("#strain"+no).val();
	stock=$("#stock"+no).val();
	if(sp==""){
		alert("please select Species");
		$("#qf"+no).val(0);
		return false;
	}
	if(stock==""){
		alert("please select Stock Type");
		$("#qf"+no).val(0);
		return false;
	}
	$.get("checkfemalenumber.php",{fq:quantity, sp:sp, st:st, stock:stock}, function(data, status){
		//alert(data);
		if(data==-1){
			return true;
		}else if(data==-2){
			$("#qm"+no).val(0);
			alert("stock not available in animal house! Species: "+sp+" Strain: "+st +" Stock Type: "+stock);
			return false;
		}else{
			$("#qm"+no).val(0);
			alert("Quantity is more than available stock! Available stock = "+data);
			return false;
			
		}
	});
}
</script>	
<script type="text/javascript">
function CheckDuplicate(no)
{
	z=$("#row_no").val();
	for(x=1;x<=z;x++)
	{	
		if(x!=no)
		{
				
			if(($("#species"+x).val()==$("#species"+no).val()) && ($("#strain"+x).val()==$("#strain"+no).val()) && ($("#stock"+x).val()==$("#stock"+no).val())){
				$("#strain"+no).val("");
				$("#species"+no).val("");
				$("#stock"+no).val("");				
				alert("Species,Strain and stock type allready selected");
			}
				
		}
	}
}
</script>	
<!-- End of validation -->

<!-- Script end-->
 
<div class="container" id="main" style="display:none">
<br>
<!-- submit message -->
	<?php 
		
		if(isset($_SESSION['message'])){
			echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
			unset($_SESSION['message']);
		}
								
	?>
<!-- submit message -->
<form action="EditFormE_proccess.php" name="myform" method="post" onsubmit="return valid();">
<br>
	
	<div class="form-group" id="box">
	<fieldset>
		<legend>Sale details</legend>
		<label class="control-label"  for="sdate">Sale Date<span id="red">*</span>:</label>
			<input class="form-control" name="sdate" type="date" id="sdate" size="15" required value="<?php echo htmlspecialchars($pass['Saledate']); ?>" />
		<label class="control-label" for="mdate">Bill No<span id="red">*</span>:</label>
			<input  class="form-control" pattern="[0-9A-Za-z/\\ -]*" name="billno" type="text" id="billno" size="15" required value="<?php echo htmlspecialchars($pass['BillNo']); ?>" />
		
	</fieldset>
	</div>
	<div class="form-group" id="box">
	<fieldset>
		<legend>Buyer</legend>
		<label class="control-label" for="species">Buyer Code<span id="red">*</span>:</label>
			<select class="form-control" required  name="bname" type="text" id="bname" onchange="getBuyeradd(this.value)" required>
			  <option value="<?php echo htmlspecialchars($pass['Bcode']); ?>"><?php echo htmlspecialchars($pass['Bcode']); ?></option>
			  <?php 
				
				$str="";	
				$resultbuy = mysqli_query($db,"SELECT DISTINCT BCode FROM anbuyer");
				
				while($passbuy=mysqli_fetch_array($resultbuy,MYSQLI_ASSOC)){
					
					$str = $str ."<option value=\"".htmlspecialchars($passbuy['BCode'])."\">".htmlspecialchars($passbuy['BCode'])."</option>";
							
				}
				echo $str;
				mysqli_free_result($resultbuy);				
					
				?>		
		  </select>  
	
	<div id="baddh" style="cursor:pointer; display:none;">
	
		<label class="control-label" for="strain">Buyer Address:</label>
			<textarea class="form-control" name="add" readonly="true" type="text" id="add" rows="2" ></textarea>
		<label class="control-label" for="stock">Buyer pin<span id="red">*</span>:</label>
			<input  class="form-control" name="pin" readonly="true" type="text" id="pin" size="10" />	
	</fieldset>
	</div>
	<div class="form-group">
	<fieldset>
	<legend>Suplier</legend>
		<label class="control-label" for="qm">Supplier Code<span id="red">*</span>:</label>
			<select class="form-control" required  name="sname" type="text" id="sname" required>
				<option value="<?php echo htmlspecialchars($pass['Scode']); ?>"><?php echo htmlspecialchars($pass['Scode']); ?></option>
				<?php 

				$resultsup = mysqli_query($db,"SELECT DISTINCT SCode FROM ansupplier");

				$str="";
				while($passsup=mysqli_fetch_array($resultsup,MYSQLI_ASSOC)){

					$str = $str ."<option value=\"".htmlspecialchars($passsup['SCode'])."\" >".htmlspecialchars($passsup['SCode'])."</option>";
				}

				echo $str;
				mysqli_free_result($resultsup);

				?>          
			</select>
		<label class="control-label" for="qf">IAEC Date<span id="red">*</span>:</label>
			<input  class="form-control" name="idate"  type="date" id="idate" required value="<?php echo htmlspecialchars($pass['IEACdate']); ?>" />
		<label class="control-label" for="qf">IAEC No.<span id="red">*</span>:</label>
			<input  class="form-control" name="iaecno" type="text" id="iaecno" size="15" pattern="[0-9A-Za-z/\\ -]*" required  value="<?php echo htmlspecialchars($pass['IAECno']); ?>" />
		
	</fieldset>
	</div>
	<div class="form-group">
	<fieldset>
	<legend>Animal details</legend>
		<div class="table-responsive">
		<?php 
			$str="<table class=\"anspecification\" width=\"70%\" border=\"0\" align=\"center\" cellpadding=\"5\" cellspacing=\"1\">
			<input type=\"hidden\" id=\"inum\" class=\"form-control\" name=\"inum\" value=\"".$SaleID."\"  />";

			//INSERT INTO sanimal(EntrySaleNumber, SaleID, Species, strain, StockType, MALE, Female) 
			$result1 = mysqli_query($db,"SELECT Species, strain, StockType, MALE, Female FROM sanimal WHERE EntrySaleNumber='$EntrySaleNumber' ");
			$j=1;
			$str=$str."<input type=\"hidden\" id=\"rowno\"  class=\"form-control\" name=\"rowno\" value=\".$j.\" />
			<tr id=\"row1\"  >
				<th  width=\"15%\"  align=\"center\" ><strong> Species </strong></th>
				<th  width=\"15%\"  align=\"center\" ><strong>Strain</strong></th>
				<th   width=\"15%\" align=\"center\" ><strong>Stock Type </strong></th>
				<th  width=\"20%\" align=\"center\" ><strong>Male</strong></th>
				<th width=\"20%\" align=\"center\" ><strong>Female</strong></th>
			</tr>";
			
			echo $str;		  
			while($pass1=mysqli_fetch_array($result1,MYSQLI_BOTH)){
				echo "<input type=\"hidden\" id=\"row_no\"  class=\"form-control\" name=\"row_no\" value=\"".$j."\" />
				<input type=\"hidden\" id=\"rowno\" class=\"form-control\" name=\"rowno\" value=\"".$j."\"  />
				<input type=\"hidden\" id=\"EntryNo".$j."\" class=\"form-control\" name=\"EntryNo".$j."\" value=\"".$EntrySaleNumber."\"  />
				<tr  id=\"row1\">
				<td align=\"center\"><select required  id=\"species".$j."\" class=\"form-control\" name=\"species".$j."\" onchange=\"getStrain(this.value,".$j.")\" required >
				<option value=\"".htmlspecialchars($pass1['Species'])."\" selected=\"selected\">".htmlspecialchars($pass1['Species'])."</option>";
				$resultsp = mysqli_query($db,"SELECT DISTINCT Species FROM animals");
				while($passsp=mysqli_fetch_array($resultsp,MYSQLI_ASSOC)){
					echo "<option value=\"".htmlspecialchars($passsp['Species'])."\">".htmlspecialchars($passsp['Species'])."</option>";
				}
				mysqli_free_result($resultsp);            
				echo " </select>
				</td>
				<td align=\"center\" id=\"selstrain1\"><select id=\"strain".$j."\" class=\"form-control\" name=\"strain".$j."\">
				<option value=\"".htmlspecialchars($pass1['strain'])."\" selected=\"selected\">".htmlspecialchars($pass1['strain'])."</option>
				</select></td>

				<td width=\"12%\" align=\"center\">
				<select required  id=\"stock".$j."\" class=\"form-control\" name=\"stock".$j."\" required>
				<option value=\"".htmlspecialchars($pass1['StockType'])."\" selected=\"selected\">".htmlspecialchars($pass1['StockType'])."</option>
				<option value=\"2\">Breeding Pair</option>
				<option value=\"1\">Issue Stock</option>
				</select>            </td>
				<td align=\"center\"><input class=\"form-control\" name=\"qm".$j."\" type=\"number\"  min=\"0\"  id=\"qm".$j."\"  onchange=\"malenumber(this.value,1);\" value=\"".htmlspecialchars($pass1['MALE'])."\"/></td>
				<td align=\"center\"><input class=\"form-control\" name=\"qf".$j."\" type=\"number\"  min=\"0\"  id=\"qf".$j."\"  onchange=\"femalenumber(this.value,1);\" value=\"".htmlspecialchars($pass1['Female'])."\" /></td>

				</tr>";
			}
			echo "</table>";
			//echo $str;
			?>
		</div>
	</fieldset>
	</div>
	<!-- Add Task Button -->
	<div class="form-group">
	
		<div class="col-sm-offset-4 col-sm-6">
			<button type="submit" class="btn btn-danger">
				<i class="fa fa-btn fa-edit"></i> Edit Sale
			</button>
			<button type="button" class="btn btn-warning" onclick="window.history.back()">
				<i class="fa fa-btn fa-arrow-left"></i> Back
			</button>
		</div>
	
	</div>
</form>
</div>
		
	<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
	</div>
	
</body>
</html>
<?php 
		}
	}else{
		$_SESSION['message']="Edit Error, Contact Admin  !";
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=SaleReport.php">';
	}
}else{
	$_SESSION['message']="Edit Error, Invalid input data  !";
	echo '<META HTTP-EQUIV="Refresh" Content="0; URL=Sale.php">';
}
?>