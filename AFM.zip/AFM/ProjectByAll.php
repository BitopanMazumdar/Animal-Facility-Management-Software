<?php include "include/sesionlauth.php"; ?>

<?php 
					
	include "Dbconnect.php";
	
	$result = mysqli_query($db,"SELECT Projectcode,ProjectName, PrincipalInvestigator,ToDate FROM projects");
	//$pass = mysqli_fetch_array($result);
	$i=1;
	if($result){
			$str="<div class=\"panel-heading\">
                        <h4 class=\"text-primary\"><i class=\"fa fa-archive\"></i> Protocol Management <button type=\"button\" class=\"btn btn-success col-sm-offset-5\" onClick=\"document.location.href='Addproject.php'\">
						<i class=\"fa fa-btn fa-plus\"></i>ADD New Protocol
					</button> </h4>
                    </div>

                    <div class=\"panel-body  table-responsive\" >
                        <table class=\"table table-striped table-hover\">
                            <thead>
                                <th>S.No.</th>
								<th>Protocol No.</th>
								<th>Title</th>
								<th>Incharge</th>
								<th>Status</th>
                                <th>&nbsp;</th>
                            </thead>
                            <tbody>";
	
		
	while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){	
		$todate=$pass['ToDate'];
		$today = date("Y-m-d");
		$status="unknown";
		if($todate >= $today)
		{
			$status="Active";
		}else{
			$status="Expired";
		}
		$str=$str."
						<tr>
							<td class=\"table-text\"><div>".$i."</div></td>
							<td class=\"table-text\"><div>".$pass['Projectcode']."</div></td>
							<td class=\"table-text\"><div>".$pass['ProjectName']."</div></td>
							<td class=\"table-text\"><div>".$pass['PrincipalInvestigator']."</div></td>
							<td class=\"table-text\"><div class=\"text-danger\">".$status."</div></td>
							<!-- Task Delete Button -->
							<td>
								<form action=\"EditProject.php\" method=\"POST\">
									<input type=\"hidden\" name=\"prno\" value=\"".$pass['Projectcode']."\">
									<button type=\"submit\" class=\"btn btn-danger\">
										<i class=\"fa fa-btn fa-edit\"></i>Edit
									</button>
								</form>
							</td>
						</tr>";
						$i++;
					}
					if ($i== 1){
						$str=$str. "<tr><td colspan=\"2\" class=\"table-text text-danger\"><div>*No Records found</div></td></tr>";
					}
					$str=$str."</tbody>
				</table>
			</div>
		</div>";
		
		echo $str;
		mysqli_free_result($result);
	}else{
		$_SESSION['message']="Error  ! Contact admin !";
			
	}
		
	?>

<!-- end of query/php -->