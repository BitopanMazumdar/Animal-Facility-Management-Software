<?php //include "include/sesionlauth.php"; ?>
 
<?php 
	if(session_id() == '' || !isset($_SESSION)) {
		// session isn't started
		session_start();
	}

	$type=$_POST['type'];
	$name=$_POST['name'];
	$e=$_POST['email'];
	$phone=$_POST['phone'];
	$mobile=$_POST['mb'];
	$dg=$_POST['dg'];
	$dpt=$_POST['dpt'];
	$ex=$_POST['ex'];
	$add=$_POST['add']; 
	$pin=$_POST['pin'];
	$pass=$_POST['pass'];
	$p=sha1($pass);
	/*
	if(isset($_SESSION['pie'])){
	  $pie=$_SESSION['pie'];
	  
	}else{
		header("Location: index.php", true, 301);
		exit();
	} */
	//first registration

	if($e!="" && $p !==""){
		include "DBconnect.php";

		$sql= "INSERT INTO projectincharge(Piname,PiDesignation,PiDepartment,Piphone,Pimobile,PiEmail,PiExperience, PiPasscode,Role,PiAddress,Pin,created_at,updated_at,author) values ('$name','$dg','$dpt','$phone','$mobile','$e','$ex','$p','$type','$add','$pin',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,'soflam')";

		$result = mysqli_query($db,$sql);


		if(!$result)
		  {
			//echo "<script>alert('Database error, contact admin  !'); window.history.go(-1);</script>";
			$_SESSION['message']="Database error, contact admin  !";
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=registrationBoot.php">';
			die('Error: ' . mysqli_error($db));
		  }
		else
		{
			$_SESSION['message']="Registration successful !";
			//echo '<META HTTP-EQUIV="Refresh" Content="0; URL=index.php">';
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=index.php">';
		}
		mysqli_close($db);
	}else{
		//echo "<script>alert('Invalid Email !'); window.history.go(-1);</script>";
		
		$_SESSION['message']="Invalid Email !";
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=registrationBoot.php">';
	}
	
?>
