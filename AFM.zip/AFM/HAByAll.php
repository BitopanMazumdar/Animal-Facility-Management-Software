<?php include "include/sesionlauth.php"; ?>
 <?php 
	include "Dbconnect.php";
	$result = mysqli_query($db,"SELECT DISTINCT Species FROM animals");
	if($result){
	$str="<div class=\"panel-heading\" id=\"rempbdiv\">
							Member Details
						</div>

						<div class=\"panel-body table-responsive\">
							<table class=\"table table-striped task-table\">
								<thead>
									<th>Sl. No.</th>
									<th>Species Name</th>
									<th>View Strains</th>
									<th class=\"remOnPrint\">&nbsp;</th>								
								</thead>
								<tbody>";
		
	$i=1;
	while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
		$str=$str."
			<tr>
				<td class=\"table-text\"><div>".$i."</div></td>
				<td class=\"table-text\"><div>".$pass['Species']."</div></td>						
				<td class=\"table-text\"><div><a href="."AddStrain.php?species=".str_replace (' ', '%20',$pass['Species']).">Add Strain</a></div></td>
				
				<!-- Task Delete Button -->
				<td class=\"remOnPrint\">
					
						<input type=\"hidden\" readonly name=\"oldspecies$i\" id=\"oldspecies$i\" value=\"".$pass['Species']."\">
						<button onclick=\"editSp($i)\" value=\"".$pass['Species']."\" class=\"btn btn-danger\">
							<i class=\"fa fa-btn fa-edit\"></i>Edit
						</button>
															
				</td>
				<td>
					<div style=\"display:none;\" id=\"editspecies$i\">
						<input name=\"newspecies$i\" type=\"text\" id=\"newspecies$i\" />
						<button  name=\"newbtnspecies\" id=\"newbtnspecies\" onclick=\"New_Sp($i);\" class=\"btn btn-primary\">
							<i class=\"fa fa-btn fa-edit\"></i> Submit
						</button>	
					</div>
				</td>
			</tr>";	
			$i++;		 
		}
		if ($i==1){
			$str=$str."<tr><td colspan=\"4\" class=\"table-text text-danger \"><div>No Records found.</div></td></tr>";								
		}
		$str=$str."</tbody>
	</table>
                    
                </div>";
				
			echo $str;
		
		mysqli_free_result($result);
	}else{
		$_SESSION['message']="Error  ! contact admin";
		echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=HouseAnimals.php\">";
	}
	mysqli_close($db);
	
		
	?>