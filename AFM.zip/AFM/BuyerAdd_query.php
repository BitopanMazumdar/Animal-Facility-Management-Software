<?php include "include/sesionlauth.php"; ?>
<?php 
	//session_start();
	
	$bnam = $_GET['bnam'];
	if($bnam!=""){					
	include "DBconnect.php";
	//`animalbuyer`(`BCode`, `Bname`, `BRegNum`, `BAddress`, `Bpin`, `Bphone`, `Bmobile`, `BEmail`)
	$result = mysqli_query($db,"SELECT DISTINCT BAddress FROM anbuyer WHERE BCode = '$bnam'" );
	
	$str = "";
	if($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
		
		$str = $pass['BAddress'];
		
	}
	echo $str;
	mysqli_free_result($result);
	mysqli_close($db);
	}else{
		//echo"Select buyer code!"
	}	
	?>