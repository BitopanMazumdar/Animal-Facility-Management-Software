<?php include "include/sesionlauth.php"; ?>
 <?php 
 session_start();

  $pie=$_SESSION['pie'];
  $piname=$_SESSION['piname'];
  echo $piname;
  include "DBconnect.php";	
	$result = mysqli_query($db,"SELECT ProjectCode FROM projects WHERE PiEmail='$pie'");
	
	$str = "<option value=\"\">Select</option>";
	while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
		
		$str = $str . "<option value=\"".$pass['ProjectCode']."\">".$pass['ProjectCode']."</option>";
		
	}
	echo $str;
	mysqli_free_result($result);
	mysqli_close($db);
 
 ?>