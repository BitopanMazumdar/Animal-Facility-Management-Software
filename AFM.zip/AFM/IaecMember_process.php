<?php include "include/sesionlauth.php"; ?>

<?php 
$type=$_POST['type'];
$ftenure=$_POST['ftenure'];
$ttenure=$_POST['ttenure'];
	$name=$_POST['name'];
	$e=$_POST['email'];
	$phone=$_POST['phone'];
	$mobile=$_POST['mb'];
	$add=$_POST['add']; 
	$pin=$_POST['pin'];
	
	
if($e!=""){
	include "DBconnect.php";
	 
	//INSERT INTO iaecmember(Itype, IName, Ftenure, Ttenure, IEmail, IPhone, IMobile, IAddress, Ipin) VALUES
	$sql= "INSERT IGNORE INTO iaecmember(Itype, IName, Ftenure, Ttenure, IEmail, IPhone, IMobile, IAddress, Ipin) VALUES ('$type','$name', '$ftenure','$ttenure','$e','$phone','$mobile','$add','$pin')";

	$result = mysqli_query($db,$sql);


		if(!$result){
			
			$_SESSION['message']="Database error, contact admin  !";
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=IaecMember.php">';
			die('Error: ' . mysqli_error($db));
		}else{
				$_SESSION['message']="successful saved  !";
				
				echo '<META HTTP-EQUIV="Refresh" Content="0; URL=IaecMember.php">';
		}
	mysqli_close($db);
}else{
				
		$_SESSION['message']="Invalid Email !";
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=IaecMember.php">';
	}
?>
