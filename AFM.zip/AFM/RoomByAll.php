<?php include "include/sesionlauth.php"; ?>
 <?php 
	include "Dbconnect.php";
	$result = mysqli_query($db,"SELECT RoomName FROM rooms ORDER BY RoomName" );
	if($result){
	$str="<div class=\"panel-heading\" id=\"rempbdiv\">
							Room List
						</div>

						<div class=\"panel-body table-responsive\">
							<table class=\"table table-striped task-table\">
								<thead>
									<th>Sl. No.</th>
									<th>Room Name</th>
									
									<th class=\"remOnPrint\">&nbsp;</th>								
								</thead>
								<tbody>";
		
	$i=1;
	while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
		$str=$str."
			<tr>
				<td class=\"table-text\"><div>".$i."</div></td>
				<td class=\"table-text\"><div>".$pass['RoomName']."</div></td>						
								
				<!-- Task Delete Button -->
				<td class=\"remOnPrint\">
					
						<input type=\"hidden\" readonly name=\"oldname$i\" id=\"oldname$i\" value=\"".$pass['RoomName']."\">
						<button onclick=\"editRoom($i)\" class=\"btn btn-danger\">
							<i class=\"fa fa-btn fa-edit\"></i>Edit
						</button>
						
															
				</td>
				<td>
					<div style=\"display:none;\" id=\"editrm$i\">
						<input   name=\"newrname$i\" type=\"text\" id=\"newrname$i\" />
						<button  onclick=\"NewRoomName($i);\" class=\"btn btn-primary\">
							<i class=\"fa fa-btn fa-edit\"></i> Submit
						</button>	
					</div>
				</td>
			</tr>";	
			$i++;		 
		}
		if ($i==1){
			$str=$str."<tr><td colspan=\"3\" class=\"table-text text-danger \"><div>No Records found.</div></td></tr>";								
		}
		$str=$str."</tbody>
		</table>
                    
                </div>";
				
			echo $str;
		
		mysqli_free_result($result);
	}else{
		$_SESSION['message']="Error  ! contact admin";
		echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=HouseRooms.php\">";
	}
	mysqli_close($db);
	
		
	?>