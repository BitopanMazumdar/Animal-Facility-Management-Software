$projcode=$pass['Projectcode'];
				$status="Unknown";
				$sqlstatus="SELECT ToDate FROM projects WHERE ProjectCode ='$projcode'";
				$resultstatus = mysqli_query($db,$sqlstatus);
				$today = date("Y-m-d");
				if($resultstatus){
					if($passstatus=mysqli_fetch_array($resultstatus,MYSQLI_ASSOC))
					{
						$todate=$passstatus['ToDate'];
						if($todate >= $today)
						{
							$status="Active";
						}else{
							$status="Expired";
						}
					}
					
				}
				
	<td class=\"table-text\"><div class=\"text-danger\"\>".$status."</div></td>			