<?php include "include/sesionlauth.php"; ?>
<?php 

$gdate=filter_var($_POST['gdate'], FILTER_SANITIZE_STRING);
$species=filter_var($_POST['species'], FILTER_SANITIZE_STRING);
$strain=filter_var($_POST['strain'], FILTER_SANITIZE_STRING);
$sex=filter_var($_POST['sex'], FILTER_SANITIZE_STRING);
$ano=filter_var($_POST['ano'], FILTER_SANITIZE_STRING);
$dob=filter_var($_POST['dob'], FILTER_SANITIZE_STRING);
$sdbye=filter_var($_POST['sdby'], FILTER_SANITIZE_STRING);
$room=filter_var($_POST['room'], FILTER_SANITIZE_STRING);


if($room!="" && $gdate!=""){
	include "DBconnect.php" ;

	$sql="INSERT INTO geneticmonitoring(GCollectionDate,Species,strain,Gender,AnimalNo, DOB,GCollectedBy,RoomNo) values ('$gdate', '$species', '$strain', '$sex', '$ano','$dob','$sdbye','$room')";

	$Result = mysqli_query($db, $sql);

	if(!$Result)
	  {
		$_SESSION['message']="Error, Contact admin  !";
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=GeneticSampling.php">';
		die('Error: ' . mysqli_error($db));
	  }
	else
	{
		$_SESSION['message']="Successfully saved  !";
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=GeneticSampling.php">';
	}
	mysqli_close($db);
}else{
	$_SESSION['message']="Error, Invalid input  !";
	echo '<META HTTP-EQUIV="Refresh" Content="0; URL=GeneticSampling.php">';
}
?>
