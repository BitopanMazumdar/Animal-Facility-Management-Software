<?php $db=mysqli_connect("localhost", "root", "jaya182b", "nbrc");
if(!$db)
{
	echo "Failed to connect to MySQL: " . mysqli_connect_error();
	exit;
}
?>jaya182b