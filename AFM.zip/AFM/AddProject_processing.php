<?php include "include/sesionlauth.php"; ?>

<?php 

$pcode=$_POST['code'];
$pname=$_POST['name'];
$pi=$_POST['pi'];
$doa=$_POST['doa'];
$idoa=$_POST['idoa'];
$dfrom=$_POST['dfrom'];
$dto=$_POST['dto'];
$remark=$_POST['remark'];
$piemail=$_POST['email'];
$rowno= $_POST['row_no'];

//echo "I m here........";
//echo $rowno;
for($i=1; $i<=$rowno; $i++){
	/*${'species'.$i} =$_POST[{'species'.$i}]; 
	
	${'strain'.$i}=$_POST[{'strain'.$i}];
	${'gender'.$i}=$_POST[{'sex'.$i}];
	${'age'.$i}=$_POST[{'age'.$i}];
	${'iso'.$i}=$_POST[{'iso'.$i}];
	${'noa'.$i}=$_POST[{'no_of_an'.$i}]; */
	
	
$strain[$i]=$_POST['strain'.$i];
$gender[$i]=$_POST['sex'.$i];
$age[$i]=$_POST['age'.$i];
$issueyear[$i]=$_POST['issueyear'.$i];
$noa[$i]=$_POST['no_of_an'.$i];
}
$flag=0;

	include "DBconnect.php";  
	//INSERT INTO projects(ProjectCode, ProjectName, PrincipalInvestigator, ApprovalDate, FromDate, ToDate, PiEmail, created_at, updated_at, author) VALUES
			$sql1="INSERT INTO projects(ProjectCode, ProjectName, PrincipalInvestigator, ApprovalDate, FromDate, ToDate, PiEmail, created_at, updated_at, author, IeacApprove, Remarks) values ('$pcode', '$pname', '$pi', '$doa', '$dfrom', '$dto','$piemail',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,'$pie','$idoa','$remark')";

			$result1 = mysqli_query($db, $sql1);
			
			if(!$result1)
			  {
				$flag=0;
				$_SESSION['message']="Error ! Contact admin  !";
				echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=AddProject.php\">";
				die('Error: ' . mysqli_error($db));
			  }
			  else{

				for($i=1; $i<=$rowno; $i++){
					$sql2="INSERT INTO projectanimal (ProjectCode,SpStrain, Gender,Weight_Age,NoAnimal, IssueYear) values ('$pcode','$strain[$i]','$gender[$i]', '$age[$i]', '$noa[$i]', '$issueyear[$i]')";
					$result2 = mysqli_query($db, $sql2);
					if(!$result2)
					  {	
						$_SESSION['message']="Error ! Contact admin  !";
						echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=AddProject.php\">";
						die('Error: ' . mysqli_error($db));
					  }
					else
					{
						$flag=1;
					}
				}
			  }
			
		if($flag==1){
				$_SESSION['message']="Succesfully submitted  !";
				echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=AddProject.php\">";
			  
		}
		else{
			$sql3="DELET FROM projects WHERE ProjectCode=$code";

			$result3 = mysqli_query($db, $sql3);
			
			if(!$result3)
			  {
				$_SESSION['message']="Error ! Contact admin  !";
				echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=AddProject.php\">";
				die('Error: ' . mysqli_error($db));
			  }
			 $_SESSION['message']="Error ! Contact admin  !";
			echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=AddProject.php\">";
		}

mysqli_close($db);

?>
