<?php 
if(session_id() == '' || !isset($_SESSION)) {
	// session isn't started
	session_start();
}

$e=filter_var($_POST['email'], FILTER_SANITIZE_STRING);

$pass=filter_var($_POST['pass'], FILTER_SANITIZE_STRING);


if($pass!="" && $e!=""){
	$p=sha1($pass);
	include "DBconnect.php";
		
	$query="UPDATE projectincharge SET PiPasscode='$p' WHERE PiEmail='$e'" ;
	mysqli_query($db,$query);
		$result = mysqli_affected_rows($db);
		if($result>=0){
			/*delete tocken
			$querydel="DELETE FROM forgot_pass WHERE emailId='$e'" ;
			$resultdel = mysqli_query($db,$querydel);
			if(!$resultdel){
				
				$_SESSION['message']="tocken problem, contact admin !";
				echo '<META HTTP-EQUIV="Refresh" Content="0; URL=index.php">';
			}else{
				$_SESSION['message']="Successfully reset !";
				echo '<META HTTP-EQUIV="Refresh" Content="0; URL=index.php">';
			}*/
			$_SESSION['message']="Successfully reset !";
				echo '<META HTTP-EQUIV="Refresh" Content="0; URL=index.php">';
			
		}else{
			$_SESSION['message']="Error, Contatct admin !";
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=index.php">';
		}
		mysqli_close($db);
	

}else{
	$_SESSION['message']="Invalid email or password, reset password failed !";
	echo "<script> window.history.go(-1);</script>";
}