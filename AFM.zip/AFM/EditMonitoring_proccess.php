<?php include "include/sesionlauth.php"; ?>
 <?php 

$EntryNumber=filter_var($_POST['EntryNumber'], FILTER_SANITIZE_STRING);
$room=filter_var($_POST['room'], FILTER_SANITIZE_STRING);
$edate=filter_var($_POST['edate'], FILTER_SANITIZE_STRING);
$time=filter_var($_POST['time'], FILTER_SANITIZE_STRING);
$emin=filter_var($_POST['emin'], FILTER_SANITIZE_STRING);
$emax=filter_var($_POST['emax'], FILTER_SANITIZE_STRING);
$havg=filter_var($_POST['havg'], FILTER_SANITIZE_STRING); 
$lintensity=filter_var($_POST['lintensity'], FILTER_SANITIZE_STRING); 
$av=filter_var($_POST['av'], FILTER_SANITIZE_STRING);
$sound=filter_var($_POST['sound'], FILTER_SANITIZE_STRING);


//EntryNumber,RoomNo, EntryDate, EntryTime, MinTemperature, MaxTemperature, Humidity, Lintensity, Avelocity, Sound FROM temperature"

if($EntryNumber!=""){
	include "DBconnect.php";
	
	$query="UPDATE temperature SET RoomNo='$room', EntryDate='$edate', EntryTime='$time', MinTemperature='$emin', MaxTemperature='$emax', Humidity='$havg', Lintensity='$lintensity', Avelocity='$av', Sound='$sound' WHERE EntryNumber= '$EntryNumber'" ;
	mysqli_query($db,$query);
		$result = mysqli_affected_rows($db);
		if($result>=0){
			$_SESSION['message']="Successfully edited";
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=MonitoringReports.php">';
		}else{
			$_SESSION['message']="Error, Contact admin";
				echo '<META HTTP-EQUIV="Refresh" Content="0; URL=MonitoringReports.php">';
		}
		
		mysqli_close($db);
	
}else{
	$_SESSION['message']="Error, Invalid input  !";
	echo '<META HTTP-EQUIV="Refresh" Content="0; URL=MonitoringReports.php">';
}