<?php include "include/sesionlauth.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Production Data</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  
</head>
<body style="background-color:#F8F9FA">
	<nav >
		 <div class="container-fluid">
			<?php 
			include"include/headerboot.php"; 
			?>
		  </div>
		  <div class="container-fluid">
			<?php 
			include"include/MenuAi.php"; 
			?>		
		  </div>
			<div class="container-fluid">
				<?php 
				include"include/invRepMenu.php"; 
				?>		
			  </div>		  
	</nav>
	
 <!-- srcipt strat -->
<script type="text/javascript">
$(document).ready(function(){
$("#displaydiv").slideDown("slow");
$.get("species_query.php", function(data, status){
$("#species").html(data);

});
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function() {
	  if (this.readyState == 4 && this.status == 200) {
		document.getElementById("viewdata").innerHTML = this.responseText;
		$("#viewdata").slideDown("slow");
		$("#loader").hide();
	  }
	};
	
	xmlhttp.open("GET", "InventoryByAll.php", true);
	xmlhttp.send();
});
function getStrain(val1){
	
	
	$.get("strain_query.php", {sp:val1}, function(data, status){
		
    $("#strain").html(data);
    });
	return true;
}	
</script>
	<script type="text/javascript">
function showList()
{
	$("#viewdata").hide();
	type=$('input:radio[name=type]:checked').val();
	spe=$('#species').val();
	str=$('#strain').val();
	vdate=$('#vdate').val();
	vdate1=$('#vdate1').val();
	if(type==1){
		if(spe=="" && str==""){
			alert("Select Species/Strain");
		}else{
			//window.location='InventoryByspst.php?page=ahreports&pg=prodrep&type='+type+'&vspecies='+spe+'&vstrain='+str+'';
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() {
			  if (this.readyState == 4 && this.status == 200) {
				document.getElementById("viewdata").innerHTML = this.responseText;
				$("#viewdata").slideDown("slow");
				$("#loader").hide();
			  }
			};
			
			xmlhttp.open("GET", "InventoryByspst.php?vspecies="+spe+"&vstrain="+str,true);
			xmlhttp.send();
		}
	}																												
	if(type==2)
	{
		if(vdate=="")
		{	alert("Select From date");}
		else if(vdate1=="")
		{	alert("Select To date");}
		else if (new Date(vdate) > new Date(vdate1)){ 
			alert("To aate must be greater than From date");
		}
		else {
				//window.location='viewbydate.php?page=ahreports&pg=prodrep&type='+type+'&sd='+vdate+'&sd1='+vdate1+'';
				var xmlhttp = new XMLHttpRequest();
				xmlhttp.onreadystatechange = function() {
				  if (this.readyState == 4 && this.status == 200) {
					  //alert("in by date");
					document.getElementById("viewdata").innerHTML = this.responseText;
					$("#viewdata").slideDown("slow");
					$("#loader").hide();
				  }
				};
				
				xmlhttp.open("GET", "InventoryByDate.php?sd="+vdate+"&sd1="+vdate1, true);
				xmlhttp.send();
			}
	}

}

function checkType(val)
{

$('input:radio[name=type]')[val].checked = true;
return true;
}

</script>
<script type="text/javascript">
function printDiv() {
        //Get the HTML of whole page
        var oldPage = document.body.innerHTML;
        //remove unwanted elements
		
		$("th").remove(".remOnPrint");
		$("td").remove(".remOnPrint");
		//$("#rempbdiv").remove(); 
		//Reset the page's HTML with div's HTML only
		//Get the HTML of div
        var divElements = document.getElementById('printdiv').innerHTML; 
        //alert(divElements);
		var htmlToPrint = '' +
        '<style type="text/css">' +
        'table th, table td {' +
        'border:1px solid black;' +
        'padding;0.5em;' +
        '}' +'table thead {'+'border:1px solid black; background-color:#F8F9FA;'+'}'+
        '</style>';
        document.body.innerHTML = 
          "<html><head><title>All Client List</title>" +  htmlToPrint+"</head><body>" + divElements + "</body></html>";
        //Print Page
        window.print();
        //Restore orignal HTML
        document.body.innerHTML = oldPage;

    }
</script>
 <!-- srcipt end -->
<div>&nbsp;</div>
<div class="container" id="displaydiv" >
        <div class="col-sm-offset-2 col-sm-8">
            <div class="panel panel-default">
                <div class="panel-heading">
				   <span class="text-primary">Production Management<button type="button" class="btn btn-danger col-sm-offset-6" onClick="document.location.href='InventoryRegister.php'"><i class="fa fa-btn fa-plus"></i> ADD Production 
					</button></span>
                </div>

                <div class="panel-body">
                    <!-- submit message -->
						<?php 
								if(isset($_SESSION['message'])){
									echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
									unset($_SESSION['message']);
								}		
						?>
					<!-- submit message -->	

                    <!-- New Task Form -->
                    <form class="form-horizontal">
						<div class="row">
							<div class="radio col-sm-3">
							  <label><input  name="type" type="radio" value="1" checked>Species</label>
							</div>
							
							<div class="form-group col-sm-4">
								<select class="form-control" name="species" id="species" onfocus="checkType('0');" onchange="getStrain(this.value);">
									<option value="">Select</option>
								 </select> 
							</div>
							
							<div class="form-group col-sm-5">
								<label for="vdate1" class="col-sm-3 control-label">Strain:</label>
								<div class="col-sm-7">
									<select class="form-control" id="strain" name="strain">
									<option value="" selected="selected"> Select </option>
								</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="radio col-sm-3">
							  <label><input name="type" type="radio" value="2" >Date</label>
							</div>
							
							<div class="form-group col-sm-4">
								<label for="vdate" class="col-sm-3 control-label">From:</label>
								<div class="col-sm-6">
									<input class="form-control" style="width:10em;" type="date" name="vdate" id="vdate"  onfocus="checkType('1')" />
								</div>
							</div>
							
							<div class="form-group col-sm-4">
								<label for="vdate1" class="col-sm-3 control-label">To:</label>
								<div class="col-sm-6">
									<input class="form-control" style="width:10em;" type="date" name="vdate1" id="vdate1"  onfocus="checkType('1')" />
								</div>
							</div>
						</div>
						<div class="row">
							<div class="form-group">
								<div class="col-sm-offset-4 col-sm-6">
									
									<button type="button" onClick="showList()" class="btn btn-success">
										<i class="fa fa-btn fa-search"></i> Search
									</button>
								</div>
							</div>
						</div>
					</form>
                </div>
            </div>
		</div>
	</div>
	<div class="container-fluid">
        <div class="col-sm-offset-0 col-sm-12">
            <div id="viewdata" class="panel panel-default" style="display:none">
			<!-- load data-->	
			</div>
		</div>
		</div>
	</div>
    
	<div class="container" >
		<div id="loader" class="col-sm-offset-5 col-sm-7 loader">
		</div>
	</div>
	
	<div>&nbsp;</div><div>&nbsp;</div>
	<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
	</div>
	
</body>
</html>