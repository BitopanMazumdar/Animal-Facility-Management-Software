<?php include "include/sesionlauth.php"; ?>
 <?php
	$str="<div class=\"panel-heading\">
				<h4 class=\"text-danger\"><i class=\"fa fa fa-exclamation-circle\"></i> Notified but not delivered yet</h4>
			</div>

			<div class=\"panel-body  table-responsive\" >
				<table class=\"table table-striped table-hover\">
					<thead>
						<th>S.No.</th>
						<th>Requested By</th>
						<th>Protocol</th>
						<th>Requested date</th>
						<th>&nbsp;</th>
						<th>&nbsp;</th>
					</thead>
					<tbody>";  
	include "DBconnect.php";
	//issued=1 physical delivery of animal
	//$result = mysqli_query($db,"SELECT IndentNumber,Projectcode,RName,ARDate,issued FROM indentform");
	$sql="SELECT IndentNumber,Projectcode,RName,ARDate FROM indentform WHERE (IndentNumber IN (SELECT IndentNumber FROM responsenew WHERE issued=0) )";
	$result = mysqli_query($db,$sql);
	if($result){
	$i=1;
	
	
			while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
				
				$str=$str."
						<tr>
							<td class=\"table-text\"><div>".$i."</div></td>
							<td class=\"table-text\"><div>".$pass['RName']."</div></td>
							<td class=\"table-text\"><div>".$pass['Projectcode']."</div></td>
							<td class=\"table-text\"><div>".$pass['ARDate']."</div></td>
							
							<!-- Task Delete Button -->
							<td>
								<form action=\"IssueReply.php\" method=\"POST\">
									<input type=\"hidden\" name=\"pcode\" value=\"".$pass['Projectcode']."\">
									<input type=\"hidden\" name=\"inumber\" value=\"".$pass['IndentNumber']."\">
									<button type=\"submit\" class=\"btn btn-success\">
										<i class=\"fa fa-btn fa-check\"></i> Check details
									</button>
								</form>
							</td>
							
						</tr>";
						$i++;
					}
					if ($i== 1){
						$str=$str. "<tr><td colspan=\"5\" class=\"table-text text-danger\"><div>*No Records found</div></td></tr>";
					}
					
			
			
			mysqli_free_result($result);
		}else{
			//$_SESSION['message']="Error  ! Contact admin !";
			$str=$str. "<tr><td colspan=\"5\" class=\"table-text text-danger\"><div>Error  ! Contact admin !</div></td></tr>";	
		}

mysqli_close($db);
$str=$str."</tbody>
				</table>
			</div>
		</div>";
		echo $str;
?>
			
					