<?php include "include/sesionlauth.php"; ?>
 <?php 
	$sd = $_GET['vdate'];
	if($sd!=""){
		include "DBconnect.php";
	
			//census(CensusID, Species, strain, StockType, Male, Female)
			
			$query= "SELECT Species, strain, StockType, Male, Female FROM census WHERE insertdate='$sd' ";
			
			$result = mysqli_query($db,$query);
			$i=1; 
			$str="<caption> Status on Date= ".$sd." </caption><tr>
				<th width=\"24%\" align=\"left\" bgcolor=\"#CCCCCC\"><strong>Species</strong></th>
				<th width=\"25%\" align=\"left\" bgcolor=\"#CCCCCC\"><strong>Strain</strong></th>
				<th width=\"21%\" align=\"center\" bgcolor=\"#CCCCCC\"><strong>Stock Type </strong></th>
				<th width=\"15%\" align=\"center\" bgcolor=\"#CCCCCC\"><strong>Male/Female </strong></th>
				<th width=\"15%\" align=\"center\" bgcolor=\"#CCCCCC\"><strong>Total Animals  </strong></th>
				</tr>";
			while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
				$str=$str. "<tr bgcolor=\"#FFFFFF\">";							
				$str=$str. "<td >".$pass['Species']. "</td>";
				$str=$str. "<td >".$pass['strain']. "</td>";
				$str=$str. "<td >" .$pass['StockType']. "</td>";
				$str=$str. "<td >".$pass['Male']." + " .$pass['Female']."</td>";
				$total= $pass['Male'] + $pass['Female'];
				$str=$str. "<td >".$total. "</td>";
			    $str=$str."</tr>";
				$i=$i+1;
			}
								
			if ($i== 1){
				$str=$str."<tr height="."30"."><td colspan="."5"." align="."center"." class="."norecord"." >Not Available </td></tr>";
			}	
			echo $str;
			mysqli_free_result($result);
	
	mysqli_close($db);
	}else{
		echo "<tr height="."30"."><td colspan="."5"." align="."center"." class="."norecord"." >Please selct a field for searching ! </td></tr>";
	}
			
	?>