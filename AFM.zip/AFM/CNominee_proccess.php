<?php include "include/sesionlauth.php"; ?>

<?php 
$type=$_POST['type'];
$ftenure=$_POST['ftenure'];
$ttenure=$_POST['ttenure'];
	$name=$_POST['name'];
	$e=$_POST['email'];
	$phone=$_POST['phone'];
	$mobile=$_POST['mb'];
	$add=$_POST['add']; 
	$pin=$_POST['pin'];
if($e!=""){
	include "DBconnect.php";
	 
	//INSERT INTO cpcseanominee(Ctype, CName, Ftenure, Ttenure, CEmail, CPhone, CMobile, CAddress, Cpin) VALUES 
	$sql= "INSERT IGNORE  INTO cpcseanominee(Ctype, CName, Ftenure, Ttenure, CEmail, CPhone, CMobile, CAddress, Cpin) VALUES  ('$type','$name','$ftenure','$ttenure','$e','$phone','$mobile','$add','$pin')";

	$result = mysqli_query($db,$sql);


		if(!$result){
			
			$_SESSION['message']="Database error, contact admin  !";
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=CNominee.php">';
			die('Error: ' . mysqli_error($db));
		}else{
				$_SESSION['message']="successful saved  !";
				
				echo '<META HTTP-EQUIV="Refresh" Content="0; URL=CNominee.php">';
		}
	mysqli_close($db);
}else{
				
		$_SESSION['message']="Invalid Email !";
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=CNominee.php">';
	}
?>
