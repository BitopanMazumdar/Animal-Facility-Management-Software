<?php include "include/sesionlauth.php"; ?>
<?php
	
	$sd = filter_var($_GET['sd'], FILTER_SANITIZE_STRING);	
	$sd1 =filter_var($_GET['sd1'], FILTER_SANITIZE_STRING);	
	$str="<div class=\"panel-heading\">
				<button type=\"button\" class=\"btn btn-danger\" onclick=\"javascript:printDiv()\" ><i class=\"fa fa-btn fa-print\"></i> Print</button>
				<span class=\"text-primary\" >&nbsp;&nbsp;&nbsp;&nbsp;	List of Disposal data</span>
			</div>

			<div class=\"panel-body  table-responsive\" id=\"printdiv\">
				<table class=\"table table-striped table-hover\">
				<thead>
					<th width=\"3%\" >S.No. </th>
					<th >Date </th>
					<th >Protocol</th>
					<th >Disposed By </th>
					<th >Species/Strain</th>
					<th >Gender</th>
					<th >Quantity</th>
					<th >Disposal Reason</th>
					<th >Euthanasia Method </th>
					<th class=\"remOnPrint\" >&nbsp;</th>
				</thead>
				<tbody>";	
	if($sd != "" && $sd1 != ""){
		include "DBconnect.php";
		//disposeform (DisposeNumber, Projectcode, Title, DisposeBy, DisposeDate, Reason, Euthanasia)  
			$query= "SELECT DisposeNumber, Projectcode, Title, DisposeBy, DisposeDate, Reason, Euthanasia FROM disposeform WHERE DisposeDate BETWEEN '$sd' AND '$sd1' ORDER BY DisposeDate DESC";			
			$result = mysqli_query($db,$query);
						
			$i=1; 
			
				while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
					$disNumber=$pass['DisposeNumber'];
					$query1= "SELECT SpStrain, Gender,NoAnimal FROM disposeanimal WHERE DisposeNumber = '$disNumber'";			
					$result1 = mysqli_query($db,$query1);
					while($pass1=mysqli_fetch_array($result1,MYSQLI_ASSOC)){
						$str=$str. "<tr>";
						$str=$str. "<td class=\"table-text\"><div>".$i."</div></td>";
						$str=$str. "<td class=\"table-text\"><div>".$pass['DisposeDate']."</div></td>";		
						$str=$str. "<td class=\"table-text\"><div>".$pass['Projectcode']."</div></td>";
						$str=$str. "<td class=\"table-text\"><div>".$pass['DisposeBy']."</div></td>";
						$str=$str. "<td class=\"table-text\"><div>".$pass1['SpStrain']."</div></td>";
						$str=$str. "<td class=\"table-text\"><div>".$pass1['Gender']."</div></td>";
						$str=$str. "<td class=\"table-text\"><div>".$pass1['NoAnimal']."</div></td>";
						$str=$str. "<td class=\"table-text\"><div>" .$pass['Reason']. "</div></td>";
						$str=$str. "<td class=\"table-text\"><div>" .$pass['Euthanasia']. "</div></td>";
						$str=$str."<td class=\"remOnPrint\">
								<form action=\"EditDisposal.php\" method=\"POST\">
									<input type=\"hidden\" name=\"disnumber\" value=\"".$pass['DisposeNumber']."\">
									<button type=\"submit\" class=\"btn btn-danger\">
										<i class=\"fa fa-btn fa-edit\"></i> Edit
									</button>
								</form>
							</td>";
						$str=$str."</tr>";
						
						$i=$i+1;
					}
				}				
				if ($i== 1){
					$str=$str. "<tr><td colspan=\"8\" class=\"table-text text-danger\"><div>*No records found.</div></td></tr>";
				}	
				
		mysqli_close($db);
	}else{
		
		$str=$str. "<tr><td colspan=\"8\" class=\"table-text text-danger\"><div>*Error, You have not selected any option.</div></td></tr>";
	}
		$str=$str."</tbody>
			</table>
		</div>
	</div>";
	echo $str;		
?>