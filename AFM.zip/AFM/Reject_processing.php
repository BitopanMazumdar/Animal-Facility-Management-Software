<?php include "include/sesionlauth.php"; ?>

<?php 

$inum=filter_var($_POST['inum'], FILTER_SANITIZE_STRING);
$pc=filter_var($_POST['pc'], FILTER_SANITIZE_STRING);
$msg=filter_var($_POST['msg'], FILTER_SANITIZE_STRING);

if($inum!="" && $pc!=""){
	include "DBconnect.php";	
		//rejection(RejectNumber, IndentNumber, MSG)
		$sql1="INSERT INTO rejection(IndentNumber,MSG) values ('$inum','$msg')";
		$result1 = mysqli_query($db, $sql1);
		
		if(!$result1)
		  {
			
			$_SESSION['message']="Error ! Contact admin  !";
			echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=Indents.php\">";
			die('Error: ' . mysqli_error($db));
		  }
		  else{
				//mail string
				$str="<html>
				<head>
				<title>Soflam, System generated email</title>
				</head>
				<body>
					<table border=\"1\" style=\"border-color: #666;border-collapse:collapse;\" cellpadding=\"10\">
						<tr style=\"background: #eee;\">
							<th>Protocol</th>
							<th>Message</th>
						</tr>";
								
					$str=$str."<tr>
							<td style=\"width:10%\" >".$pc."</td>
							<td style=\"width:10%\">".$msg."</td>
						</tr>
					";
					$str=$str."</table>
					</body>
				</html>";
			//partial string ends
			   
			   $mailfrom=$_SESSION['pie'];
			   $piname=$_SESSION['piname'];
			   
			   //projects(ProjectCode, ProjectName, PrincipalInvestigator, ApprovalDate, FromDate, ToDate)
			   //projectincharge(Piname, PiDesignation, PiDepartment, Piphone, Pimobile, PiEmail, PiExperience, PiPasscode, Role, PiAddress, Pin)
			   $querymail="SELECT PiEmail FROM projects WHERE ProjectCode='$pc'";
				//response(ResponseNumber, IndentNumber, DateSupply, TimeSupply, AIFCode, DeliveryPoint, TAName, MSG)
				
				$resultmail = mysqli_query($db,$querymail);
				$i=1;
				$to_email="";
				if($resultmail){
					while($passmail=mysqli_fetch_array($resultmail,MYSQLI_BOTH)){
						
						$to_email= $passmail['PiEmail'];
						$subject = 'Regarding response of animal request.';
						$headers = "MIME-Version: 1.0" . "\r\n";
						$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
						// More headers
						$headers .= "From: ".$mailfrom."\r\n";
						if(mail($to_email,$subject,$str,$headers)){
							$_SESSION['message']="Succesfully submitted ! Response is sent to Protocol incharge via mail.";
							echo '<META HTTP-EQUIV="Refresh" Content="0; URL=Indents.php">';
						}else{
							$_SESSION['message']="Succesfully submitted ! but fail to send mail, Inform personally  !";
							echo '<META HTTP-EQUIV="Refresh" Content="0; URL=Indents.php">';
						}	
					}
				}else{
					$_SESSION['message']="Succesfully submitted ! but fail to send mail as no mail ID if found to send email. Inform personally  !";
					echo '<META HTTP-EQUIV="Refresh" Content="0; URL=Indents.php">';
				}
			}	

	mysqli_close($db);
}else{
	$_SESSION['message']="Invalid input data  ! Failed to submit  !";
	echo '<META HTTP-EQUIV="Refresh" Content="0; URL=Indents.php">';
}
?>
