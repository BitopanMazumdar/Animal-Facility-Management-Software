<?php if(session_id() == '' || !isset($_SESSION)){
							// session isn't started
							session_start();
} ?>
 <?php 
	
	$e=filter_var($_POST['email'], FILTER_SANITIZE_STRING);
	$pass=filter_var($_POST['pass'], FILTER_SANITIZE_STRING);
	$p=sha1($pass);
	$log=1;	
	$flag=0;
	if($e!="" && $p!=""){
		include "DBconnect.php";
		$result = mysqli_query($db,"SELECT DISTINCT PiName,PiPasscode,PiEmail,Role FROM projectincharge WHERE PiEmail='$e'");
				//$pass=mysqli_fetch_array($result,MYSQLI_ASSOC);			
				if($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
					if($pass['PiPasscode'] == $p){					
						$msg="succefully login";
						if($pass['Role'] =="Principal Investigator"){
							
							echo '<META HTTP-EQUIV="Refresh" Content="0; URL=ProjectIncharge/Pihome.php?msg='.$msg.'">';
						}else if($pass['Role'] =="Incharge Animal Facility"){
							
							echo '<META HTTP-EQUIV="Refresh" Content="0; URL=Aihome.php?msg='.$msg.'">';
						}else if($pass['Role'] =="Technical Officer AF"){
							
							echo '<META HTTP-EQUIV="Refresh" Content="0; URL=staff/Staffhome.php?msg='.$msg.'">';
						}else if($pass['Role'] =="Technical Assistant AF"){
							
							echo '<META HTTP-EQUIV="Refresh" Content="0; URL=staff/Staffhome.php?msg='.$msg.'">';
						}
						else if($pass['Role'] =="Athorized Personel"){
							
							echo '<META HTTP-EQUIV="Refresh" Content="0; URL=ProjectIncharge/Pihome.php?msg='.$msg.'">';
						}else{
							$flag=1;
						}
						if($flag==0){
							$_SESSION['piname']=$pass['PiName'];
							$_SESSION['pie']=$pass['PiEmail'];
							$_SESSION['PREV_USERAGENT'] = sha1($_SERVER['HTTP_USER_AGENT']);
							$_SESSION['message']="succefully login !";
						}
					}
					else
					{
						$flag=1;
						
					}	
						
				}else{
						$flag=1;
					   
			  }
			  
			  if($flag==1){
					$_SESSION['message']="Login Fail   !  Not authorized to access  ! !";
					echo '<META HTTP-EQUIV="Refresh" Content="0; URL=index.php">';
			 }								
				
		mysqli_close($db);
				
								
	}			
?>

