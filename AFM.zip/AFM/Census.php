<?php include "include/sesionlauth.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal facility status</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  
</head>
<body style="background-color:#F8F9FA">
	<nav >
		 <div class="container-fluid">
			<?php 
			include"include/headerboot.php"; 
			?>
		  </div>
		  <div class="container-fluid">
			<?php 
			include"include/MenuAi.php"; 
			?>		
		  </div> 
		  <div class="container-fluid">
				<?php 
				include"include/invRepMenu.php"; 
				?>		
			  </div>
	</nav>
	
 <!-- srcipt strat -->
<!-- Script start-->
<script type="text/javascript">
$(document).ready(function(){
	$("#displaydiv").slideDown("slow");
	$.get("species_query.php", function(data, status){
	$("#species").html(data);
	
	});
		var xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = function() {
		  if (this.readyState == 4 && this.status == 200) {
			document.getElementById("viewdata").innerHTML = this.responseText;
			$("#viewdata").slideDown("slow");
			$("#loader").hide();
		  }
		};
		
		xmlhttp.open("GET", "censusByAll.php", true);
		xmlhttp.send();

});
</script>
<script type="text/javascript">
function showList()
{
	$("#viewdata").hide();
	$("#loader").show();
	type=$('input:radio[name=type]:checked').val();
	spe=$('#species').val();
	str=$('#strain').val();
	stock=$('#stock').val();
	vdate=$('#vdate').val();
	if(type==1){
		if(spe=="" && str==""){
			alert("Select Species/Strain");
		}else{
			//window.location='CensusByspst.php?page=ahreports&pg=census&type='+type+'&spe='+spe+'&str='+str+'';
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() {
			  if (this.readyState == 4 && this.status == 200) {
				document.getElementById("viewdata").innerHTML = this.responseText;
				$("#viewdata").slideDown("slow");
				$("#loader").hide();
			  }
			};
			
			xmlhttp.open("GET", "CensusByspst.php?spe="+spe+"&str="+str,true);
			xmlhttp.send();
		}
	}																												
	if(type==2)
	{
			if(stock=="")
			alert("Select stock Type !");
			else {
				//window.location='CensusByDate.php?page=ahreports&pg=census&type='+type+'&sd='+vdate+'';
				var xmlhttp = new XMLHttpRequest();
				xmlhttp.onreadystatechange = function() {
				  if (this.readyState == 4 && this.status == 200) {
					  //alert("in by stock");
					document.getElementById("viewdata").innerHTML = this.responseText;
					$("#viewdata").slideDown("slow");
					$("#loader").hide();
				  }
				};
				
				xmlhttp.open("GET", "CensusByStock.php?sd="+stock, true);
				xmlhttp.send();
			}
	}
}

function checkType(val)
{
//alert(val);

$('input:radio[name=type]')[val].checked = true;
}
</script>
<script type="text/javascript">

function getStrain(val1){
		
	$.get("strain_query.php", {sp:val1}, function(data, status){
		
    $("#strain").html(data);
    });
	return true;
}	
</script>

<script type="text/javascript">
function printDiv() {
        //Get the HTML of whole page
        var oldPage = document.body.innerHTML;
        //remove unwanted elements
		
		$("th").remove(".remOnPrint");
		$("td").remove(".remOnPrint");
		//$("#rempbdiv").remove(); 
		//Reset the page's HTML with div's HTML only
		//Get the HTML of div
        var divElements = document.getElementById('printdiv').innerHTML; 
        //alert(divElements);
		var htmlToPrint = '' +
        '<style type="text/css">' +
        'table th, table td {' +
        'border:1px solid black;' +
        'padding;0.5em;' +
        '}' +'table thead {'+'border:1px solid black; background-color:#F8F9FA;'+'}'+
        '</style>';
        document.body.innerHTML = 
          "<html><head><title>All Client List</title>" +  htmlToPrint+"</head><body>" + divElements + "</body></html>";
        //Print Page
        window.print();
        //Restore orignal HTML
        document.body.innerHTML = oldPage;

    }
</script>
 <!-- srcipt end -->
<div>&nbsp;</div>
<div class="container" id="displaydiv" style="display:none">
        <div class="col-sm-offset-2 col-sm-8">
            <div class="panel panel-default">
                <div class="panel-heading">
                   Animal house status, Search criteria.
                </div>

                <div class="panel-body">
                    <!-- submit message -->
						<?php 
								if(isset($_SESSION['message'])){
									echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
									unset($_SESSION['message']);
								}		
						?>
					<!-- submit message -->	

                    <!-- New Task Form -->
                    <form class="form-horizontal">
						<div class="row">
							<div class="radio col-sm-3">
							  <label><input  name="type" type="radio" value="1" checked>Species</label>
							</div>
							
							<div class="form-group col-sm-4">
								<select class="form-control" name="species" id="species" onfocus="checkType('0');" onchange="getStrain(this.value);">
									<option value="">Select</option>
								 </select> 
							</div>
							
							<div class="form-group col-sm-5">
								<label for="vdate1" class="col-sm-3 control-label">Strain:</label>
								<div class="col-sm-7">
									<select class="form-control" id="strain" name="strain">
									<option value="" selected="selected"> Select </option>
								</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="radio col-sm-3">
							  <label><input name="type" type="radio" value="2" >Stock Type</label>
							</div>
							
							<div class="form-group col-sm-4">
								
								<div >
									<select class="form-control col-sm-10" name="stock" id="stock" onFocus="checkType('1')" >
										<option value="">Select</option>
										<option value="Breeding Pair">Breeding Pair</option>
										<option value="Issue Stock">Issue Stock </option>
									</select>
								</div>
							</div>
							
						</div>
						<div class="row">
							<div class="form-group">
								<div class="col-sm-offset-4 col-sm-6">
									
									<button type="button" onClick="showList()" class="btn btn-success">
										<i class="fa fa-btn fa-search"></i> Search
									</button>
								</div>
							</div>
						</div>
					</form>
                </div>
            </div>
		</div>
	</div>
	<div class="container">
        <div class="col-sm-offset-0 col-sm-12">
            <div id="viewdata" class="panel panel-default" style="display:none">
			<!-- load data-->	
			</div>
		</div>
		</div>
	</div>
    
	<div class="container" >
		<div id="loader" class="col-sm-offset-5 col-sm-7 loader">
		</div>
	</div>
	
	<div>&nbsp;</div><div>&nbsp;</div>
	<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
	</div>
	
</body>
</html>