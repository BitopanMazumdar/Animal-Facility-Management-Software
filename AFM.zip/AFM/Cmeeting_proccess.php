<?php include "include/sesionlauth.php"; ?>
<?php 

$minutes=filter_var($_POST['minutes'], FILTER_SANITIZE_STRING);
$dtitle=filter_var($_POST['dtitle'], FILTER_SANITIZE_STRING);
$rdate=filter_var($_POST['rdate'], FILTER_SANITIZE_STRING);
//$dfile=$_POST['dfile']; 

include "DBconnect.php";

/* File upload */
$targetDir = "uploads/";
$fileName = basename($_FILES["dfile"]["name"]);

$targetFilePath = $targetDir . $fileName;
/* echo $fileName;
echo $targetDir ;
echo $targetFilePath;
*/
$statusMsg ="";

$fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);

if($fileName!=""){
	
	   // Allow certain file formats
	   
    $allowTypes = array('jpg','png','jpeg','gif','pdf','docx'); 
    if(in_array($fileType, $allowTypes)){
        // Upload file to server
        if(move_uploaded_file($_FILES["dfile"]["tmp_name"], $targetFilePath)){
            //`meeting`(`MeetingID`, `Minutes`, `MDocumentTitle`, `MReferenceDate`, `DocumentName`)
			$sql="INSERT INTO `meeting`(`Minutes`, `MDocumentTitle`, `MReferenceDate`, `DocumentName`) values ('$minutes', '$dtitle', '$rdate', '$fileName')";

			$Result = mysqli_query($db, $sql);													
			if(!$Result)
			  {
				$_SESSION['message']="Error ! Contact admin  !";
				echo '<META HTTP-EQUIV="Refresh" Content="0; URL=Cmeeting.php">';
				die('Error: ' . mysqli_error($db));
			  }
			else
			{
				//$statusMsg = "The file ".$fileName. " has been uploaded successfully.";	
				$_SESSION['message']="The file ".$fileName. " has been uploaded successfully.";
								
			}
			mysqli_close($db);
			
			/* Insert image file name into database
            $insert = $db->query("INSERT into images (file_name, uploaded_on) VALUES ('".$fileName."', NOW())");
            if($insert){
                $statusMsg = "The file ".$fileName. " has been uploaded successfully.";
            }
			else{
                $statusMsg = "File upload failed, please try again.";
            } */
        }else{
            $_SESSION['message'] = "Sorry, there was an error uploading your file.";
        }
    }else{
        $_SESSION['message'] = 'Sorry, only JPG, JPEG, PNG, GIF, & PDF files are allowed to upload.';
    }
}else{
    $_SESSION['message'] = 'Please select a file to upload.';
}
echo '<META HTTP-EQUIV="Refresh" Content="0; URL=Cmeeting.php">';
// Display status message
//echo $statusMsg;

/* End of file upload code */


//$result = mysql_query($query);
//$passcheck = mysql_fetch_array($result);

?>
