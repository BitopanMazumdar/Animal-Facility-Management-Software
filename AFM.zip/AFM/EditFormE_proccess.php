<?php include "include/sesionlauth.php"; ?>
 <?php 
$inum=$_POST['inum'];
$sdate=filter_var($_POST['sdate'], FILTER_SANITIZE_STRING);
$SupplyTo=filter_var($_POST['bname'], FILTER_SANITIZE_STRING);
$billno=filter_var($_POST['billno'], FILTER_SANITIZE_STRING);
$SupplyFrom=filter_var($_POST['sname'], FILTER_SANITIZE_STRING);
$idate=filter_var($_POST['idate'], FILTER_SANITIZE_STRING);
$iaecno=filter_var($_POST['iaecno'], FILTER_SANITIZE_STRING);
$rowno= filter_var($_POST['row_no'], FILTER_SANITIZE_STRING);

$rowno= $_POST['row_no'];
for($i=1; $i<=$rowno; $i++){
$EntryNo[$i]=$_POST['EntryNo'.$i];
$species[$i]=filter_var($_POST['species'.$i], FILTER_SANITIZE_STRING);
$strain[$i]=filter_var($_POST['strain'.$i], FILTER_SANITIZE_STRING);
$qm[$i]=filter_var($_POST['qm'.$i], FILTER_SANITIZE_STRING);
$qf[$i]=filter_var($_POST['qf'.$i], FILTER_SANITIZE_STRING);
$stock[$i]=filter_var($_POST['stock'.$i], FILTER_SANITIZE_STRING);
}

$flag=1;
if($inum !="" && $sdate!="" && $SupplyTo!=""){
	include "DBconnect.php";
	//fsale(SaleID, Saledate, Scode, Bcode, IEACdate, IAECno, BillNo)
	//('$sdate', '$SupplyTo', '$SupplyFrom','$idate','$iaecno','$billno')
	$query="UPDATE fsale SET Saledate='$sdate', Scode='$SupplyFrom', Bcode='$SupplyTo', IEACdate='$idate', IAECno='$iaecno', BillNo='$billno' WHERE SaleID= '$inum'" ;
	mysqli_query($db,$query);
	$result = mysqli_affected_rows($db);	
		if($result >= 0){
			$flag=1;
		}else{
			$flag=0;
			$_SESSION['message']="Error, Contact Admin  !";
			echo'<META HTTP-EQUIV="Refresh" Content="0; URL=SaleReport.php">';
			die();
		}
		for($i=1; $i<=$rowno; $i++){
			//sanimal(EntrySaleNumber,SaleID, Species, strain, StockType, MALE, Female) values ('$sid','$species[$i]','$strain[$i]','$stock[$i]','$qm[$i]','$qf[$i]')"; 
					
			$sql2="UPDATE sanimal SET species='$species[$i]', strain='$strain[$i]', StockType='$stock[$i]', MALE='$qm[$i]', Female='$qf[$i]' WHERE EntrySaleNumber= '$EntryNo[$i]'";
			mysqli_query($db,$sql2);
			$result2 = mysqli_affected_rows($db);
			if($result2 < 0){ 
				$flag=0;
				$_SESSION['message']="Could not update animal data: contact admin";
				echo"<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=SaleReport.php\">";
				die();						
			}							
		}
		if($flag==1){
			$_SESSION['message']="Successfully edited !";
			echo"<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=SaleReport.php\">";
		}else{
			$_SESSION['message']="Error, Contact Admin  !";
			echo"<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=SaleReport.php\">";
			
		}
		
		mysqli_close($db);
	
}else{
	$_SESSION['message']="Error, Invalid input  !";
	echo'<META HTTP-EQUIV="Refresh" Content="0; URL=SaleReport.php">';
}
