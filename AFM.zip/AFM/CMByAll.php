<?php include "include/sesionlauth.php"; ?>
<?php 
						
	include "DBconnect.php";
	$str="<div class=\"panel-heading\">
				<button type=\"button\" class=\"btn btn-danger\" onclick=\"javascript:printDiv()\" ><i class=\"fa fa-btn fa-print\"></i> Print</button>
				<span class=\"text-primary\" >&nbsp;&nbsp;&nbsp;&nbsp;	CPCSEA Member</span>
			</div>

			<div class=\"panel-body  table-responsive\" id=\"printdiv\">
				<table class=\"table table-bordered table-hover\">
				<thead>
					<th width=\"4%\" ><strong>S.No. </strong></th>
		<th width=\"10%\" ><strong>Type </strong></th>
        <th width=\"20%\" ><strong>Name </strong></th>
		<th width=\"15%\" ><strong>Phone </strong></th>
		<th width=\"15%\" ><strong>Mobile </strong></th>
        <th width=\"20%\" ><strong>Email ID </strong></th>
		<th width=\"25%\" ><strong>Address </strong></th>
					<th width=\"10%\"  class=\"remOnPrint\" >&nbsp;</th>
				</thead>
				<tbody>";
	//cpcseanominee(Ctype, CName, CEmail, CPhone, CMobile, CAddress, Cpin)
	$sql="SELECT Ctype, CName, CEmail, CPhone, CMobile, CAddress, Cpin FROM cpcseanominee ";
	$result = mysqli_query($db,$sql);
	//$pass = mysqli_fetch_array($result);
	if($result){
				$i=1;
	
	while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){				
								
		$str=$str. "<tr>";
		$str=$str. "<td >";
		$str=$str. "<b>".$i."<b>";
		$str=$str. "</td>";
			
		$str=$str. "<td >";
		$str=$str. "<b>".$pass['Ctype']. "<b>";
		$str=$str. "</td>";
		$str=$str. "<td >";
		$str=$str. "<b>".$pass['CName']. "<b>";
		$str=$str. "</td>";
		$str=$str. "<td >";
		$str=$str. "<b>".$pass['CPhone']. "<b>";
		$str=$str. "</td>";
		
		$str=$str. "<td >";
		$str=$str. "<b>".$pass['CMobile']."<b>";
		$str=$str. "</td>";
		$str=$str. "<td >";
		$str=$str. "<b>".$pass['CEmail']."<b>";
		$str=$str. "</td>";
		$str=$str. "<td >";
		$str=$str. "<b>".$pass['CAddress']." - ".$pass['Cpin']."<b>";
		$str=$str. "</td>";
		$str=$str."<td class=\"remOnPrint\">
				<form action=\"EditCMUser.php\" method=\"POST\">
					<input type=\"hidden\" name=\"user\" value=\"".$pass['CEmail']."\">
					<button type=\"submit\" class=\"btn btn-danger\">
						<i class=\"fa fa-btn fa-edit\"></i> Edit
					</button>
				</form>
			</td>";
		$str=$str."</tr>";
		$i++;		 
	}
	if ($i== 1){
				$str=$str. "<tr><td colspan=\"8\" class=\"table-text text-danger\"><div>*No Records found</div></td></tr>";
			}	
		
		mysqli_free_result($result);
	}else{
		$str=$str. "<tr><td colspan=\"8\" class=\"table-text text-danger\"><div>*Error, Contact Admin.</div></td></tr>";
	}
	$str=$str."</tbody>
			</table>
		</div>
	</div>";
	echo $str;
	mysqli_close($db);
	
	?>