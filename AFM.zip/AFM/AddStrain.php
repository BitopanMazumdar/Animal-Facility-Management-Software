<?php include "include/sesionlauth.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  <link rel="stylesheet" href="css/custom.css">
  
</head>
<body style="background-color:#F8F9FA">
<nav >
 <div class="container-fluid">
	<?php 
	include"include/headerboot.php"; 
	?>
  </div>
  <div class="container-fluid">
	<?php 
	include"include/MenuAi.php"; 
	?>		
  </div>
   
</nav>
	<div>&nbsp;</div>
<?php $species =$_GET['species'];?>

<!-- Script start-->
<script type="text/javascript">
$(document).ready(function(){
		$("#search").slideDown("slow");
});
</script>
<script type="text/javascript">
function validate(){
	
	frm = document.myform;
	
	 if(frm.strain.value =="")
	  {
			alert("Please enter Strain! ");
			frm.strain.focus();
			return false;
	  }
	    
}
</script>
<script type="text/javascript">

$(document).ready(function(){
	var spec= document.getElementById("species").value;
		var xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = function() {
		  if (this.readyState == 4 && this.status == 200) {
			document.getElementById("viewdata").innerHTML = this.responseText;
			$("#viewdata").slideDown("slow");
		  }
		};
		
		xmlhttp.open("GET", "StrainBySpecies.php?species="+spec, true);
		xmlhttp.send();
});
	
</script>
<script type="text/javascript">
function editSt(i){
		
		$("#editstrain"+i).slideDown('slow'); 
		$("#newstrain"+i).focus();
}

function newStrain(i){ 
	 newst= $("#newstrain"+i).val();
	 oldst=$("#oldstrain"+i).val();
	 var patt = /[%*+;<=>^]/;
	 
	if(patt.test(newst)){
		alert("invalid input! special characters: %*+;<=>^ are not allowed");
		return false;
	}else{
		if(newst == ""){
			alert("Please Enter New strain to edit !");
			$("#newstrain"+i).focus();
		}else{
			var xmlhttp = new XMLHttpRequest();
				xmlhttp.onreadystatechange = function() {
				  if (this.readyState == 4 && this.status == 200) {
					//document.getElementById("tdata").innerHTML = this.responseText;
					alert(this.responseText);
					location.reload(true);
				  }
				};
				
				xmlhttp.open("GET", "EditStrain.php?newst="+newst+"&oldst="+oldst, true);
				xmlhttp.send();
		}
	}
}

</script>
<!-- Script end-->
<!-- body-->
<div class="container" id="displaydiv" >
<div class="col-sm-12">&nbsp;</div>
	<div class="col-sm-offset-2 col-sm-8">
		<div class="panel panel-default">
		
			<div class="panel-heading">
				<h4>Species : <?php echo htmlspecialchars($species);?>, Add Strain </h4>
			</div>

			<div class="panel-body">
				
				<!-- New Task Form -->
				<form name="myform" action="AddStrain_proccssing.php" method="post" onSubmit="return validate();" class="form-horizontal">
					
					<!-- Task Name -->
					<div class="form-group">
						<label for="species" class="col-sm-3 control-label"><span style="color: red">*</span>Strain Name:</label>
						<div class="col-sm-6">
							<input class="form-control" required name="strain" type="text" id="strain"/> 
							<input class="form-control" id="species" name="species" type="hidden" value="<?php echo htmlspecialchars($species);?>" hidden />
						</div>
						
					</div>
					
					<!-- Add Task Button -->
					<div class="form-group">
						<div class="col-sm-offset-3 col-sm-6">
							<button type="submit" class="btn btn-default">
								<i class="fa fa-btn fa-plus"></i> Add Strain
							</button>
						</div>
					</div>
				</form>
			</div>
		</div>
		
		
	</div>
	<div class="col-sm-offset-1 col-sm-10">
		<!-- submit message -->
			<?php 
				
					if(isset($_SESSION['message'])){
						echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
						unset($_SESSION['message']);
					}						
			?>
		<!-- submit message -->
			<div id="viewdata" class="panel panel-default" style="display:none">
			
			</div>
		
	</div>
</div>
<div class="footer" >
		<?php 
			include"include/footerboot.php"; 
		?>
</div>			
</body>
</html>
