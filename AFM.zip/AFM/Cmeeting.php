<?php include "include/sesionlauth.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  <link rel="stylesheet" href="css/custom.css">
  
</head>
<body style="background-color:#F8F9FA">
<nav >
 <div class="container-fluid">
	<?php 
	include"include/headerboot.php"; 
	?>
  </div>
  <div class="container-fluid">
	<?php 
	include"include/MenuAi.php"; 
	?>		
  </div>
   
</nav>

<!-- Script start-->
<script type="text/javascript">
 $(document).ready(function(){
	 $("#main").slideDown("slow");
	
});
</script>
<script type="text/javascript">		
 function valid(){
	frm = document.myform;
	var patt = /[%*+;<=>^]/;
	  if(frm.minutes.value =="")
	  {
			alert("Please Enter Minutes of meeting! ");
			frm.minutes.focus();
			return false;
	  }
	  if(patt.test(frm.minutes.value)){
				alert("invalid address input ! special characters: %*+;<=>^ are not allowed");
				frm.minutes.focus();
				return false;
		}
	  	  
	  if(frm.dtitle.value =="")
	  {
			alert("Please Document Title !");
			frm.dtitle.focus();
			return false;
	  }
	   if(frm.rdate.value =="")
	  {
			alert("Please Date for Ref.!");
			frm.rdate.focus();
			return false;
	  }
	 if(frm.dfile.value =="" )
	  {
			alert("Please select file !");
			frm.dfile.focus();
			return false;
	  }
	  var r = confirm("confirm submit!");
	  if (r == true) {
		return true;
	  }else {
		frm.minutes.focus();
		return false;
	  }	  
}
</script>

<!-- Script end-->
 
<div class="container" id="main" style="display:none">
<br>
<!-- submit message -->
	<?php 
		
		if(isset($_SESSION['message'])){
			echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
			unset($_SESSION['message']);
		}
								
	?>
<!-- submit message -->
<form autocomplete="off" action="Cmeeting_proccess.php" enctype="multipart/form-data" name="myform" method="post" onSubmit="return valid();">
	<button type="button" class="btn btn-success col-sm-offset-9" onClick="document.location.href='ViewMeeting.php'">
						<i class="fa fa-btn fa-file"></i> View Previous Meeting
					</button> 
	<div class="form-group">
	<fieldset>
	<legend>Meeting Document Management
	</legend>
		<label class="control-label"  for="minutes">Minutes Of Meeting<span id="red">*</span>:</label>
			<textarea required class="form-control" style="text-transform: capitalize;" name="minutes" type="text" id="minutes" rows="5"></textarea>
			
		<label class="control-label"  for="dtitle">Meeting Title<span id="red">*</span>:</label>
			<input class="form-control" style="text-transform: capitalize;" pattern="[A-Za-z0-9\s]*" title="Special characters are not allowed" required name="dtitle" type="text" id="dtitle" value="" size="25"/>
			
		<label class="control-label"  for="rdate">Date for Reference<span id="red">*</span>:</label>
			<input class="form-control" required  name="rdate" type="date"  id="rdate" />
		</fieldset>
	</div>
	<div class="form-group">
	<fieldset>		
		<label class="control-label"  for="dfile">Upload Document<span id="red">*</span>:</label>
			<input class="custom-file-label" required  name="dfile" type="file" id="dfile"/>
	</fieldset>
	</div>
	<!-- Add Task Button -->
	<div class="form-group">
	
		<div class="col-sm-offset-5 col-sm-6">
			<button type="submit" class="btn btn-danger">
				<i class="fa fa-btn fa-save"></i> Save
			</button>
			<button type="button" class="btn btn-info" onclick="window.history.back()">
				<i class="fa fa-btn fa-arrow-left"></i> Back
			</button>
		</div>
	
	</div>
</form>
</div>
		
	<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
	</div>
	
</body>
</html>
