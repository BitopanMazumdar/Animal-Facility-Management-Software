<?php include "include/sesionlauth.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  
  
  
</head>
<body style="background-color:#F8F9FA">

	<nav >
	  <div class="container-fluid">
		<?php 
		include"include/headerboot.php"; 
		?>
	  </div>
	  <div class="container-fluid">
		<?php 
		include"include/MenuAi.php"; 
		?>
	  </div>
	</nav>
	<div>&nbsp;</div>
<script type="text/javascript">
$(document).ready(function(){
	
	var xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = function() {
		  if (this.readyState == 4 && this.status == 200) {
			document.getElementById("viewdata").innerHTML = this.responseText;
			$("#viewdata").slideDown("slow");
			$("#loader").hide();
		  }
		};
		
		xmlhttp.open("GET", "indentByAll.php", true);
		xmlhttp.send();	
		
		
});

</script>
	<div class="container" id="displaydiv" >
        <div class="col-sm-offset-2 col-sm-8">
		<!-- submit message -->
			<?php 
					if(isset($_SESSION['message'])){
						echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
						unset($_SESSION['message']);
					}		
			?>
		<!-- submit message -->
			
		</div>
		
		<div class="col-sm-12" id="disviewDiv">
			
			<div id="viewdata" class="panel panel-default" style="display:none">
				
			</div>
		</div>
    </div>
	<div class="container" >
		<div id="loader" class="col-sm-offset-5 col-sm-7 loader">
		</div>
	</div>
	<div>&nbsp;</div><div>&nbsp;</div>
	<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
	</div>
	
</body>
</html>