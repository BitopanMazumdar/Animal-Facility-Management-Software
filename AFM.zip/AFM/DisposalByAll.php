<?php include "include/sesionlauth.php"; ?>
<?php 
	/*if(session_id() == '' || !isset($_SESSION)) {
			// session isn't started
			session_start();
		}
		$pie=$_SESSION['pie'];		
		$piname=$_SESSION['piname']; not neccessary*/
	   	   
		include "DBconnect.php";
			//disposeform (DisposeNumber, Projectcode, Title, DisposeBy, DisposeDate, Reason, Euthanasia)  
			$query= "SELECT DisposeNumber, Projectcode, Title, DisposeBy, DisposeDate, Reason, Euthanasia FROM disposeform WHERE Projectcode IN (SELECT ProjectCode FROM projects WHERE PrincipalInvestigator='$piname') ORDER BY Projectcode";			
			$result = mysqli_query($db,$query);
						
			$i=1; 
			$str="<caption> Serarch By : All </caption>
				<tr>
				<th width=\"3%\" ><strong>S.No. </strong></th>
				<th width=\"9%\" ><strong>Date </strong></th>
				<th width=\"9%\" ><strong>Project Code </strong></th>
				<th width=\"9%\" ><strong>Disposed By </strong></th>
				<th width=\"9%\" ><strong>Species/Strain</strong></th>
				<th width=\"9%\" ><strong>No. Of Animals</strong></th>
				<th width=\"9%\" ><strong>Disposal Reason</strong></th>
				<th width=\"9%\" ><strong>Euthanasia Method </strong></th>
				<th width=\"5%\" align=\"center\" ><strong>Edit</strong></th>
				</tr>";
				while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
					$disNumber=$pass['DisposeNumber'];
					$query1= "SELECT SpStrain, NoAnimal FROM disposeanimal WHERE DisposeNumber = '$disNumber'";			
					$result1 = mysqli_query($db,$query1);
					while($pass1=mysqli_fetch_array($result1,MYSQLI_ASSOC)){
						//disposeform (DisposeNumber, Projectcode, Title, DisposeBy, DisposeDate, Reason, Euthanasia)
						
						$str=$str. "<tr bgcolor=\"#FFFFFF\">";
						$str=$str. "<td >".$i."</td>";
						$str=$str. "<td >".$pass['DisposeDate']."</td>";		
						$str=$str. "<td >".$pass['Projectcode']."</td>";
						$str=$str. "<td >".$pass['DisposeBy']."</td>";
						$str=$str. "<td >".$pass1['SpStrain']."</td>";
						$str=$str. "<td >".$pass1['NoAnimal']."</td>";
						$str=$str. "<td >" .$pass['Reason']. "</td>";
						$str=$str. "<td >" .$pass['Euthanasia']. "</td>";
						
						$str= $str. "<td align=\"center\" ><button id=\"newDisposal\" onclick=\"editDisposal(this.value)\" value=\"".$pass['DisposeNumber']."\" style=\"width:5em; \" > edit </button> </td>";
						
						$i=$i+1;
					}
				}				
				if ($i== 1){
					$str=$str. "<tr height="."30"."><td colspan="."10"." align="."center"." bgcolor="."red"." >No Records found.</td></tr>";
				}	
				echo $str;
			
	mysqli_free_result($result);
	mysqli_close($db);
			
	?>
 