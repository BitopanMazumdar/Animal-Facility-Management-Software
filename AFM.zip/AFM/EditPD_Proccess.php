<?php include "include/sesionlauth.php"; ?>

<?php 
$pcode=$_POST['code'];
//$pname=$_POST['name'];
//$pi=$_POST['pi'];
$name=$_POST['name'];
$doa=$_POST['doa'];
$idoa=$_POST['idoa'];
$dfrom=$_POST['dfrom'];
$dto=$_POST['dto'];
$remark=$_POST['remark'];
//$piemail=$_POST['email'];
//echo $pcode;
	if($pcode!=""){
		include "DBconnect.php";

			$sql="UPDATE projects SET ProjectName ='$name', ApprovalDate='$doa',FromDate='$dfrom',ToDate='$dto', IeacApprove='$idoa', Remarks='$remark', author='$pie' WHERE ProjectCode ='$pcode'";
			
		mysqli_query($db,$sql);
		$result = mysqli_affected_rows($db);
		if($result >=0){
			$_SESSION['message']="Protocol: ".$pcode." is Successfully edited  !";
			echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=projects.php\">";
			
		}else{
			$_SESSION['message']="Fail to edit  ! contact admin  !";
			echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=projects.php\">";
		}		
		
		mysqli_close($db);
	}else{
		$_SESSION['message']="Invalid input data";
		echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=projects.php\">";
	}
		
	?>
