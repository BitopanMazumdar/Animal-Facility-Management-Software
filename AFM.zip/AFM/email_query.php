<?php include "include/sesionlauth.php"; ?>
<?php 
	include "DBconnect.php";
	//projectincharge(Piname,PiDesignation,PiDepartment,Piphone,Pimobile,PiEmail,PiExperience, PiPasscode,Role,PiAddress,Pin,created_at,updated_at,author)
	$mailid=filter_var($_GET['mailid'], FILTER_SANITIZE_STRING);	
	$result = mysqli_query($db,"SELECT DISTINCT PiEmail FROM projectincharge WHERE PiEmail='$mailid'");	
	$str = 0;
	if($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
		
		$str = 1;				
	}	
	echo $str;
	mysqli_free_result($result);
	mysqli_close($db);
		
	?>