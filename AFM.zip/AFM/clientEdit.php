<?php include "include/sesionlauth.php"; ?>

<?php 
//users(FName,LName,EmailID,Contact,UserType)
$clientID=filter_var($_POST['clientID'], FILTER_SANITIZE_STRING);

if($clientID!=""){
include"DBconnect.php";
	//client(name, clientID, cType, status, mobile1, mobile2, phone1, phone2, email1, email2, region, cState, city, adderss, pin, cRegNum, cRdate)
	$result = mysqli_query($db,"SELECT DISTINCT BCode, Bname, BRegNum, BRdate, BAddress, Bpin, Bphone, Bmobile, BEmail FROM anbuyer WHERE BCode='$clientID'");
	if($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
	?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  <link rel="stylesheet" href="css/custom.css">
  
</head>
<body style="background-color:#F8F9FA">
<nav >
 <div class="container-fluid">
	<?php 
	include"include/headerboot.php"; 
	?>
  </div>
  <div class="container-fluid">
	<?php 
	include"include/MenuAi.php"; 
	?>		
  </div>
  
</nav>
 
<script type="text/javascript">
function getCompany(name){
	 $("#code").val(name);
}
</script>
<script language="javascript" type="text/javascript" >
	function valid()
	{
		frm = document.clientform;
		var patt = /[%*+;<=>^]/;
		if(frm.address.value !=""){
			if(patt.test(frm.address.value)){
				alert("invalid company address ! special characters: %*+;<=>^ are not allowed");
				frm.address.focus();
				return false;
			}
		}
		
		r=confirm("confirm submission!");
		if(r==true){
		  return true;
		}else{
		  frm.name.focus;
		  return false;
		}
		   
	}
</script>		

<div>&nbsp;</div>


<div class="container">
  <h3 class="text-primary">Edit Client Information</h3>
  <form class="form-horizontal" name="clientform" action="clientEdit_process.php" method="POST" onsubmit="return valid();">
    <div class="form-group">
      <label class="control-label col-sm-2" for="name"><span style="color: red">*</span>Client Name:</label>
      <div class="col-sm-8">
        <input style="text-transform:capitalize;" pattern="[0-9\\A-Za-z\s.,(&/)]*" title="Special characters: . , are allowed only" required type="text" class="form-control" id="name" placeholder="Enter Client Name" name="name" onchange="getCompany(this.value)" value="<?php echo htmlspecialchars($pass['Bname']); ?>" />
      </div>
    </div>
	<div class="form-group">
      <label class="control-label col-sm-2" for="code"><span style="color: red">*</span>Client Code:</label>
      <div class="col-sm-8">
        <input style="text-transform:capitalize;" pattern="[0-9\\A-Za-z\s.,(&/)]*" title="Special characters: . , are allowed only" required type="text" class="form-control" id="code" placeholder="Enter Client Code" name="code" value="<?php echo $clientID; ?>" />
		<input type="hidden" class="form-control" id="codeold" name="codeold" value="<?php echo $clientID; ?>" />
      </div>
    </div> 
	
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group">
				<label class="control-label col-sm-4" for="rno"><span style="color: red">*</span>Registration No.:</label>
				<div class="col-sm-7 ">
				<input pattern="[A-Za-z\\0-9\s/-]*" title="Special characters: \,/,- are allowed only" required type="text" class="form-control" id="rno" placeholder="Enter Registration No." name="rno" value="<?php echo htmlspecialchars($pass['BRegNum']); ?>" />
				</div>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label class="control-label col-sm-4" for="rdate"><span style="color: red">*</span>Registration Date:</label>
				<div class="col-sm-6">
				<input required type="date" class="form-control" id="rdate" placeholder="Enter Client Code" name="rdate" value="<?php echo htmlspecialchars($pass['BRdate']); ?>" />
				</div>
			</div>
		</div>
	</div>
	
			
	<div class="form-group">
      <label class="control-label col-sm-2" for="address"><span style="color: red">*</span>Address:</label>
      <div class="col-sm-8">
        <textarea required style="text-transform: capitalize;" class="form-control" id="address" placeholder="Enter Address" name="address"><?php echo htmlspecialchars($pass['BAddress']); ?></textarea>
      </div>
    </div>
	
	
	<div class="row">
		
		<div class="col-sm-6">
			<div class="form-group">
				<label class="control-label col-sm-4" for="pin">PIN:</label>
				<div class=" col-sm-6">
				<input pattern="[0-9]{6}" title="6 digit pin allowed only" type="text" class="form-control" id="pin" placeholder="Enter Pin number" name="pin" value="<?php echo htmlspecialchars($pass['Bpin']); ?>" />
				</div>
			</div>
		</div>
	</div>
	
    
	
	<div class="form-group">
      <label class="control-label col-sm-2" for="email1">Email:</label>
      <div class="col-sm-8">
        <input type="email" class="form-control" id="email1" placeholder="Enter Email" name="email1" value="<?php echo htmlspecialchars($pass['BEmail']); ?>" />
      </div>
    </div>
	
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group">
				<label class="control-label col-sm-4" for="phone1">Phone No.:</label>
				<div class=" col-sm-6">
				<input pattern="[0-9\/\+\s-]{9,}" type="tel" title="digit + - and / allowed only" type="text" class="form-control" id="phone1" placeholder="Enter Phone No." name="phone1" value="<?php echo htmlspecialchars($pass['Bphone']); ?>" />
				</div>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label class="control-label col-sm-4" for="mobile1">Mobile No.:</label>
				<div class=" col-sm-6">
				<input pattern="[0-9\+\s-]{9,}" title="digits + - allowed only minimum length:9 " type="text" class="form-control" id="mobile1" placeholder="Enter Mobile No." name="mobile1" value="<?php echo htmlspecialchars($pass['Bmobile']); ?>" />
				</div>
			</div>
		</div>
	</div> 
	
	
		
    <div class="form-group">
		<div>&nbsp;</div>
      <div class="col-sm-offset-4 col-sm-8">
        <button type="submit" class="btn btn-danger">
		<i class="fa fa-btn fa-edit"></i> Edit Client
		</button>
		<button type="reset" class="btn btn-primary"><i class="fa fa-btn fa-refresh"></i> Reset</button> 
		<button type="button" class="btn btn-primary" onclick="window.history.back()"><i class="fa fa-btn fa-arrow-circle-left"></i> Back</button>
      </div>
    </div>
 
	</form>
</div>
<div>&nbsp;</div><div>&nbsp;</div>
<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
</div>
</body>
</html>


<?php 
	}
}
?> 