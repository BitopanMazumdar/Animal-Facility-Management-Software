<?php include "include/sesionlauth.php"; ?>
<?php 

$inum=filter_var($_POST['inum'], FILTER_SANITIZE_STRING);
$pc=filter_var($_POST['pc'], FILTER_SANITIZE_STRING);
$dos=filter_var($_POST['dos'], FILTER_SANITIZE_STRING); 
$tos=filter_var($_POST['tos'], FILTER_SANITIZE_STRING);
$AIFcode=filter_var($_POST['AIFcode'], FILTER_SANITIZE_STRING);
$dpt=filter_var($_POST['dpt'], FILTER_SANITIZE_STRING);
$tech_name=filter_var($_POST['tech_name'], FILTER_SANITIZE_STRING);
$msg=filter_var($_POST['msg'], FILTER_SANITIZE_STRING);

//animal specification
$rowno= filter_var($_POST['rowno'], FILTER_SANITIZE_STRING); 

for($i=1; $i<=$rowno; $i++){
	$strain[$i]=filter_var($_POST['strain'.$i], FILTER_SANITIZE_STRING);
	$gender[$i]=filter_var($_POST['sex'.$i], FILTER_SANITIZE_STRING);
	$age[$i]=filter_var($_POST['age'.$i], FILTER_SANITIZE_STRING);
	
	//$iso[$i]=filter_var($_POST['iso'.$i], FILTER_SANITIZE_STRING);
	$noa[$i]=filter_var($_POST['isno'.$i], FILTER_SANITIZE_STRING);
}

$flag=1;
$mailsend=0;
if($inum!="" && $pc!=""){
	include "DBconnect.php";
			
		
		$sql1="INSERT INTO responsenew(IndentNumber, DateSupply, TimeSupply, AIFCode, DeliveryPoint, TAName, MSG) 
				values ('$inum', '$dos', '$tos', '$AIFcode', '$dpt', '$tech_name', '$msg')";
		$result1 = mysqli_query($db, $sql1);
		
		if(!$result1){
			 $flag=0;
			$_SESSION['message']="Error ! Contact admin  !";
			echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=Indents.php\">";
			die('Error: ' . mysqli_error($db));
		  }else{
			//mail string
			$str="<html>
				<head>
				<title>Soflam, System generated email</title>
				</head>
				<body>
					<table border=\"1\" style=\"border-color:#666;border-collapse:collapse;\" cellpadding=\"10\">
						<tr style=\"background: #eee;\">
							<th>Protocol</th>
							<th>Date</th>
							<th>Time</th>
							<th>Location</th>
							<th>Tachnical Asst.</th>
							<th>Message</th>
						</tr>";
								
					$str=$str."<tr>
							<td style=\"width:10%\" >".$pc."</td>
							<td style=\"width:15%\">".$dos."</td>
							<td style=\"width:10%\">".$tos."</td>
							<td style=\"width:10%\">".$dpt."</td>
							<td style=\"width:10%\">".$tech_name."</td>
							<td style=\"width:10%\">".$msg."</td>
						</tr>
					";
					$str=$str."<tr>
									<td colspan=\"6\"><div>
										<table border=\"1\" style=\"border-color:#666;border-collapse:collapse;width:90%;\" cellpadding=\"10\">
											<tr>
												<th>Sl. No.</th>
												<th>Animal</th>
												<th>Gender</th>
												<th>Quantity</th>
												<th>Wieght/Age</th>  
											</tr>";
			  
			//partial string ends
			
			$sql21="SELECT DISTINCT ResponseNumber FROM responsenew WHERE IndentNumber='$inum'";
			$resultIN= mysqli_query($db,$sql21);
			
			//if($pass=mysqli_fetch_array($resultIN,MYSQLI_ASSOC)){
			if($pass=mysqli_fetch_array($resultIN,MYSQLI_ASSOC)){
				
				$rnumber=$pass['ResponseNumber'];
				
				for($i=1; $i<=$rowno; $i++){
					//responseanimal(ResponseEntryId, ResponseNumber, SPStrain, Gender, Weight_Age, NoAnimal, IndentNumber)	
					$sql2="INSERT INTO responseanimal(ResponseNumber,SPStrain, Gender, Weight_Age, NoAnimal, IndentNumber) values ('$rnumber','$strain[$i]','$gender[$i]', '$age[$i]', '$noa[$i]','$inum')";
					$result2 = mysqli_query($db, $sql2);
					if(!$result2){	
						$flag=0;
						$_SESSION['message']="Error ! Contact admin  !";
						echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=Indents.php\">";
						die('Error: ' . mysqli_error($db));
					}else{
						$str=$str."<tr>
							<td style=\"width:15%\" >".$i."</td>
							<td style=\"width:15%\" >".$strain[$i]."</td>
							<td style=\"width:15%\">".$gender[$i]."</td>
							<td style=\"width:15%\">".$age[$i]."</td>
							<td style=\"width:15%\">".$noa[$i]."</td>
							</tr>";
					}		
				}
			}
			$str=$str."</table>
							</div>
						</td>
					</tr>
				</table>
			</body>
		</html>";
		}
		
	if($flag==1){
		
		   $mailfrom=$_SESSION['pie'];
		   $piname=$_SESSION['piname'];
		   
		   //projects(ProjectCode, ProjectName, PrincipalInvestigator, ApprovalDate, FromDate, ToDate)
		   //projectincharge(Piname, PiDesignation, PiDepartment, Piphone, Pimobile, PiEmail, PiExperience, PiPasscode, Role, PiAddress, Pin)
		   $querymail="SELECT PiEmail FROM projects WHERE ProjectCode='$pc'";
			//response(ResponseNumber, IndentNumber, DateSupply, TimeSupply, AIFCode, DeliveryPoint, TAName, MSG)
			
			$resultmail = mysqli_query($db,$querymail);
			$i=1;
			if($resultmail){
				while($passmail=mysqli_fetch_array($resultmail,MYSQLI_BOTH)){
					
					$to_email= $passmail['PiEmail'];
					$subject = 'Regarding response of animal request.';
					$headers = "MIME-Version: 1.0" . "\r\n";
					$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
					// More headers
					$headers .= "From: ".$mailfrom."\r\n";
					if(mail($to_email,$subject,$str,$headers)){
						$_SESSION['message']="Succesfully submitted ! Response is sent to Protocol incharge via mail.";
						echo '<META HTTP-EQUIV="Refresh" Content="0; URL=Indents.php">';
					}else{
						$_SESSION['message']="Succesfully submitted ! but fail to send mail, Inform personally  !";
						echo '<META HTTP-EQUIV="Refresh" Content="0; URL=Indents.php">';
					} 
				}
			}else{
				$_SESSION['message']="Succesfully submitted ! but fail to send mail as no mail ID if found to send email. Inform personally  !";
				echo '<META HTTP-EQUIV="Refresh" Content="0; URL=Indents.php">';
			}
	}
	else{
		$sql3="DELETE FROM responsenew WHERE IndentNumber ='$inum' ";
		$result3 = mysqli_query($db, $sql3);
		if(!$result3)
		  {
			//$flag=0;
			$_SESSION['message']="Error ! contact Admin";
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=Indents.php">';
			die('Error: ' . mysqli_error($db));
		  }
		$_SESSION['message']="Fail to Submit Issue animal. Please enter data properly  !";
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=Indents.php">';
	}
	mysqli_close($db);
}else{
	$_SESSION['message']="Invalid input data  ! Failed to submit  !";
	echo '<META HTTP-EQUIV="Refresh" Content="0; URL=Indents.php">';
}

?>
