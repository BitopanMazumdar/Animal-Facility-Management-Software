<?php include "include/sesionlauth.php"; ?>
 <?php 
$rname=filter_var($_POST['rname'], FILTER_SANITIZE_STRING);
$status=1;
$str="";
if($rname!=""){
include "DBconnect.php";
	$sql="INSERT IGNORE INTO rooms(RoomName,Status) values ('$rname', '$status')";

	$Result = mysqli_query($db, $sql);

	if(!$Result)
	  {
		$_SESSION['message']="Fail to add  ! contact admin";
		echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=HouseRooms.php\">";
		
		die('Error: ' . mysqli_error($db));
	  }
	else
	{
		$_SESSION['message']="Successfully Added new room.";
		echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=HouseRooms.php\">";
				
	}
	//$_SESSION['msg']=$str;
mysqli_close($db);
}else{
	$_SESSION['message']="Fail, Invalid input data  !";
	echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=HouseRooms.php\">";	
}
?>
