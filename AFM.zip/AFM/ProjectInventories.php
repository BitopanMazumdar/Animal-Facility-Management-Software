<?php include "include/sesionlauth.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  
</head>
<body style="background-color:#F8F9FA">
	<nav >
		 <div class="container-fluid">
			<?php 
			include"include/headerboot.php"; 
			?>
		  </div>
		  <div class="container-fluid">
			<?php 
			include"include/MenuAi.php"; 
			?>		
		  </div> 
	</nav>
	
 <!-- srcipt strat -->
	<script type="text/javascript">
	$(document).ready(function(){
		$("#displaydiv").slideDown("slow");
	});
	</script>
	<script type="text/javascript">    
	$(document).ready(function(){
			
		$.get("pi_query.php", function(data, status){
		$("#pi").html(data);
		
		});
		$.get("Project_queryAll.php", function(data, status){
		$("#proj").html(data);
		
		});
		var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() {
			  if (this.readyState == 4 && this.status == 200) {
				document.getElementById("viewdata").innerHTML = this.responseText;
				$("#viewdata").slideDown("slow");
				$("#loader").hide();
				
			  }
			};
			
			xmlhttp.open("GET", "ProjectInventoriesByAll.php", true);
			xmlhttp.send();
	});
	</script>

	<script type="text/javascript">
	function showList()
	{	
		$("#viewdata").hide();
		$("#loader").show();
		type=$('input:radio[name=type]:checked').val();
		proj=$('#proj').val();
		pi=$('#pi').val();
		
		if(type==1){
			//window.location='PInvByproject.php?page=inventory&type='+type+'&proj='+proj+'';
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() {
			  if (this.readyState == 4 && this.status == 200) {
				document.getElementById("viewdata").innerHTML = this.responseText;
				$("#viewdata").slideDown("slow");
				$("#loader").hide();
			  }
			};
			
			xmlhttp.open("GET", "PInvByproject.php?proj="+proj, true);
			xmlhttp.send();
		}
		if(type==2){
			//window.location='PinvByPi.php?page=inventory&type='+type+'&pi='+pi+'';
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() {
			  if (this.readyState == 4 && this.status == 200) {
				document.getElementById("viewdata").innerHTML = this.responseText;
				$("#viewdata").slideDown("slow");
				$("#loader").hide();
				
			  }
			};
			
			xmlhttp.open("GET", "PInvByPi.php?pi="+pi, true);
			xmlhttp.send();
		}
	}
	function checkType(val)
	{
	//alert(val);

	$('input:radio[name=type]')[val].checked = true;
		
	}
	</script>
<script type="text/javascript">
function printDiv(divID) {
	
        //Get the HTML of div
        var divElements = document.getElementById(divID).innerHTML;
        //Get the HTML of whole page
        var oldPage = document.body.innerHTML;
        //Reset the page's HTML with div's HTML only
		var htmlToPrint = '' +
        '<style type="text/css">' +
        'table th, table td {' +
        'border:1px solid #000;' +
        'padding;0.5em;' +
        '}' +
        '</style>';
        document.body.innerHTML = 
          "<html><head><title></title></head><body>" +  htmlToPrint + divElements + "</body>";
        //Print Page
        window.print();
        //Restore orignal HTML
        document.body.innerHTML = oldPage;

    }
</script> 

 <!-- srcipt end -->
<div>&nbsp;</div>
<div class="container" id="displaydiv" >
        <div class="col-sm-offset-2 col-sm-8">
            <div class="panel panel-default">
                <div class="panel-heading">
                   Animal Request-Reply information
                </div>

                <div class="panel-body">
                    <!-- submit message -->
						<?php 
								if(isset($_SESSION['message'])){
									echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
									unset($_SESSION['message']);
								}		
						?>
					<!-- submit message -->	

                    <!-- New Task Form -->
                    <form class="form-horizontal">
						<div class="row">
							<div class="radio col-sm-3">
							  <label><input name="type" type="radio" value="1" checked>Protocol</label>
							</div>
							<div class="form-group col-sm-6">
									<select class="form-control" name="proj" id="proj"  onFocus="checkType('0')" >
										<option value="">Select</option>
									</select>
							</div>
						</div>
						<div class="row">
							<div class="radio col-sm-3">
							  <label><input name="type" type="radio" value="2" >Protocol Incharge</label>
							</div>
							<div class="form-group col-sm-6">
								<select class="form-control" name="pi" id="pi" onFocus="checkType('1')" >
									<option value="">Select</option>
								</select>
							</div>
						</div>
						<div class="row">
							<div class="form-group">
								<div class="col-sm-offset-4 col-sm-6">
									
									<button type="button" onClick="showList()" class="btn btn-success">
										<i class="fa fa-btn fa-search"></i> Search
									</button>
								</div>
							</div>
						</div>
					</form>
                </div>
            </div>
		</div>
	</div>
	<div class="container">
        <div class="col-sm-offset-0 col-sm-12">
            <div id="viewdata" class="panel panel-default" style="display:none">
			<!-- load data-->	
			</div>
		</div>
		</div>
	</div>
    
	<div class="container" >
		<div id="loader" class="col-sm-offset-5 col-sm-7 loader">
		</div>
	</div>
	
	<div>&nbsp;</div><div>&nbsp;</div>
	<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
	</div>
	
</body>
</html>