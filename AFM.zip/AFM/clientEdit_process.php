<?php include "include/sesionlauth.php"; ?>
 <?php 
$codeold=filter_var($_POST['codeold'], FILTER_SANITIZE_STRING);
$name = filter_var($_POST['name'], FILTER_SANITIZE_STRING);
$code = filter_var($_POST['code'], FILTER_SANITIZE_STRING);
$rno = filter_var($_POST['rno'], FILTER_SANITIZE_STRING);
$rdate = filter_var($_POST['rdate'], FILTER_SANITIZE_STRING);
 
$address = filter_var($_POST['address'], FILTER_SANITIZE_STRING);

$pin = filter_var($_POST['pin'], FILTER_SANITIZE_STRING);
$email = filter_var($_POST['email1'], FILTER_SANITIZE_STRING);

$mobile = filter_var($_POST['mobile1'], FILTER_SANITIZE_STRING);

$phone = filter_var($_POST['phone1'], FILTER_SANITIZE_STRING);

//client(name, clientID, cType, status, mobile1, mobile2, phone1, phone2, email1, email2, region, cState, city, adderss, pin, cRegNum, cRdate) 

if($codeold!=""){
	include "DBconnect.php";
	
	$query="UPDATE anbuyer SET BCode='$code', Bname='$name', BRegNum='$rno', BRdate='$rdate', BAddress='$address', Bpin='$pin', Bphone='$phone', Bmobile='$mobile', BEmail='$email'  WHERE BCode= '$codeold'" ;
	mysqli_query($db,$query);
		$result = mysqli_affected_rows($db);
		if($result >=0){
			$_SESSION['message']="Successfully edited !";
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=viewClient.php">';
			
		}else{
			$_SESSION['message']="Error  ! Contact admin !";
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=viewClient.php">';
		}
		
		
		mysqli_close($db);
	
}else{
	$_SESSION['message']="Invalid data !";
	echo '<META HTTP-EQUIV="Refresh" Content="0; URL=viewClient.php">';
}
?>