<?php include "include/sesionlauth.php"; ?>
 <?php 
$ProductionNo=filter_var($_POST['ProductionNo'], FILTER_SANITIZE_STRING);
$pcode=filter_var($_POST['pcode'], FILTER_SANITIZE_STRING);
$species=filter_var($_POST['species'], FILTER_SANITIZE_STRING);
$strain=filter_var($_POST['strain'], FILTER_SANITIZE_STRING);
$stock=filter_var($_POST['stock'], FILTER_SANITIZE_STRING);
$qm=filter_var($_POST['qm'], FILTER_SANITIZE_STRING);
$qf=filter_var($_POST['qf'], FILTER_SANITIZE_STRING);

$pdate=filter_var($_POST['pdate'], FILTER_SANITIZE_STRING);
$bdate=filter_var($_POST['bdate'], FILTER_SANITIZE_STRING);
$wdate=filter_var($_POST['wdate'], FILTER_SANITIZE_STRING);
$genotype=filter_var($_POST['genotype'], FILTER_SANITIZE_STRING);
if($pcode=="Acquired"){
	$pcode=filter_var($_POST['scode'], FILTER_SANITIZE_STRING);
};

//production(ProductionCode,Species,strain,StockType,MALE,Female,ProductionDate) 
//values ('$pcode', '$species', '$strain', '$stock', '$qm', '$qf', '$pdate')";
if($pcode!=""){
	include "DBconnect.php";
	
	$query="UPDATE production SET ProductionCode='$pcode', Species='$species', strain='$strain', StockType='$stock', MALE='$qm', Female='$qf', ProductionDate='$pdate', BredDate='$bdate', WeanDate='$wdate', Genotype='$genotype' WHERE ProductionNo= '$ProductionNo'" ;
	mysqli_query($db,$query);
		$result = mysqli_affected_rows($db);
		if($result >=0){
			$_SESSION['message']="Successfully edited  !";
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=InventoryReports.php">';
			mysqli_free_result($result);
		}else{
			$_SESSION['message']="Error, contact admin  !";
			echo '<META HTTP-EQUIV="Refresh" Content="0; URL=InventoryReports.php">';
		}
			
		mysqli_close($db);
	
}else{
	$_SESSION['message']="Error, Invalid input  !";
	echo '<META HTTP-EQUIV="Refresh" Content="0; URL=InventoryReports.php">';
}