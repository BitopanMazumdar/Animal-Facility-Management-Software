<?php if(session_id() == '' || !isset($_SESSION)){
							// session isn't started
							session_start();
} ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal facility management</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">  
  <style>
  .footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   color: white;
   text-align: center;
}
  </style>
</head>
<body >

	<nav >
	  <div class="container-fluid">
		<?php 
		include"include/headerboot.php"; 
		?>
	  </div>
	  <div class="container-fluid">
		<?php 
		include"include/header2.php"; 
		?>		
	  </div>
	</nav>
	
<script type="text/javascript">
$(document).ready(function(){
		$("#displaydiv").slideDown("slow");
});
</script>
	
	
<!-- Login from -->
	<script language="javascript" type="text/javascript" >
	function showNewpassword(){ 
		$("#login").hide();
		$("#forgot").slideDown("slow");
	}
	function showlogin(){ 
		$("#login").slideDown("slow");
		$("#forgot").hide();
	}
	function valid()
	{
		frm = document.myform;
		
		  if(frm.email.value =="")
		  {
				alert("Please enter the Email/User Id ! ");
				frm.email.focus();
				return false;
		  }			  
					  
		   if(frm.pass.value =="")
		  {
				alert("Please enter Password !");
				frm.pass.focus();
				return false;
		  }				  			   
	}
	function validate()
	{
		frm = document.forgot_myform;
		
		if(frm.femail.value =="")
		  {
				alert("Please enter the Email Id/User Id ! ");
				frm.femail.focus();
				return false;
		  }		
		 /* if(frm.newpass.value =="")
		  {
				alert("Please enter new Password ! ");
				frm.newpass.focus();
				return false;
		  }			  
					  
		   if(frm.re_pass.value =="")
		  {
				alert("Please enter Conform Password !");
				frm.re_pass.focus();
				return false;
		  }	
			if(frm.re_pass.value != frm.newpass.value)
		  {
				alert("Password mismatch!");
				frm.re_pass.focus();
				return false;
		  }		*/	  
	}
			
	</script>
	<div class="container" id="displaydiv" style="min-height:100%; position:relative; display:none;" >
		<div class="col-sm-12">&nbsp;</div>
        <div class="col-sm-offset-2 col-sm-8">
            <div class="panel panel-default" id="login">
                <div class="panel-heading">
                    User Login
                </div>

                <div class="panel-body" >
                    <!-- Display Validation Errors -->
                    <!--@include('common.errors')-->

                    <!-- New Task Form -->
                    <form action="login_process.php" name="loginform" method="POST" class="form-horizontal" onsubmit="return valid();">
					<!-- submit message -->
						<?php 
							
								if(isset($_SESSION['message'])){
									echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
									unset($_SESSION['message']);
								}
												
						?>
					<!-- submit message -->
                        <div class="form-group">
							<label for="email" class="col-sm-3 control-label"><i class="fa fa-envelope icon"></i> <span style="color: red">*</span>Email:</label>
							<div class="col-sm-6">
								<input class="form-control" required name="email" type="email" id="email" size="30">
							</div>
						</div>
						<div class="form-group">
							<label for="pass" class="col-sm-3 control-label"><i class="fa fa-key icon"></i>  <span style="color: red">*</span>Password:</label>
							<div class="col-sm-6">
								<input class="form-control" required  name="pass" type="password" id="pass" size="20">
							</div>
						</div>
						<!-- Add Task Button -->
                        <div class="form-group">
                            <div class="col-sm-offset-4 col-sm-6">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-btn fa-sign-in"></i>  Login
                                </button>
								<button type="button" id="fp" class="btn btn-warning" onclick="showNewpassword();"><i class="fa fa-btn fa-key"></i> Forgot  Password
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
			</div>
			<div class="panel panel-default" id="forgot" style="display:none;">
				<div class="panel-heading">
                    Forgot Password
                </div>
				<div class="panel-body" >
                    <!-- Display Validation Errors -->
                    <!--@include('common.errors')-->

                    <!-- New Task Form -->
                    <form action="forgotPass_process.php" name="loginform" method="POST" class="form-horizontal" onsubmit="return valid();">
						<!-- submit message -->
						<?php 
							if(session_id() == '' || !isset($_SESSION)){
								// session isn't started
								session_start();
								if(isset($_SESSION['message'])){
									echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
									unset($_SESSION['message']);
								}
							}						
						?>
						<!-- submit message -->
                        <div class="form-group">
							<label for="femail" class="col-sm-3 control-label"><i class="fa fa-envelope icon"></i><span style="color: red">*</span>Email:</label>
							<div class="col-sm-6">
								<input class="form-control" required name="femail" type="email" id="femail" size="30">
							</div>
						</div>
						
						<!-- Add Task Button -->
                        <div class="form-group">
                            <div class="col-sm-offset-4 col-sm-6">
                                <button type="submit" id="forgot_submit" value="Create" class="btn btn-danger">
                                    <i class="fa fa-btn fa-plus"></i>Create
                                </button>
								<button type="button" onclick="showlogin();" class="btn btn-danger">
                                    <i class="fa fa-btn fa-arrow-left"></i>Back
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
		</div>
    </div>
	<div class="footer" >
		<?php 
			include"include/footerboot.php"; 
		?>
	</div>
</body>
</html> 
	
	
	
	
	 
	