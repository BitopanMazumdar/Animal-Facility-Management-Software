<?php include "include/sesionlauth.php"; ?>
  <?php 
	$sd = filter_var($_GET['sd'], FILTER_SANITIZE_STRING);
	$sd1 = filter_var($_GET['sd1'], FILTER_SANITIZE_STRING);		
	$str="<div class=\"panel-heading\">
				<button type=\"button\" class=\"btn btn-danger\" onclick=\"javascript:printDiv()\" ><i class=\"fa fa-btn fa-print\"></i> Print</button>
				<span class=\"text-primary\" >&nbsp;&nbsp;&nbsp;&nbsp;	Room Fumigation Record</span>
			</div>

			<div class=\"panel-body  table-responsive\" id=\"printdiv\">
				<table class=\"table table-bordered table-hover\">
					<tr>
					<th width=\"11%\" align=\"center\" >Line</th>
					<th width=\"18%\" align=\"center\" >Fumigation Date</th>
					<th width=\"26%\" align=\"center\" >Room No  </th>
					<th width=\"15%\" align=\"left\" >Duration</th>
					<th width=\"28%\" align=\"left\" >Done By </th>
					
					<th class=\"remOnPrint\" >&nbsp;</th>
					</tr>
				<tbody>";	
	if($sd != "" && $sd1 != ""){
			include "DBconnect.php";
			$query= "SELECT * FROM fumigationregister WHERE FumigationDate BETWEEN '$sd' AND '$sd1' ORDER BY FumigationID DESC";
			
			$result = mysqli_query($db,$query);
			if($result){
				$i=1;  
			
				while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
					$str=$str. "<tr >";
					$str=$str. "<td >".$i."</td>";
					$str=$str. "<td >".$pass['FumigationDate']."</td>";
					$str=$str. "<td >" .$pass['RoomNo']. "</td>";
					$str=$str. "<td >" .$pass['Duration']. "</td>";
					$str=$str. "<td >".$pass['FumigationBy']. "</td>";
					$str=$str."<td class=\"remOnPrint\">
							<form action=\"EditFumigation.php\" method=\"POST\">
								<input type=\"hidden\" name=\"prno\" value=\"".$pass['FumigationID']."\">
								<button type=\"submit\" class=\"btn btn-danger\">
									<i class=\"fa fa-btn fa-edit\"></i> Edit
								</button>
							</form>
						</td>";
					$str=$str."</tr>";
					
					$i=$i+1;
				}
									
				if ($i== 1){
					$str=$str. "<tr><td colspan=\"9\" class=\"table-text text-danger\"><div>*No Records found</div></td></tr>";
				}	
			}else{
				$str=$str. "<tr><td colspan=\"9\" class=\"table-text text-danger\"><div>*Error, Contact Admin.</div></td></tr>";
			}
			
		mysqli_close($db);
	}else{
			$str=$str. "<tr><td colspan=\"9\" class=\"table-text text-danger\"><div>*Error, Invalid Input.</div></td></tr>";
	}
	$str=$str."</tbody>
			</table>
		</div>
	</div>";
	echo $str;

	?>
 