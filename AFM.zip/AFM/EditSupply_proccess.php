<?php include "include/sesionlauth.php"; ?>
 <?php 
$inum=filter_var($_POST['inum'], FILTER_SANITIZE_STRING);
$suppliedto=filter_var($_POST['suppliedto'], FILTER_SANITIZE_STRING);
$sdate=filter_var($_POST['sdate'], FILTER_SANITIZE_STRING);
$billno=filter_var($_POST['billno'], FILTER_SANITIZE_STRING);
$SupplyFrom=filter_var($_POST['sname'], FILTER_SANITIZE_STRING);

$rowno= filter_var($_POST['row_no'], FILTER_SANITIZE_STRING);

for($i=1; $i<=$rowno; $i++){
$EntrySupplyNumber[$i]=filter_var($_POST['EntrySupplyNumber'.$i], FILTER_SANITIZE_STRING);
$species[$i]=filter_var($_POST['species'.$i], FILTER_SANITIZE_STRING);
$strain[$i]=filter_var($_POST['strain'.$i], FILTER_SANITIZE_STRING);
$qm[$i]=filter_var($_POST['qm'.$i], FILTER_SANITIZE_STRING);
$qf[$i]=filter_var($_POST['qf'.$i], FILTER_SANITIZE_STRING);
$stock[$i]=filter_var($_POST['stock'.$i], FILTER_SANITIZE_STRING);
}

$flag=1;
if($suppliedto!="" && $sdate!="" && $SupplyFrom!=""){
	include "DBconnect.php";
	
	//supply(SupplyID, SupplyTo, Supplydate, SupplyFrom, SupplyBillNo, PorT)
	$query="UPDATE supply SET Supplydate='$sdate', SupplyFrom='$SupplyFrom', SupplyBillNo='$billno' WHERE SupplyTo= '$suppliedto' AND SupplyID='$inum'" ;
	mysqli_query($db,$query);
		$result = mysqli_affected_rows($db);
		if($result>=0){
			$flag=1;			
			
		}
		for($i=1; $i<=$rowno; $i++){
				//supplyanimal(EntrySupplyNumber, SupplyID, Species, strain, StockType, MALE, Female) 
				//values ('$sid','$species[$i]','$strain[$i]','$stock[$i]','$qm[$i]','$qf[$i]'		
				$sql2="UPDATE supplyanimal SET species='$species[$i]', strain='$strain[$i]', StockType='$stock[$i]', MALE='$qm[$i]', Female='$qf[$i]' WHERE EntrySupplyNumber= '$EntrySupplyNumber[$i]' AND SupplyID='$inum'";
				$result2 = mysqli_query($db, $sql2);
				if($result2 < 0)
				  {						
					$flag=0;
				  }							
		}
		if($flag==1){
			$_SESSION['message']="Successfully Edited Data  !";
			echo'<META HTTP-EQUIV="Refresh" Content="0; URL=SupplyReport.php">';
		}else{
			
			$_SESSION['message']="Error, Contact Admin  !";
			echo'<META HTTP-EQUIV="Refresh" Content="0; URL=SupplyReport.php">';
			die();
		}
		
		mysqli_close($db);
	
}else{
	$_SESSION['message']="Error, Invalid input  !";
	echo'<META HTTP-EQUIV="Refresh" Content="0; URL=SupplyReport.php">';
}
