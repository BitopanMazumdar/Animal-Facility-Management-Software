
<?php include "include/sesionlauth.php"; ?>
<?php 
		      
    $str = "<select><option value=\"\">Select</option>";	
	include "DBconnect.php";
	
	$result = mysqli_query($db,"SELECT DISTINCT Species FROM animals ORDER BY Species DESC" );
	
	
	while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
		
		$str = $str . "<option value=\"" .$pass['Species']. "\">".$pass['Species']."</option>";
		
	}
	$result1 = mysqli_query($db,"SELECT DISTINCT strain FROM animals ORDER BY strain DESC" );
	
	while($pass1=mysqli_fetch_array($result1,MYSQLI_ASSOC)){
		
		$str = $str . "<option value=\"" .$pass1['strain']. "\">".$pass1['strain']."</option>";
		
	}
		
	echo $str;
	mysqli_free_result($result);
	mysqli_free_result($result1);
	mysqli_close($db);
		
?>	