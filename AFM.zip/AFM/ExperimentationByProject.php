<?php include "include/sesionlauth.php"; ?>
 <?php 
	$proj = filter_var($_GET['proj'], FILTER_SANITIZE_STRING);	
	$str="<div class=\"panel-heading\">
				<button type=\"button\" class=\"btn btn-danger\" onclick=\"javascript:printDiv()\" ><i class=\"fa fa-btn fa-print\"></i> Print</button>
				<span class=\"text-primary\" >&nbsp;&nbsp;&nbsp;&nbsp;	List of Experimentation data</span>
			</div>

			<div class=\"panel-body  table-responsive\" id=\"printdiv\">
				<table class=\"table table-striped table-hover\">
				<thead>
					<th>S.No. </th>
					<th>Date </th>
					<th>Protocol </th>
					<th>Done By </th>
					<th>Species/Strain</th>
					<th>Gender</th>
					<th>Quantity</th>
					<th>Group</th>
					<th>Route</th>
					<th>Sample Type</th>
					<th>ST Value</th>
					<th>Interval</th>
					<th>Interval Value</th>
					<th class=\"remOnPrint\" >&nbsp;</th>
				</thead>
				<tbody>";	
		
	if($proj != "" ){
		include "DBconnect.php";
		//experimentationform(ExperimentationNumber, Projectcode, Title, ExperimentBy, ExperimentDate, ExpGroup, Route, SampleCollection, SCInterval)
			$query= "SELECT ExperimentationNumber, Projectcode, Title, ExperimentBy, ExperimentDate, ExpGroup, Route, SampleCollection, SCInterval,SCvalue,SIvalue FROM experimentationform WHERE Projectcode='$proj' ORDER BY ExperimentationNumber DESC ";
			
			$result = mysqli_query($db,$query);
						
			$i=1; 
			
				while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
					//experimentationform(ExperimentationNumber, Projectcode, Title, ExperimentBy, ExperimentDate, ExpGroup, Route, SampleCollection, SCInterval)			
					//experimentationanimal`(`EntryNo`, `ExperimentationNumber`, `SpStrain`, `Gender`, `Weight_Age`, `NoAnimal`)
					
					$disNumber=$pass['ExperimentationNumber'];
					$query1= "SELECT SpStrain, Gender, NoAnimal FROM experimentationanimal WHERE ExperimentationNumber = '$disNumber'";			
					$result1 = mysqli_query($db,$query1);
					
					while($pass1=mysqli_fetch_array($result1,MYSQLI_ASSOC)){
						$str=$str. "<tr bgcolor=\"#FFFFFF\">";
						$str=$str. "<td class=\"table-text\"><div>".$i."</div></td>";
						$str=$str. "<td class=\"table-text\"><div>".$pass['ExperimentDate']."</div></td>";		
						$str=$str. "<td class=\"table-text\"><div>".$pass['Projectcode']."</div></td>";
						$str=$str. "<td class=\"table-text\"><div>".$pass['ExperimentBy']."</div></td>";
						
						$str=$str. "<td class=\"table-text\"><div>".$pass1['SpStrain']."</div></td>";
						$str=$str. "<td class=\"table-text\"><div>".$pass1['Gender']."</div></td>";
						$str=$str. "<td class=\"table-text\"><div>".$pass1['NoAnimal']."</div></td>";
						$str=$str. "<td class=\"table-text\"><div>" .$pass['ExpGroup']. "</div></td>";
						$str=$str. "<td class=\"table-text\"><div>" .$pass['Route']. "</div></td>";
						$str=$str. "<td class=\"table-text\"><div>" .$pass['SampleCollection']. "</div></td>";
						$str=$str. "<td class=\"table-text\"><div>" .$pass['SCvalue']. "</div></td>";
						$str=$str. "<td class=\"table-text\"><div>" .$pass['SCInterval']. "</div></td>";
						$str=$str. "<td class=\"table-text\"><div>" .$pass['SIvalue']. "</div></td>";
						$str=$str."<td class=\"remOnPrint\">
								<form action=\"EditExperimentation.php\" method=\"POST\">
									<input type=\"hidden\" name=\"disnumber\" value=\"".$pass['ExperimentationNumber']."\">
									<button type=\"submit\" class=\"btn btn-danger\">
										<i class=\"fa fa-btn fa-edit\"></i> Edit
									</button>
								</form>
							</td>";
						$str=$str."</tr>";
										
						$i=$i+1;
					}
				}			
				if ($i== 1){
					$str=$str. "<tr><td colspan=\"13\" class=\"table-text text-danger\"><div>*No records found.</div></td></tr>";
				}	
				
		mysqli_close($db);
	}else{
		echo "<tr height="."30"."><td colspan="."13"." align="."center"." bgcolor="."red"." >You have not selected any option !</td></tr>";
		$str=$str. "<tr><td colspan=\"13\" class=\"table-text text-danger\"><div>*Error, You have not selected any option.</div></td></tr>";
	}
		$str=$str."</tbody>
			</table>
		</div>
	</div>";
	echo $str;
	?>
		