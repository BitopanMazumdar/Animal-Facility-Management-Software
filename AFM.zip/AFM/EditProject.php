<?php include "include/sesionlauth.php"; ?>
<?php 
 //projects(ProjectCode, ProjectName, PrincipalInvestigator, ApprovalDate, FromDate, ToDate, PiEmail, created_at, updated_at, author)
$pcode=filter_var($_POST['prno'], FILTER_SANITIZE_STRING);
if($pcode!=""){
include"DBconnect.php";
	$query= "SELECT * FROM projects WHERE ProjectCode = '$pcode' ";
	$result = mysqli_query($db,$query);
	if($result){
		if($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
	?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  
</head>
<body style="background-color:#F8F9FA">
	<nav >
		 <div class="container-fluid">
			<?php 
			include"include/headerboot.php"; 
			?>
		  </div>
		  <div class="container-fluid">
			<?php 
			include"include/MenuAi.php"; 
			?>		
		  </div> 
	</nav>
	
 <!-- srcipt strat -->
<script type="text/javascript">
$(document).ready(function(){
	$("#displaydiv").slideDown("slow");
});
</script>
<script type="text/javascript">
function valid(){
	frm = document.myform;
	 	  
	  if(frm.name.value =="")
	  {
			alert("Please enter Project Name !");
			frm.name.focus();
			return false;
	  }
	  
	  if(frm.pi.value =="")
	  {
			alert("Please enter Project Incharge !");
			frm.pi.focus();
			return false;
	  }
	  if(frm.doa.value =="")
	  {
			alert("Please enter Date of Approval !");
			frm.doa.focus();
			return false;
	  }
	  if(frm.dfrom.value =="")
	  {
			alert("Please enter Duration of Approval From Date!");
			frm.dfrom.focus();
			return false;
	  }
	  if(frm.dto.value =="")
	  {
			alert("Please enter Duration of Approval To Date !");
			frm.dto.focus();
			return false;
	  } 
	   var txt;
  var r = confirm("confirm submit!");
  if (r == true) {
    return true;
  } else {
	frm.name.focus();
    return false
  }
	
	  
}
</script>		
<!-- End of validation -->
 <!-- srcipt end -->
<div>&nbsp;</div>
 <div class="container" >
        <div class="col-sm-offset-2 col-sm-8 ">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="row col-sm-12">
						<div class="col-sm-6">
						<h4><span class="col-sm-12 text-primary"><i class="fa fa-archive"></i> Protocol Management </span></h4>
						</div>
						<div class="col-sm-3">
						<form class="form horizontal" action="EditSpStrainDetails.php" method="POST" name="editanimal">
							<input class="col-sm-8" type="hidden" name="pid" value="<?php echo $pcode; ?>">
							<button type="submit" class="btn btn-danger">
								<i class="fa fa-btn fa-edit"></i>Edit Animal
							</button>
						</form>
						</div>
						<div class="col-sm-3">
						<form class="form horizontal" action="AddProjSpStrain.php" method="POST" name="addanimal">
							<input class="col-sm-8" type="hidden" name="pid" value="<?php echo $pcode; ?>">
							<button type="submit" class="btn btn-success">
								<i class="fa fa-btn fa-plus"></i>ADD Animal
							</button>
						</form>
						</div>
					</div>	
                </div>

                <div class="panel-body">
                    <!-- submit message -->
						<?php 
								if(isset($_SESSION['message'])){
									echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
									unset($_SESSION['message']);
								}		
						?>
					                    
                </div>
            </div>
		</div>
</div>
 <div class="container" id="displaydiv" style="display:none">
        <h4 class="text-primary"><i class="fa fa-edit "></i> Edit Protocol Information </h4>
        <form action="EditPD_Proccess.php" name="myform" method="post" onSubmit="return valid();" class="form-horizontal" >
        <!-- submit message -->
					<?php 
						
							if(isset($_SESSION['message'])){
								echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
								unset($_SESSION['message']);
							}
												
					?>
		<!-- submit message -->
			<div class="form-group">
				<label for="code" class="col-sm-3 control-label"><span style="color: red">*</span>Protocol:</label>
				<div class="col-sm-6">
					<input class="form-control" readonly required name="code" type="text" id="code" value="<?php echo $pcode; ?>"/>
				</div>
			</div>
			<div class="form-group">
				<label for="name" class="col-sm-3 control-label"><span style="color: red">*</span>Title:</label>
				<div class="col-sm-6">
					<textarea class="form-control" style="text-transform:capitalize;" name="name" rows="2" cols="30" id="name" type="text"><?php echo htmlspecialchars($pass['ProjectName']); ?></textarea>
				</div>
			</div>
			
			<div class="form-group">
				<label for="pi" class="col-sm-3 control-label"><span style="color: red">*</span>Incharge:</label>
				<div class="col-sm-6">
					<select readonly class="form-control" required name="pi" id="pi">
						<option value="<?php echo htmlspecialchars($pass['PrincipalInvestigator']); ?>"><?php echo htmlspecialchars($pass['PrincipalInvestigator']); ?></option>			  
					</select> 
				</div>
			</div>
			<div class="form-group">
				<label for="email" class="col-sm-3 control-label"><span style="color: red">*</span>Email ID:</label>
				<div class="col-sm-6">
					<input class="form-control col-sm-6" readonly required name="email" type="email" id="email" placeholder="Enter email id" value="<?php echo htmlspecialchars($pass['PiEmail']); ?>" />
					
				</div>
			</div>
			<div class="form-group">
				<label for="doa" class="col-sm-3 control-label">Date of CPCSEA Approval:</label>

				<div class="col-sm-6">
					<input class="form-control" required   name="doa" type="date" id="doa" value="<?php echo htmlspecialchars($pass['ApprovalDate']); ?>"/>
				</div>
			</div>
			<div class="form-group">
				<label for="idoa" class="col-sm-3 control-label">Date of IEAC Approval:</label>

				<div class="col-sm-6">
					<input class="form-control" required   name="idoa" type="date" id="idoa" value="<?php echo htmlspecialchars($pass['IeacApprove']); ?>"/>
				</div>
			</div>
			<div class="form-group">
				<label for="dfrom" class="col-sm-3 control-label">Duration Form:</label>

				<div class="col-sm-6">
					<input class="form-control" required  name="dfrom" type="date" id="dfrom" value="<?php echo htmlspecialchars($pass['FromDate']); ?>" />
				</div>
			</div>
			<div class="form-group">
				<label for="dto" class="col-sm-3 control-label">Duration To:</label>

				<div class="col-sm-6">
					<input class="form-control" required  name="dto" type="date" id="dto" value="<?php echo htmlspecialchars($pass['ToDate']); ?>" />
				</div>
			</div> 
			<div class="form-group">
				<label for="remark" class="col-sm-3 control-label">Remark:</label>

				<div class="col-sm-6">
					<input class="form-control"   name="remark" type="text" id="remark"  value="<?php echo htmlspecialchars($pass['Remarks']); ?>" />
				</div>
			</div>
			<!-- Add Task Button -->
			<div class="form-group">
				<div class="col-sm-offset-4 col-sm-6">
					<button type="submit" class="btn btn-danger">
						<i class="fa fa-btn fa-user-edit"></i> 	Edit protocol</button> 
					<button type="reset" class="btn btn-primary"><i class="fa fa-btn fa-refresh">
						</i> Reset</button> 
					<button type="button" class="btn btn-warning" onclick="window.history.back()">
						<i class="fa fa-btn fa-arrow-circle-left"></i> Back</button>
					</button>
				</div>
			</div>
		</form>
    </div>
	<div>&nbsp;</div>
	<div>&nbsp;</div>
	
	<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
	</div>
	
</body>
</html>	
<?php 
	}
}
}
?> 