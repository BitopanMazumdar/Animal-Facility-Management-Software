<?php include "include/sesionlauth.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  <link rel="stylesheet" href="css/custom.css">
  
</head>
<body style="background-color:#F8F9FA">
<nav >
 <div class="container-fluid">
	<?php 
	include"include/headerboot.php"; 
	?>
  </div>
  <div class="container-fluid">
	<?php 
	include"include/MenuAi.php"; 
	?>		
  </div> 
</nav>
<script type="text/javascript">
$(document).ready(function(){
		$("#displaydiv").slideDown("slow");
});
</script>
<script type="text/javascript">
function getCompany(name){
	 $("#code").val(name);
}
</script>
<script language="javascript" type="text/javascript" >
	function valid()
	{
		frm = document.clientform;
		var patt = /[%*+;<=>^]/;
		if(frm.address.value !=""){
			if(patt.test(frm.address.value)){
				alert("invalid company address ! special characters: %*+;<=>^ are not allowed");
				frm.address.focus();
				return false;
			}
		}
		
		r=confirm("confirm submission!");
		if(r==true){
		  return true;
		}else{
		  frm.name.focus;
		  return false;
		}
		   
	}
</script>
<script type="text/javascript">
document.getElementById("code").onchange = function() {checkEmail()};
function checkEmail(){
	
	var mail = document.getElementById('name').value;
	 
	$.get("code_query.php",{code:mail}, function(data, status){
		
		 if(data==1){
			//$("#emailok").hide();
			 document.getElementById("emailexist").innerHTML = "client name/code already exsist ! select code different from client name !";
			 
			 $("#emailexist").slideDown("slow");
			 $("#code").val("");
		 }else{
			 $("#emailexist").hide();
			 $("#code").val(mail);
			 //document.getElementById('emailok').innerHTML="<img src='images/right.jpg' alt='Email ok' height='10' width='32' />";
			 //$("#emailok").slideDown("slow");
		 }
	});
	
	
}
</script>		

<div>&nbsp;</div>

<div class="container" id="displaydiv" style="display:none">
  
  <div class="panel panel-default">
                <div class="panel-heading">
					<span class="text-primary">Client Management<button type="button" class="btn btn-danger col-sm-offset-7" onClick="document.location.href='viewClient.php'"><i class="fa fa-btn fa-plus"></i> View Client 
					</button></span>
                </div>

                <div class="panel-body">
  <form class="form-horizontal" name="clientform" action="client_process.php" method="POST" onsubmit="return valid();">
	<!-- submit message -->
		<?php 
			
				if(isset($_SESSION['message'])){
					echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
					unset($_SESSION['message']);
				}
								
		?>
	<!-- submit message -->
    <div class="form-group">
      <label class="control-label col-sm-2" for="name"><span style="color: red">*</span>Client Name:</label>
      <div class="col-sm-8">
        <input style="text-transform:capitalize;" pattern="[0-9\\A-Za-z\s.,(&/)]*" title="Special characters: . , are allowed only" required type="text" class="form-control" id="name" placeholder="Enter Client Name" name="name" onchange="checkEmail();"/>
      </div>
    </div>
	<div class="form-group">
      <label class="control-label col-sm-2" for="code"><span style="color: red">*</span>Client Code:</label>
      <div class="col-sm-6">
        <input style="text-transform:capitalize;" pattern="[0-9\\A-Za-z\s.,(&/)]*" title="Special characters: . , are allowed only" required type="text" class="form-control" id="code" placeholder="Enter Client Code" name="code"  />
		<div class="alert alert-danger col-sm-6" id="emailexist" style="display:none"> </div>
					<!--
					<p id="emailok" style="display:none"></p>
					<div class="alert alert-success col-sm-1 col-sm-offset-9" id="emailok" style="display:none"> 
					</div>-->
	  </div> 
    </div>
	
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group">
				<label class="control-label col-sm-4" for="rno"><span style="color: red">*</span>Registration No.:</label>
				<div class="col-sm-7 ">
				<input pattern="[A-Za-z\\0-9\s/-]*" title="Special characters: \,/,- are allowed only" required type="text" class="form-control" id="rno" placeholder="Enter Registration No." name="rno"/>
				</div>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label class="control-label col-sm-4" for="rdate"><span style="color: red">*</span>Registration Date:</label>
				<div class="col-sm-6">
				<input required type="date" class="form-control" id="rdate" placeholder="Enter Client Code" name="rdate"/>
				</div>
			</div>
		</div>
	</div>
	
			
	<div class="form-group">
      <label class="control-label col-sm-2" for="address"><span style="color: red">*</span>Address:</label>
      <div class="col-sm-8">
        <textarea required style="text-transform: capitalize;" class="form-control" id="address" placeholder="Enter Address" name="address"></textarea>
      </div>
    </div>
	
	
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group">
				<label class="control-label col-sm-4" for="pin">PIN:</label>
				<div class=" col-sm-6">
				<input pattern="[0-9]{6}" title="6 digit pin allowed only" type="text" class="form-control" id="pin" placeholder="Enter Pin number" name="pin"/>
				</div>
			</div>
		</div>
		
	</div>
	
		<div class="form-group">
		  <label class="control-label col-sm-2" for="email1">Email:</label>
		  <div class="col-sm-8">
			<input type="email" class="form-control" id="email1" placeholder="Enter Email" name="email1"/>
		  </div>
		</div>
	
	
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group">
				<label class="control-label col-sm-4" for="phone1">Phone No.:</label>
				<div class=" col-sm-6">
				<input pattern="[0-9\/\+\s-]{9,}" type="tel" title="digit + - and / allowed only" type="text" class="form-control" id="phone1" placeholder="Enter Phone No." name="phone1"/>
				</div>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label class="control-label col-sm-4" for="mobile1">Mobile No.:</label>
				<div class=" col-sm-6">
				<input pattern="[0-9\+\s-]{9,}" title="digits + - allowed only minimum length:9 " type="text" class="form-control" id="mobile1" placeholder="Enter Mobile No." name="mobile1"/>
				</div>
			</div>
		</div>
	</div>
			
    <div class="form-group">
		<div>&nbsp;</div>
      <div class="col-sm-offset-4 col-sm-8">
        <button type="submit" class="btn btn-danger">
		<i class="fa fa-btn fa-plus"></i> Add Client
		</button>
		<button type="reset" class="btn btn-info"><i class="fa fa-btn fa-refresh"></i> Reset</button> 
		<button type="button" class="btn btn-warning" onclick="window.history.back()"><i class="fa fa-btn fa-arrow-circle-left"></i> Back</button>
      </div>
    </div>
 
	</form>
</div></div></div>
<div>&nbsp;</div><div>&nbsp;</div>
<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
</div>
</body>
</html>
