<?php include "include/sesionlauth.php"; ?>
 
<?php 
					
	include"DBconnect.php";
	//meeting(MeetingID, Minutes, MDocumentTitle, MReferenceDate, DocumentName)
	$result = mysqli_query($db,"SELECT DISTINCT MDocumentTitle FROM meeting");
	
	$str = "<option value=\"\">Select</option>";
	while($pass=mysqli_fetch_array($result,MYSQLI_ASSOC)){
		
		$str = $str ."<option value=\"".$pass['MDocumentTitle']."\">".$pass['MDocumentTitle']."</option>";
				
	}
	echo $str;
	mysqli_free_result($result);
	mysqli_close($db);
		
	?>
