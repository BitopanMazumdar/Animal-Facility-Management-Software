<?php include "include/sesionlauth.php"; ?>
 <?php 
	  
	  $fdate=filter_var($_GET['fd'], FILTER_SANITIZE_STRING);
	  $tdate=filter_var($_GET['td'], FILTER_SANITIZE_STRING);
	  //$str=$str. $prc;
	//session_start();
						
	
	$str="<div class=\"panel-heading\">
			
			<button type=\"button\" class=\"btn btn-danger\" onclick=\"javascript:printDiv('printdiv')\" ><i class=\"fa fa-btn fa-print\"></i> Print</button>
			<span class=\"text-primary\" >&nbsp;&nbsp;&nbsp;&nbsp;	Protocol List</span>
		</div>

		<div class=\"panel-body  table-responsive\" id=\"printdiv\">
			<table class=\"table table-bordered table-hover\">
				<thead>
				<th width=\"6%\" rowspan=\"2\"  ><strong>Date</strong></th>
				<th width=\"10%\" rowspan=\"2\"  ><strong>IAEC/ CPCSEA permission number and Date </strong></th>
				<th colspan=\"4\"  ><strong>Animal bred[B] / acquire [A] </strong></th>
				<th colspan=\"3\"  ><strong>Acquired from [if acquired, not bred] </strong></th>
				<th width=\"6%\" rowspan=\"2\"  ><strong>Period of experimental procedure </strong></th>
				<th width=\"10%\" rowspan=\"2\"  ><strong>Name and address of person authorising experment </strong></th>
				</tr>
				<tr>
				<th width=\"7%\"  ><strong>Species</strong></th>
				<th width=\"7%\"  ><strong>Gender</strong></th>
				<th width=\"6%\"  ><strong>Weight/ Age</strong></th>
				<th width=\"6%\"  ><strong>(Approved/ Issued) </strong></th>
				<th width=\"9%\"  ><strong>Name</strong></th>
				<th width=\"12%\"  ><strong>Address</strong></th>
				<th width=\"9%\"  ><strong>Registration Number </strong></th>
				</thead>
				<tbody>";
	
	//`indentform`(`IndentNumber`, `Projectcode`, `Title`, `RName`, `ARDate`, `IndentTime`, `Duration`, `TAssistance`, `SRequest`, `IndentDate`)
	//`indentanimal`(`EntryNo`, `IndentNumber`, `ProjectCode`, `SpStrain`, `Gender`, `Weight_Age`, `NoAnimal`)
	//`projects`(`ProjectCode`, `ProjectName`, `PrincipalInvestigator`, `ApprovalDate`, `FromDate`, `ToDate`)
	//$query1="SELECT Projectcode AS pc, Species, strain, Weight, Age, ReceiverName, PeriodOfExperimental, IndentDate, MALE, Female, Any FROM indentsform ";
	
	if($tdate != "" && $fdate != ""){
		include "DBconnect.php";
		$i=1;
		$queryPr="SELECT * FROM projects ORDER BY FromDate DESC"; //query for name addrees project incharge
		$resultPr = mysqli_query($db,$queryPr);
	while($passPr=mysqli_fetch_array($resultPr,MYSQLI_ASSOC)){
			
		$prcode= $passPr['ProjectCode'];
		$pname= $passPr['PrincipalInvestigator'];
		$Duration="";
		$Duration=$passPr['FromDate']." to ".$passPr['ToDate'];
		$piemail=$passPr['PiEmail'];
		$piaddress="Address not mentioned";
		$queryAd="SELECT PiAddress FROM projectincharge WHERE PiEmail='$piemail'  "; //query for address of PI 
		$resultAd = mysqli_query($db,$queryAd);
		if($passAd=mysqli_fetch_array($resultAd,MYSQLI_ASSOC)){
			$piaddress=$passAd['PiAddress'];
		}
		$queryIn="SELECT * FROM supply WHERE SupplyTo='$prcode'"; //query for animal specification		
		$resultIn = mysqli_query($db,$queryIn);
		while($passIn=mysqli_fetch_array($resultIn,MYSQLI_ASSOC)){
					
			$SupplyID=$passIn['SupplyID'];
			$SupplyFrom=$passIn['SupplyFrom'];
			$queryIa="SELECT EntrySupplyNumber, Species, strain, MALE, Female FROM supplyanimal WHERE SupplyID ='$SupplyID'"; //query for animal specification
			$resultIa = mysqli_query($db,$queryIa);
			while($passIa=mysqli_fetch_array($resultIa,MYSQLI_ASSOC)){
				$EntrySupplyNumber=$passIa['EntrySupplyNumber'];	
				$Species=$passIa['Species'];
				$Strain=$passIa['strain'];
				//$gen=$passIa['Gender'];				
				$supplierAddress= "";
				$supplierPin= "";
				$supplierName= "";
				$supplierRegNo="";	
				
				$queryAs="SELECT SAddress,Spin,Sname,RegNum FROM ansupplier WHERE SCode='$SupplyFrom' "; //query for animal supplier code
				$resultAs = mysqli_query($db,$queryAs);
					
				if($passAs=mysqli_fetch_array($resultAs,MYSQLI_ASSOC)){
					$supplierAddress= $passAs['SAddress'];
					$supplierPin= $passAs['Spin'];
					$supplierName= $passAs['Sname'];
					$supplierRegNo= $passAs['RegNum'];
				}
					
				if($Strain==""){
					$animal=$Species;
					
				}else{
					$animal=$Strain;
					
				}		
					
												
				$supMale=$passIa['MALE'];
				$supFemale=$passIa['Female'];
				if($supMale!=0 && $supFemale!=0){
					//`projectanimal`(`EntryNumber`, `ProjectCode`, `SpStrain`, `Gender`, `Weight_Age`, `NoAnimal`)
					$AppNumberMale=0;
					$Weight_AgeM="-";
					$queryAppMale="SELECT  NoAnimal,Weight_Age FROM projectanimal WHERE ProjectCode='$prcode' AND SpStrain='$animal' AND (Gender='Male' OR Gender='Any')"; 
					//query for no of animal approved
					$resultAppMale = mysqli_query($db,$queryAppMale);
					if(!$resultAppMale){
						die(mysqli_error($db));
					}else{
						
						if($passAppMale=mysqli_fetch_array($resultAppMale,MYSQLI_ASSOC)){
							$AppNumberMale=$passAppMale['NoAnimal'];
							$Weight_AgeM=$passAppMale['Weight_Age'];
						}
					}
					$AppNumberFemale=0;
					$Weight_AgeF="-	";
					$queryAppFemale="SELECT  NoAnimal,Weight_Age FROM projectanimal WHERE ProjectCode='$prcode' AND SpStrain='$animal' AND (Gender='Female' OR Gender='Any')";  
					//query for no of animal approved
					$resultAppFemale = mysqli_query($db,$queryAppFemale);					
					if($passAppFemale=mysqli_fetch_array($resultAppFemale,MYSQLI_ASSOC)){
						$AppNumberFemale=$passAppFemale['NoAnimal'];
						$Weight_AgeF=$passAppFemale['Weight_Age'];
					}
					$str=$str."<tr>
						<td class=\"table-text\">".$passIn['Supplydate']."</div></td>
						<td class=\"table-text\">".$prcode."</div></td>
						
						<td class=\"table-text\">".$animal."</div></td>
						<td class=\"table-text\">Male/Any</div></td>
						<td class=\"table-text\">".$Weight_AgeM."</div></td>
						<td class=\"table-text\">".$passIa['MALE']." (".$AppNumberMale.")</div></td>
						
						<td class=\"table-text\">".$supplierName."</div></td>
						<td class=\"table-text\">".$supplierAddress."-".$supplierPin."</div></td>
						<td class=\"table-text\">".$supplierRegNo."</div></td>
						
						<td class=\"table-text\">".$Duration."</div></td>
						<td class=\"table-text\">" .$pname.",<br/> ".$piaddress."</div></td>
						</tr>";
					$i++;
					$str=$str."<tr>
						<td class=\"table-text\">".$passIn['Supplydate']."</div></td>
						<td class=\"table-text\">".$prcode."</div></td>
						
						<td class=\"table-text\">".$animal."</div></td>
						<td class=\"table-text\">Female/Any</div></td>
						<td class=\"table-text\">".$Weight_AgeF."</div></td>
						<td class=\"table-text\">".$passIa['Female']." (".$AppNumberFemale.")</div></td>
						
						<td class=\"table-text\">".$supplierName."</div></td>
						<td class=\"table-text\">".$supplierAddress."-".$supplierPin."</div></td>
						<td class=\"table-text\">".$supplierRegNo."</div></td>
						
						<td class=\"table-text\">".$Duration."</div></td>
						<td class=\"table-text\">" .$pname.",<br/> ".$piaddress."</div></td>
						</tr>";
					$i++;
					
				}elseif($supMale!=0){
					//`projectanimal`(`EntryNumber`, `ProjectCode`, `SpStrain`, `Gender`, `Weight_Age`, `NoAnimal`)
					$AppNumberMale=0;
					$Weight_AgeM="-";
					$queryAppMale="SELECT NoAnimal,Weight_Age FROM projectanimal WHERE ProjectCode='$prcode' AND SpStrain='$animal' AND (Gender='Male' OR Gender='Any' )"; 
					//query for no of animal approved
					$resultAppMale = mysqli_query($db,$queryAppMale);
					if(!$resultAppMale){
						die(mysqli_error($db));
					}else{
						
						if($passAppMale=mysqli_fetch_array($resultAppMale,MYSQLI_ASSOC)){
							$AppNumberMale=$passAppMale['NoAnimal'];
							$Weight_AgeM=$passAppMale['Weight_Age'];
						}
					}
					$str=$str."<tr>
						<td class=\"table-text\">".$passIn['Supplydate']."</div></td>
						<td class=\"table-text\">".$prcode."</div></td>
						
						<td class=\"table-text\">".$animal."</div></td>
						<td class=\"table-text\">Male/Any</div></td>
						<td class=\"table-text\">".$Weight_AgeM."</div></td>
						<td class=\"table-text\">".$passIa['MALE']." (".$AppNumberMale.")</div></td>
						
						<td class=\"table-text\">".$supplierName."</div></td>
						<td class=\"table-text\">".$supplierAddress."-".$supplierPin."</div></td>
						<td class=\"table-text\">".$supplierRegNo."</div></td>
						
						<td class=\"table-text\">".$Duration."</div></td>
						<td class=\"table-text\">" .$pname.",<br/> ".$piaddress."</div></td>
						</tr>";
					$i++;
				}elseif($supFemale!=0){
					$AppNumberFemale=0;
					$Weight_AgeF="-	";
					$queryAppFemale="SELECT NoAnimal,Weight_Age FROM projectanimal WHERE ProjectCode='$prcode' AND SpStrain='$animal' AND (Gender='Female' OR Gender='Any')"; 
					//query for no of animal approved
					$resultAppFemale = mysqli_query($db,$queryAppFemale);					
					if($passAppFemale=mysqli_fetch_array($resultAppFemale,MYSQLI_ASSOC)){
						$AppNumberFemale=$passAppFemale['NoAnimal'];
						$Weight_AgeF=$passAppFemale['Weight_Age'];
					}
					$str=$str."<tr>
						<td class=\"table-text\">".$passIn['Supplydate']."</div></td>
						<td class=\"table-text\">".$prcode."</div></td>
						
						<td class=\"table-text\">".$animal."</div></td>
						<td class=\"table-text\">Female/Any</div></td>
						<td class=\"table-text\">".$Weight_AgeF."</div></td>
						<td class=\"table-text\">".$passIa['Female']." (".$AppNumberFemale.")</div></td>
						
						<td class=\"table-text\">".$supplierName."</div></td>
						<td class=\"table-text\">".$supplierAddress."-".$supplierPin."</div></td>
						<td class=\"table-text\">".$supplierRegNo."</div></td>
						
						<td class=\"table-text\">".$Duration."</div></td>
						<td class=\"table-text\">" .$pname.",<br/> ".$piaddress."</div></td>
						</tr>";
					$i++;
				}else{
					$str=$str."<tr>
						<td class=\"table-text\">".$passIn['Supplydate']."</div></td>
						<td class=\"table-text\">".$prcode."</div></td>
						
						<td class=\"table-text\">-</div></td>
						<td class=\"table-text\">-</div></td>
						<td class=\"table-text\">-</div></td>
						<td class=\"table-text\">-</div></td>
						
						<td class=\"table-text\">".$supplierName."</div></td>
						<td class=\"table-text\">".$supplierAddress."-".$supplierPin."</div></td>
						<td class=\"table-text\">".$supplierRegNo."</div></td>
						
						<td class=\"table-text\">".$Duration."</div></td>
						<td class=\"table-text\">" .$pname.",<br/> ".$piaddress."</div></td>
						</tr>";
					$i++;
					}
				}	
			}
		}
		
		if($i==1){
			$str=$str. "<tr ><td colspan=\"11\" class=\"norecord\">*No records found</td></tr>";
		}
	
		mysqli_close($db);
	}else{
		$str=$str. "<tr ><td colspan=\"11\" class=\"norecord\">*Error, Invalid input</td></tr>";
	}
	$str=$str."</tbody>
			</table>
		</div>";
	echo $str;
	?>
