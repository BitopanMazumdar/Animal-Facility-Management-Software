<?php include "include/sesionlauth.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Animal Facility Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   
  <script src="jquery/jquery-3.js"></script>
  
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/js/bootstrap.min.js"/> 
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <link rel="stylesheet" href="css/stylesboot.css">
  
</head>
<body style="background-color:#F8F9FA">
	<nav >
		 <div class="container-fluid">
			<?php 
			include"include/headerboot.php"; 
			?>
		  </div>
		  <div class="container-fluid">
			<?php 
			include"include/MenuAi.php"; 
			?>		
		  </div> 
	</nav>
	
 <!-- srcipt strat -->
<script type="text/javascript">
$(document).ready(function(){
	$("#displaydiv").slideDown("slow");
	$("#displaydiv2").slideDown("slow");
});
</script>
<script type="text/javascript">

function getAddress(val){
	
	$.get("Saddress.php", {ascode:val}, function(data, status){
		
	$("#address").val(data);
	
	});
}

</script>
<script type="text/javascript">
$(document).ready(function(){
	
	$.get("Supplier_query.php", function(data, status){
		$("#AIFcode").html(data);
		
	});	
		
});

</script>

<script type="text/javascript">
function checkNo(val,val1,no)
{
if(val1<val)
{
alert("Issed No. should not be more than required No");
$("#isno"+no).val(val1);
}
if(val=="")
$("#isno"+no).val(0);
}
function valid(){
	frm=document.issue_form;
	var patt = /[%*+;<=>^]/;
	if(frm.dos.value == ""){
		alert("Please enter Date of issue!");
		frm.dos.focus();
		return false;
	}
	if(frm.AIFcode.value == ""){
		alert("Please enter AIFcode!");
		frm.dos.focus();
		return false;
	}
	
	if(frm.tos.value == ""){
		alert("Please enter Time of issue!");
		frm.tos.focus();
		return false;
	}
	if(frm.dpt.value == ""){
		alert("Please enter Delivery point!");
		frm.dpt.focus();
		return false;
	}
	if(frm.msg.value == ""){
		alert("Please enter reason of Rejection!");
		frm.msg.focus();
		return false;
		
	}
	if(patt.test(frm.msg.value)){
			alert("invalid message ! special characters: %*+;<=>^ are not allowed");
			frm.msg.focus();
			return false;
		}
	
  var r = confirm("confirm submit!");
  if(r == true){
    return true;
  }else{
	frm.dos.focus();
    return false;
  }
}

</script>
 <!-- srcipt end -->
<div>&nbsp;</div>

<?php 
$pcode=htmlspecialchars($_POST['pcode']);
$inumber=htmlspecialchars($_POST['inumber']);  
?>
 <div class="container" >
    <div class="col-sm-offset-2 col-sm-8 ">
	<!-- submit message -->
		<?php 
				if(isset($_SESSION['message'])){
					echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
					unset($_SESSION['message']);
				}		
		?>		                    
    </div>
		<h4><span class="col-sm-12 text-primary"><i class="fa fa-check"></i>Animal Request Management </span></h4>
                   
</div>
 <div class="container" id="displaydiv" style="display:none">

	 <form action="Reply_processing.php" method="post" name="issue_form" id="issue_form" onsubmit="return valid();" class="form-horizontal">
		<?php 
			include "DBconnect.php";
			$result = mysqli_query($db,"SELECT IndentNumber, Projectcode, Title,  RName, ARDate,IndentTime, Duration, TAssistance, SRequest FROM indentform WHERE IndentNumber='$inumber'");
			
			if($result){
				$str="<div class=\"container\" >
				<div class=\"panel panel-success\">
				<div class=\"panel-heading\">
					Animal Request Details
				</div>
				<div class=\"panel-body  table-responsive\" >
					<table class=\"table table-striped table-hover\">
						<thead>
							<th>Protocol</th>
							<th>Title</th>
							<th>Requested By</th>
							<th>Needed On</th>
							<th>Time</th>
							<th>Duration</th>
							<th>Assistant</th>
							<th>Sp. Request</th>
						</thead>
						<tbody>";
					
				$i=1;
				while($pass=mysqli_fetch_array($result,MYSQLI_BOTH)){
					//IndentNumber, Projectcode, Title,  RName, ARDate,IndentTime, Duration, TAssistance, SRequest
					$str=$str."<tr> 
							<td class=\"table-text\"><div>".htmlspecialchars($pass['Projectcode'])."</div></td>
							<td class=\"table-text\"><div>".htmlspecialchars($pass['Title'])."</div></td>
							<td class=\"table-text\"><div>".htmlspecialchars($pass['RName'])."</div></td>
							<td class=\"table-text\"><div>".htmlspecialchars($pass['ARDate'])."</div></td>
							<td class=\"table-text\"><div>".htmlspecialchars($pass['IndentTime'])."</div></td>
							<td class=\"table-text\"><div>".htmlspecialchars($pass['Duration'])."</div></td>
							<td class=\"table-text\"><div>".htmlspecialchars($pass['TAssistance'])."</div></td>
							<td class=\"table-text\"><div>".htmlspecialchars($pass['SRequest'])."</div></td>
						</tr>";
						$i++;
						
					$result1 = mysqli_query($db,"SELECT SpStrain, Gender, Weight_Age,NoAnimal FROM indentanimal WHERE IndentNumber='$inumber' ");
					$j=0;
					if($result){
						$str=$str."<tr>
						<td colspan=\"9\">
						<div class=\"table responsive\">
						<table class=\"table\" border=\"1\" style=\"border-color: #666;border-collapse:collapse;width:80%;\" cellpadding=\"10\" align=\"center\">
							<tr>
								<th>Line</th>
								<th>Animal</th>
								<th>Gender</th>
								<th>Quantity</th>
								<th>Wieght/Age</th>
																
							</tr>
								<input type=\"hidden\" name=\"ai1\" value=\"155\" />
								<input type=\"hidden\" id=\"inum\" name=\"inum\" value=\"".$inumber."\"  />
								<input type=\"hidden\" name=\"pc\" value=\"".$pcode."\" />";
							
						while($pass1=mysqli_fetch_array($result1,MYSQLI_BOTH)){
							$j++;
							$str=$str."<tr>
								<td class=\"table-text\"><div>".$j."</div></td>
								<td class=\"table-text\"><div>
									<input class=\"form-control\" type=\"text\" readonly id=\"strain".$j."\" name=\"strain".$j."\" value=\"".htmlspecialchars($pass1['SpStrain'])."\" />
								</div></td>
								
								<td class=\"table-text\"><div>
									<input class=\"form-control\" type=\"text\" readonly  id=\"sex".$j."\" name=\"sex".$j."\" value=\"".htmlspecialchars($pass1['Gender'])."\"  />
								</div></td>
								
								<td class=\"table-text\"><div>
									<input class=\"form-control\" size=\"10%\" type=\"number\" min=\"1\" name=\"isno".$j."\" id=\"isno".$j."\"  value=\"".htmlspecialchars($pass1['NoAnimal'])."\" onchange=\"checkNo(this.value,".htmlspecialchars($pass1['NoAnimal']).",".$j.")\"  />
								</div></td>
								<td class=\"table-text\"><div>
									<input class=\"form-control\" readonly type=\"text\" id=\"age".$j."\" name=\"age".$j."\" value=\"".htmlspecialchars($pass1['Weight_Age'])."\"  />
								</div></td>
								
							</tr>";			  
						
						}
					$str=$str."<input type=\"hidden\" id=\"rowno\" name=\"rowno\" value=\"".$j."\"  />	
								</table>
							</div>
						</td>
					</tr>
					</tbody>
				</table>
			</div>
		</div>";
					}else{
						//
					}
				}
			}else{
				//
			}
					
			echo $str;
			
			mysqli_free_result($result);
			mysqli_close($db);
				 					
		?> 
	<div class="container" id="displaydiv2" style="display:none">
        <div class="col-sm-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                   Animal House Reply
                </div>

                <div class="panel-body">
                    <!-- submit message -->
						<?php 
								if(isset($_SESSION['message'])){
									echo "<div class=\"alert alert-danger\">".htmlspecialchars($_SESSION['message'])."</div>"; 
									unset($_SESSION['message']);
								}		
						?>
					<!-- submit message -->	
                                        
                        <!-- Task Name -->
                        <div class="form-group">
							<label for="zone" class="col-sm-3 control-label"><span style="color: red">*</span>Date of delivery:</label>
							<div class="col-sm-6">
								<input class="form-control" required type="date"  id="dos" name="dos" value="" style="width:10em" />
							</div>
						</div>
						<div class="form-group">
							<label for="manager" class="col-sm-3 control-label"><span style="color: red">*</span>Time of delivery:</label>
							<div class="col-sm-6">
								<select class="form-control" required style="width:8em" name="tos" id="tos">
									<option selected="selected" value="">Select</option>
									<option value="09:30">09:30</option>
									<option value="10:00">10:00</option>
									<option value="10:30">10:30</option>
									<option value="11:00">11:00</option>
									<option value="11:30">11:30</option>
									<option value="12:00">12:00</option>
									<option value="12:30">12:30</option>
									<option value="13:00">13:00</option>
									<option value="13:30">13:30</option>
									<option value="14:00">14:00</option>
									<option value="14:30">14:30</option>
									<option value="15:00">15:00</option>
									<option value="15:30">15:30</option>
									<option value="16:00">16:00</option>
									<option value="16:30">16:30</option>
									<option value="17:00">17:00</option>
									<option value="17:30">17:30</option>
									<option value="18:00">18:00</option>
								</select>
							</div>
						</div>
						<div class="form-group">
							<label for="zone" class="col-sm-3 control-label"><span style="color: red">*</span>Animal Issued From:</label>
							<div class="col-sm-6">
								<select class="form-control" required  name="AIFcode" id="AIFcode" onfocus="getspecies();" onchange="getAddress(this.value);" style="width:8em">
									<option value="">Select</option>
								</select> 
							</div>
						</div>
						
						<div class="form-group">
							<label for="zone" class="col-sm-3 control-label">Address:</label>
							<div class="col-sm-6">
								<textarea class="form-control" readonly name="address" cols="30" rows="3" id="address"></textarea>
							</div>
						</div>
						<div class="form-group">
							<label for="zone" class="col-sm-3 control-label"><span style="color: red">*</span>Delivery Point:</label>
							<div class="col-sm-6">
								<input class="form-control" style="text-transform: capitalize;" pattern="[A-Za-z\\0-9\s./-]*" title="Special characters: . / \ - are allowed only" required type="text" id="dpt" name="dpt" value="" />
							</div>
						</div>
						<div class="form-group">
							<label for="zone" class="col-sm-3 control-label">TA name (if req.):</label>
							<div class="col-sm-6">
								<input class="form-control" style="text-transform: capitalize;" pattern="[A-Za-z\s]*" title="Special characters and digits are not allowed" type="text" id="tech_name" name="tech_name" value="" />
							</div>
						</div>
						<div class="form-group">
							<label for="zone" class="col-sm-3 control-label"><span style="color: red">*</span>Remark:</label>
							<div class="col-sm-6">
								<textarea class="form-control" required name="msg" cols="30" rows="3" id="msg"></textarea>
							</div>
						</div>
						<!-- Add Task Button -->
                        <div class="form-group">
                            <div class="col-sm-offset-4 col-sm-6">
                                <button type="submit" class="btn btn-success">
                                    <i class="fa fa-btn fa-check"></i>Issue Animal
                                </button>
								<button type="button" class="btn btn-warning" onclick="window.history.back()">
									<i class="fa fa-btn fa-arrow-left"></i> Back
								</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
		</div>
	</div>		

	<div>&nbsp;</div>
	<div>&nbsp;</div>
	
	<div class="footer">
		<?php 
			include"include/footerboot.php"; 
		?>
	</div>
	
</body>
</html>	