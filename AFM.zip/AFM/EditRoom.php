<?php include "include/sesionlauth.php"; ?>
 <?php 
	$room=filter_var($_GET['oldrm'], FILTER_SANITIZE_STRING);
	$newroom=filter_var($_GET['newrm'], FILTER_SANITIZE_STRING);
	
	if($newroom != ""){
		include "Dbconnect.php";
		mysqli_query($db,"UPDATE rooms SET RoomName='$newroom' WHERE RoomName='$room'" );
		$result = mysqli_affected_rows($db);
		if($result >=0){
			$_SESSION['message']="Room: ".$room." is Successfully edited to: ".$newroom;
			//echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=HouseRooms.php\">";
			
		}else{
			$_SESSION['message']="Fail to edit  ! contact admin  !";
			//echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=HouseRooms.php\">";
		}
		
		//mysqli_free_result($result);
		mysqli_close($db);
	}else{
		$_SESSION['message']="Invalid input data";
		//echo "<META HTTP-EQUIV=\"Refresh\" Content=\"0; URL=HouseRooms.php\">";
	}
		
		
	?>